# Franken Robotics · reproducible design experiments

Unzip the companion into an empty directory. From the directory containing this README, run the standard-library checks with

```sh
python3 -B verify.py
```

For all checks install NumPy and SciPy into your selected Python environment and place the Z3 executable on PATH. The recorded native environment used CPython 3.15.0, NumPy 2.5.4, SciPy 1.18.1 with its bundled HiGHS interface, and Z3 4.15.4 on arm64 macOS. Use those versions for strict byte comparisons. A library version appears in the P01 JSON, and other environments can differ in last-place floating-point output.

```sh
python3 -B verify.py --all
```

The runner checks the full inventory of released filenames as well as the SHA-256 of each listed file. An incomplete or duplicate manifest fails validation. Additional files created after extraction are outside the release inventory. The manifest provides an integrity check; identify the original package with the ZIP digest supplied independently. Run with Python assertions enabled. Each pilot can also be run separately. Standard output carries the new result. The commands below preserve the reference receipts.

## What is in the archive

| Location | Question and checks |
|---|---|
| `mor/MOR_CASE.md`, `mor/CLAIMS.md`, `mor/audit/` | Decision contract, seven audited claim dispositions and independent findings. P01–P03 were three passes within run 20261121T230034Z. Evidence ID E001 refers to the original Astra plan held in the source study. Each fixture here contains its own numerical inputs. |
| `mor/raw/` | Original author notes from all three passes. Consult the independent audit for subsequent corrections and bounds. Paths beginning with `.mor/run-20261121T230034Z/` in the notes correspond to `mor/` in this archive. |
| `mor/repro/P01-*` | Protocol, driver and original result for static stance feasibility. The projected and lifted formulations both return half-width 3/14 m under adjustable force authority. The passive equal-spring example violates one 160 N rating by 15 N. |
| `mor/repro/P02-*` | Protocol, driver, force-law results and post-pilot additive-pad family calculation. The three-law early observation failed on all 225 delayed-law cases. The direct target-dwell method succeeded on all 900 deterministic combinations. The 300 g and 240 g designs are certified at the centered nominal readings. The independent audit supplies counterexamples to extending those certificates over all readings. |
| `mor/repro/P03-*` | Binary-sensor protocol, script and exact Bayes results for fixed horizons and two error-dependence assumptions. The independent audit also considers an adaptive stopping rule. |
| `mor/repro/AUD01-recheck.py` | Independent recheck of the published P01–P03 outputs, including a generic four-force linear program on all 11,520 stance cases, gripper counterexamples and the sensor calculation. |
| `mor/repro/P04-docking.*` | Subsequent exact three-tick construction for gains 1 and 2, a bounded command, a first-pulse velocity measurement, and the common-command late-observation comparison. Both observed-gain schedules reach position 1 with zero velocity. This fixture was added after the seven-claim audit. |
| `mor/repro/P05-docking-family.*`, `P05-docking-family-prereg.md` | Protocol, scenario-tree LP driver and receipt for a noisy early velocity reading. Across 561 error/bound pairs, 344 admit exact docking and 217 fail, including nine closed-boundary equalities. All 561 late-only observations fail. The archive verifier also derives the feasible first-command interval directly using rational inequalities. |
| `pusher/PILOT_LOCK.md`, `pilot.py`, `pilot_check.py`, `PILOT_RUN.json` | Locked 10-fixture pusher protocol, two solution methods, separate checker and original timing receipt. Each arm matched 20 intervals and the checker rejected six deliberately wrong certificates. The recorded composed/specialized median ratios were 1.345× warm and 1.088× cold. Timings include certificate acceptance and follow the locked host protocol. |
| `pusher/check_locked_pusher_z3.py`, `pusher/queries/`, `pusher/pusher-z3*.json` | Independent SMT generator, 21 literal SMT-LIB queries, final receipt and two earlier tactic receipts. The final run returned UNSAT on all 20 mismatch queries and SAT on the deliberate over-exclusion. The QSAT attempt returned unknown on all queries. QE2 timed out on the `shared-tight/shared` query and the mutant. |
| `sill/promotion_rule.*` | Enumeration of the original 64-pair development decision rule over 2,145 legal discordance-count pairs. Zero qualify for a practical tie. When A-only count is zero, B needs 15 B-only results for promotion. The all-concordant interval first fits the tie margin at 86 pairs. |
| `sill/quasistatic_sill.*` | Two-stage planar statics for 12 wheel/edge/payload combinations. Each stage samples 400 edge angles. Under the modeled uniform friction range, 3/12 design cells have positive modeled success fraction. The calculation excludes impact momentum, active controller transients, other collision modes and out-of-plane motion. Sampled maxima provide a diagnostic baseline. They do not prove dynamic mission success or continuous-angle sufficiency. |

## Selected commands

```sh
(cd mor/repro && python3 -B P01-inverse.py)
(cd mor/repro && python3 -B P02-identification.py)
(cd mor/repro && python3 -B P02-identification-family.py)
(cd mor/repro && python3 -B P03-sensor.py)
(cd mor/repro && python3 -B P04-docking.py)
(cd mor/repro && python3 -B P05-docking-family.py)
(cd mor/repro && python3 -B AUD01-recheck.py)
python3 -B pusher/pilot.py --arm specialized
python3 -B pusher/pilot.py --arm composed
python3 -B pusher/pilot.py
python3 -B pusher/check_locked_pusher_z3.py
z3 -T:5 pusher/queries/wide-adjustable.smt2
z3 -T:5 pusher/queries/mutant-wide-adjustable.smt2
python3 -B sill/promotion_rule.py
python3 -B sill/quasistatic_sill.py
```

The pusher driver without `--arm` runs the original negative controls and nine warm and nine fresh-process timing pairs; elapsed times vary by host and load. The Z3 generator reconstructs its queries from the fixture table. A real discrepancy is satisfiable. Solver timeouts and unknowns leave that check unresolved.

The original three protocols, source, raw notes, receipts and audit are included. The archived pusher lock localizes its final source-footnote links. Its source-file SHA-256 before that editorial change was `a25ee5b331516a060c84056b83bdfe38cbca0f27b59665eb48c87c68f750ef30`. This package covers bounded scalar, statistical and analytic work and native execution of the scalar docking screen. Integrated native robot dynamics, physical acquisition and end-to-end design throughput require their own evidence.

## Native screens, planar comparison and information experiments

The default verifier rechecks the native source manifests, regenerates the ordered binary32 and integer outputs on any platform with standard Python, compares the results with both native receipts, and replays two information experiments. The full verifier also reproduces the 156-condition planar calculation and compares the labels with sampled statics. Native dispatch is optional for replay; its original device evidence is bundled.

| Location | Contents |
|---|---|
| `native/metal/`, `native/metal/integer/` | Apple M5 Ultra guarded float32 and exact uint32. Each folder has its separate prediction lock, Objective-C++ host, MSL, Python driver, source checksums, complete receipt, and build/run instructions in its README. |
| `native/cuda/` | RTX 4090 guarded float32 on device 0, device 1, and both devices. The signed-int32 follow-up used device 0. TOOLCHAIN.md gives exact compiler options and commands. Protocols, source, terminal results, ordered output digests, SM 8.9 disassembly and the aggregate JSON receipt are included. |
| `sill/CRITIC.md` | Corrected scope of the planar and static experiments, final critic source, independent audit, 156-case detailed output and compact sensitivity results. |
| `information/` | Exact deadline/tag script and notes, plus independent fresh replay versus two update-reuse methods on four camera delivery states. The stored stdout transcripts were regenerated while packaging. |
| `original-package/` | Original README, verifier, and checksum list from the first 59-file companion. All original study files retain their previous bytes. Run the current verifier from the archive root. |

Fresh host timing depends on driver, cache state, scheduling and hardware. The Metal warm timer covers input packing through completed host result buffers; the independent Python audit runs separately. CUDA's warm timer includes host auditing. CUDA receipts retain first-call timing and the minimum, median and maximum of 21 warm calls; Metal receipts also retain individual repetitions. Compare each native path with its same-host baseline under the same harness. These devices executed a scalar docking-boundary test. End-to-end robot dynamics, sensor pipelines and integrated product speed remain open.

## Three-family study and audit

`study/DUELING_WIZARDS_REPORT.md` presents the proposals, all 18 scores, three final reactions and post-reveal dispositions. `study/BRENNER_REPORT.md` ties the proposed experiments to their falsifiers. `study/PROVENANCE.md` identifies the authors and the source artifacts. The final Gemini-authored material came from Gemini 4 Neon Medium.

`pusher/AUDIT_PILOT.md` and `pusher/audit_pilot/` contain the independent timing-ceiling and raw-plant quantifier-elimination checks. `information/contract_bus_check.py` tests the leading proposal against a two-finger current-bus counterexample. The verifier checks the score matrix against the six reviews. With `--all`, it also runs the coupled-bus and raw-plant checks.

All scientific material from the native edition is preserved. Its three superseded wrapper files are retained in `native-edition/`.

## Reproduction checks after fresh review

The archive runner checks both pusher solvers against the locked intervals, then submits the six incorrect certificates to the independent checker. In full mode it rebuilds all 21 literal SMT programs from the locked plant, checks their contents and solver results, tests the two-label controller witness directly, and checks the complete 12 eliminated formulas for equivalence to their locked intervals. The original 150-character formula previews remain available as historical receipts.

Native verification reconciles the eight guarded/comparator CUDA runs and two exact-device runs with their original terminal output. It recomputes each shard's counts, including wrong signs, fallback decisions, ties and exclusions. For Metal it recomputes the medians from the recorded samples. This portable replay checks existing device evidence. A new native timing measurement requires the platform-specific commands.

Run `python3 -B verify_negative.py` from the extracted directory to exercise deliberate omissions, corrupted labels and a malformed controller witness in temporary copies.

## Winding control and recorded comparisons

The historical planar driver used the target current in its resistive feedforward term, $R i_{ref}$. The current fixture specifies the measured winding current, $R i$. At unsaturated voltage the two current-loop time constants are 2 ms and 2.5 ms. Full replay applies that single change in a temporary copy and compares all 156 physical conditions against the original planar labels. Of 78 cases per design, successes changed from 8 to 18 for A and from 61 to 67 for B. Sixteen timeouts became successes and eight stalls became timeouts. The exact changes are in `sill/winding-law-sensitivity.tsv`. Both runs use the exploratory planar contact and dwell logic.

The runner checks the radius, fillet, payload offset and friction for each named row and the original grid's denominator, stiffness, damping and timestep. It compares the recorded pusher inputs with the ten locked cases, checks 18 alternating timing pairs for successful reference matches, and recomputes the warm and cold median ratios. The original receipt contains a match flag per arm and trial and the per-trial mean timing for each block of 100 warm batches. Individual timings within a warm block were never recorded. The 20 negative checks include an incorrect physical radius, a duplicate grid condition, a mismatched timed result, an overstated speed ratio, absent events mistaken for time zero, a wrong Metal cold-run label count and a nonfinite warm timing sample.

The historical `sill/pilot_quick.json` uses Python's bare `NaN` extension for 261 unrecorded timestamps. These are the front-axle, rear-axle and clearance events in each of 50 stalled and 37 timed-out rows. The 69 successful rows have all three timestamps in order. To export standards-compliant JSON, run `python3 -B check_additions.py --export-planar-json > planar-public.json`. Each missing timestamp exports as `null` with the reason `unrecorded_by_planar_scorer`. The verifier compares event presence for each replayed condition. Crossing times refer to the historical planar scorer's own event definitions.

## Two follow-up experiments

Run `python3 -B verify.py --all` to replay the two additional CPU checks in `followups/` against their transcripts. Each driver also runs on its own.

**Docking with hidden gain tolerances.** The native facet assumes exactly two fixed gains, 1 and 2, one early velocity packet with bounded additive error, a shared control bound and exact terminal position and velocity. Add gain 33/32. For any first pulse of magnitude at most 3/4, gains 1 and 33/32 can return the same reading when the error radius is 1/64. A causal controller must then issue the same two remaining commands. Its two final positions are proportional to those gains. Even with unconstrained final velocity, their worst absolute position error is at least 1/65 m for a 1 m target. Z3 checks the midpoint alias, rules out exact docking and any error strictly below 1/65 m, and finds a common command sequence meeting the bound for those two gains with zero terminal velocity. Under the wider gain support, every archived native row admits this ambiguity because its command bound divided by 32 is at most twice its error radius. Each grid's 34,590 original positive decisions would therefore be wrong if reused on the amended mission. The new checks use the archived grid formulas on CPU.

**Sampled wheel control.** Use the 75 mm wheel with 0.0002 kg m² added rotor inertia, giving total spin inertia 0.00107890625 kg m² per wheel. In the local model, hold the chassis fixed, force the same direction of slip and constant contact torque, and stay strictly inside the current and voltage limits. Perturb wheel rate and winding current about that operating point. Their equations are `J δω̇ = 0.2 δi − 0.002 δω` and `τ δi̇ = δi_ref − δi`. The controller holds `δi_ref = −2 δω(0)` for 10 ms. With 1 Ω winding resistance, 10 mH inductance and 4 Ω feedback, target-current feedforward gives τ = 2 ms and measured-current feedforward gives τ = 2.5 ms. Exponentiating the augmented system with held target yields sampled spectral radii 1.4820 and 0.9207. The original 50 µs current-then-wheel substep order gives 1.5248 and 0.9124 for the same two laws. At 6.25 µs those approach 1.4875 and 0.9197. The instantaneous-current scalar magnitude 2.7075 misses the change in local stability. Rolling, changes of slip direction, load transfer, clipping and chassis motion require the coupled plant.

**Historical timing evidence.** Both Metal harnesses retained three cold CPU/GPU pairs per grid, giving 24 arm records. Each retained the correct total of 34,590 positive labels. The 36 warm pairs retained CPU, Metal host and GPU-active durations. Their ordered-label evidence comes from separate audit dispatches. CUDA compared each timed call's error counters with the first call for that arm and printed one aggregate per shard together with its timing summary. Its ordered output hashes also came from separate emission runs.

## Admission fixtures

Full replay also runs `python3 -B followups/r2_contracts.py` and `python3 -B followups/r4_contracts.py`. The first checks mass support, a design-dependent load, factory and handoff information, global range ambiguity, symmetric actions and persistent hidden dynamics. The second checks clipped-action likelihoods, joint clearance errors, clock and scale fitting, changed optimal designs, tail latency and dependent stage outcomes. Each prints its counterexamples when run directly.

The two optional host-native probes need Git checkouts holding the precise commit objects below. They read sources with `git show` and build in temporary directories. Use Python 3.12 or later with assertions enabled. From the extracted archive root, substitute local checkout and cache paths in these commands.

```sh
python3 -B followups/R1_layout.py /path/to/projects
python3 -B followups/R1_ppo_native.py --repo /path/to/projects/frankensim --cache /path/to/cargo/registry/cache
```

The layout probe expects sibling directories `franken_numpy` at `e8cb85f4e5ac31ca7e7a2efd0ee26322e2f5451d` and `frankentorch` at `8165d6a18028b059027eabae1880181231f0b12d`, plus a `rustc` supporting edition 2024. It compiles the pinned NumPy layout module and the Torch contiguous-stride constructor. An unconverted stride reads 12 where the correct value is 3. Reversing the second axis yields the logical sequence 1, 0, 3, 2.

The PPO probe uses `frankensim` at `483d09c682f24947008f2df43f53e6c3e1291c1e`, `rustc +nightly-2026-07-06` via rustup, and a cached `*/libm-0.2.16.crate` under the supplied registry-cache directory. The driver verifies the crate against the pinned Cargo.lock digest before compiling. Keep `R1_ppo.rs` beside `R1_ppo_native.py`. On the archived revision the owner supplied log-standard-deviation gradients −0.25, −0.5 and 0 at ratios 0.5, 1 and 2. Finite differences gave 0, −0.5 and −1. The owner critic gradient was 0 against a reference of 2. The second reset episode's replay ratio was 1.582459. These probes reproduce specific owner behavior used to decide whether to accept those components.
