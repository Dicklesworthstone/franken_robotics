"""Portable native receipt verification and matched planar comparison."""
from functools import lru_cache
from pathlib import Path
import csv
import hashlib
import json
import math
from statistics import median
import struct
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
COUNT = 65536
HALF = 1 << 27


def digest(data):
    return hashlib.sha256(data).hexdigest()


def binary32(value):
    return struct.unpack("<f", struct.pack("<f", value))[0]


def reference(scale):
    blobs = {key: bytearray() for key in ("raw", "tri", "final", "equal")}
    ties = mistakes = 0
    for i in range(COUNT):
        u = HALF + (i * 65537) % (HALF + 1)
        e = (u + HALF) // 4 + (i % 9 - 4) * scale
        residual = binary32(binary32(binary32(u * 2**-28) + 0.5) - 4 * binary32(e * 2**-28))
        actual = int(4 * e < u + HALF)
        raw = int(residual > 0)
        guard = 2 if abs(residual) <= 2**-21 else raw
        ties += 4 * e == u + HALF
        mistakes += guard != 2 and guard != actual
        for key, label in (("raw",raw),("tri",guard),("final",actual),("equal",4*e == u+HALF)):
            blobs[key].append(label)
    if mistakes or ties != 1820 or sum(blobs["final"]) != 34590:
        raise ValueError("The bounded dyadic reference changed")
    return blobs


def indexed_runs(rows, modes):
    keyed = {(r["mode"], r["arm"]): r for r in rows}
    expected = {(m, a) for m in modes for a in ("near", "far")}
    if set(keyed) != expected or len(rows) != len(expected):
        raise ValueError("Incomplete or duplicate native run coverage")
    return keyed


def cuda_stdout(path):
    """Read the recorded CUDA harness lines independently of the derived JSON summary."""
    rows = []
    for line in path.read_text().splitlines():
        if line.startswith("mode="):
            fields = dict(word.split("=", 1) for word in line.split())
            row = {k: v if k in ("mode", "arm") else int(v) if k == "warm_runs" else float(v)
                   for k, v in fields.items()}
            row["per_shard"] = []
            rows.append(row)
        elif line.startswith("device="):
            rows[-1]["per_shard"].append({k: int(v) for k, v in
                                         (word.split("=", 1) for word in line.split())})
    return rows


def counts(blobs, first, size, exact_mode):
    part = slice(first, first + size)
    truth = blobs["final"][part]
    raw = truth if exact_mode else blobs["raw"][part]
    tri = truth if exact_mode else blobs["tri"][part]
    fp = sum(r == 1 and t == 0 for r, t in zip(raw, truth))
    fn = sum(r == 0 and t == 1 for r, t in zip(raw, truth))
    return {"first": first, "rows": size, "exact_true": sum(truth),
            "exact_ties": sum(blobs["equal"][part]), "raw_fp": fp, "raw_fn": fn,
            "fallback": tri.count(2), "resolved_without_fallback": size - tri.count(2),
            "corrected": fp + fn, "guarded_fp": 0, "guarded_fn": 0}


def check_cuda_run(row, blobs, exact_mode):
    mode = row["mode"]
    devices = {"cpu": [-1], "0": [0], "1": [1], "dual": [0, 1]}[mode]
    size = COUNT // len(devices)
    expected = [dict(counts(blobs, i*size, size, exact_mode), device=device)
                for i, device in enumerate(devices)]
    if row["per_shard"] != expected:
        raise ValueError(f"Incorrect native per-shard results for {mode}/{row['arm']}")
    lo, mid, hi = (row[k] for k in ("warm_min_us", "warm_median_us", "warm_max_us"))
    if row["warm_runs"] != 21 or not (0 < lo <= mid <= hi and hi < math.inf and 0 < row["cold_us"] < math.inf):
        raise ValueError("Incomplete CUDA timing summary")


def check_metal_workload(workload, blobs, exact_mode):
    acc = workload["accuracy"]
    hash_final = digest(blobs["final"])
    c = counts(blobs, 0, COUNT, exact_mode)
    expected = {"exact_equal": c["exact_ties"], "exact_include": c["exact_true"],
                "exact_exclude": COUNT-c["exact_true"], "cpu_false": 0,
                "python_exact_sha256": hash_final, "cpu_sha256": hash_final}
    if exact_mode:
        expected.update(fallback=0, metal_false_admit=0, metal_false_exclude=0, metal_sha256=hash_final)
    else:
        expected.update(raw_false_include=c["raw_fp"], raw_false_exclude=c["raw_fn"], unknown=c["fallback"],
                        direct_include=blobs["tri"].count(1), direct_exclude=blobs["tri"].count(0),
                        guarded_false_include=0, guarded_false_exclude=0, resolved_false=0,
                        raw_sha256=digest(blobs["raw"]), guarded_sha256=digest(blobs["tri"]),
                        final_sha256=hash_final)
    if any(acc[k] != v for k, v in expected.items()):
        raise ValueError("Metal confusion counts or ordered outputs differ")
    warm, cold = workload["warm"]["samples"], workload["cold"]
    if len(warm) != 9 or len(cold) != 3:
        raise ValueError("Incomplete Metal timing samples")
    def duration(value):
        return type(value) in (int, float) and 0 < value < math.inf

    for sample in warm:
        if (set(sample) != {"cpu_us", "metal_us", "gpu_us"}
                or not all(duration(value) for value in sample.values())
                or sample["gpu_us"] > sample["metal_us"]):
            raise ValueError("Invalid Metal warm timing sample")
    for pair in cold:
        for backend in ("cpu", "gpu"):
            sample = pair[backend]
            times = ["host_us", "process_us"] if backend == "cpu" else ["gpu_us", "host_us", "process_us"]
            values = [sample[k] for k in times]
            if (sample["ones"] != c["exact_true"] or not all(duration(t) for t in values)
                    or values != sorted(values)):
                raise ValueError("Metal cold result count or timing sample differs from the measured workload")
    calculated = {k: median(sample[k] for sample in warm) for k in ("cpu_us", "metal_us", "gpu_us")}
    for backend in ("cpu", "gpu"):
        calculated[f"process_cold_{backend}_us"] = median(sample[backend]["process_us"] for sample in cold)
    if calculated != workload["median"]:
        raise ValueError("Metal timing median differs from raw samples")


def check_native_receipts():
    device = ROOT / "native"
    cuda = json.loads((device/"cuda/RECEIPT.json").read_text())
    metal = json.loads((device/"metal/RECEIPT.json").read_text())
    integer = json.loads((device/"metal/integer/RECEIPT.json").read_text())
    placements = ("cpu", "0", "1", "dual")
    guarded = indexed_runs(cuda["registered_runs"], placements)
    exact = indexed_runs(cuda["exploratory_direct_int32_gpu0_runs"], ("0",))
    if guarded != indexed_runs(cuda_stdout(device/"cuda/native-runs.txt"), placements):
        raise ValueError("Guarded CUDA aggregate differs from original harness output")
    if exact != indexed_runs(cuda_stdout(device/"cuda/native-int32-runs.txt"), ("0",)):
        raise ValueError("Exact CUDA aggregate differs from original harness output")
    if (cuda["native_device_count"], cuda["cuda_metal_canonical_matches"],
            cuda["bulk_labels_per_arm"], cuda["guarded_mismatches"]) != (2, 18, COUNT, 0):
        raise ValueError("CUDA summary totals changed")
    expected_hashes = {f"{mode}-{a}.{k}" for mode in ("0","1","dual")
                       for a in ("near","far") for k in ("raw","tri","final")}
    if set(cuda["registered_canonical_hashes"]) != expected_hashes:
        raise ValueError("CUDA ordered output hash inventory changed")
    for folder in (device/"metal", device/"metal/integer"):
        for entry in (folder/"SHA256SUMS").read_text().splitlines():
            expected,name = entry.split("  ",1)
            if digest((folder/name).read_bytes()) != expected:
                raise ValueError("Metal source/receipt manifest changed")
    for field,name in (("registered_prereg","prereg.md"), ("registered_source","screen.cu"),
                       ("exploratory_prereg","exploratory-int32.md"), ("exploratory_source","native-int32.cu")):
        if digest((device/"cuda"/name).read_bytes()) != cuda[field+"_sha256"]:
            raise ValueError("CUDA source or registration differs from receipt")
    for arm,case,scale in (("near","near",1),("far","separated",2048)):
        blobs = reference(scale)
        for profile, exact_mode in ((metal, False), (integer, True)):
            if set(profile["workloads"]) != {"near","separated"} or profile["fixture_count"] != COUNT:
                raise ValueError("Incomplete Metal workload coverage")
            check_metal_workload(profile["workloads"][case], blobs, exact_mode)
        for mode in placements:
            check_cuda_run(guarded[mode, arm], blobs, exact_mode=mode=="cpu")
        check_cuda_run(exact["0", arm], blobs, exact_mode=True)
        for key in ("raw","tri","final"):
            expected = digest(blobs[key])
            for mode in ("0","1","dual"):
                if cuda["registered_canonical_hashes"][f"{mode}-{arm}.{key}"] != expected:
                    raise ValueError("CUDA ordered guarded output differs")
    print("Native sources and receipts verified. Ordered guarded labels match six independent bitmap hashes on Metal, both CUDA devices and dual sharding.")


def information():
    directory=ROOT/"information"
    for name in ("deadline_check","reuse_check"):
        observed = subprocess.check_output([sys.executable,"-B",name+".py"],cwd=directory)
        if observed != (directory/(name+".txt")).read_bytes():
            raise ValueError(f"{name} output changed")
    print("The exact tag-deadline and four-state reuse transcripts matched.")


EVENT_TIMES = ("t_front_over", "t_rear_over", "t_goal")


def event_presence(row):
    present = []
    for key in EVENT_TIMES:
        t = row[key]
        if type(t) not in (int, float) or (not math.isnan(t) and not 0 <= t <= 8):
            raise ValueError(f"Invalid planar event time {key}")
        present.append(not math.isnan(t))
    times = [row[k] for k, seen in zip(EVENT_TIMES, present) if seen]
    if times != sorted(times) or (row["outcome"] == "success" and not all(present)):
        raise ValueError("Inconsistent planar success or event order")
    return tuple(present)


def quick_grid(receipt):
    """Index each label by the declared physical input and verify the complete crossed design."""
    if ((receipt["n"], receipt["dt"], receipt["k"], receipt["cn"]) != (156, 5e-5, 2e5, 2000)
            or type(receipt["wall_s"]) not in (int, float) or not 0 < receipt["wall_s"] < math.inf):
        raise ValueError("Planar quick-grid denominator or solver settings changed")
    for option, value in (("rotor", 0.0), ("ctrl_hz", 100.0), ("stall_terminal", True)):
        if option in receipt and receipt[option] != value:
            raise ValueError(f"Planar quick-grid option {option} changed")
    radii = {"A": 0.060, "B": 0.075}
    fillets = {"sharp": 0.0, "fillet": 0.002}
    expected = {(design, edge, offset, hundredths / 100)
                for design in radii for edge in fillets for offset in (-.04, 0, .04)
                for hundredths in range(35, 96, 5)}
    rows = {}
    for row in receipt["rows"]:
        key = (row["design"], row["edge"], row["pdx"], row["mu"])
        if (key not in expected or key in rows or row["rf"] != radii[key[0]]
                or row["rho"] != fillets[key[1]]
                or any(type(row[k]) not in (int, float) for k in ("pdx","mu","rf","rho","max_pitch"))
                or not 0 <= row["max_pitch"] < math.inf):
            raise ValueError(f"Incorrect or duplicate planar input at {key}")
        event_presence(row)
        rows[key] = row
    if rows.keys() != expected:
        raise ValueError("Missing physical condition in planar quick grid")
    return rows


def strict_planar_record(receipt):
    rows = quick_grid(receipt)
    records = []
    missing = [0] * len(EVENT_TIMES)
    for key, row in rows.items():
        record = dict(row)
        reasons = {}
        for index, (field, seen) in enumerate(zip(EVENT_TIMES, event_presence(row))):
            if not seen:
                record[field] = None
                reasons[field] = "unrecorded_by_planar_scorer"
                missing[index] += 1
        if reasons:
            record["missing_event_reasons"] = reasons
        records.append(record)
    if missing != [87, 87, 87]:
        raise ValueError("Historical planar event coverage changed")
    return json.dumps(dict(receipt, rows=records), allow_nan=False, indent=2)


def winding_law_check(folder, directory, historical, driver):
    source = driver.read_text()
    old = "V = np.clip(R_M * ic + KE * wfwd + KP_I * (ic - cur), -VBUS, VBUS)"
    new = old.replace("R_M * ic +", "R_M * cur +")
    if source.count(old) != 1:
        raise ValueError("Historical winding voltage expression changed")
    variant = directory / "winding.py"
    variant.write_text(source.replace(old, new))
    receipt = directory / "winding.json"
    subprocess.run([sys.executable, "-B", str(variant), "--quick", "--out", str(receipt)],
                   check=True, stdout=subprocess.PIPE)
    fresh = quick_grid(json.loads(receipt.read_text()))
    observed = {k:(r["outcome"], fresh[k]["outcome"]) for k, r in historical.items()
                if r["outcome"] != fresh[k]["outcome"]}
    with (folder / "winding-law-sensitivity.tsv").open() as f:
        reference = {}
        for row in csv.DictReader(f, delimiter="\t"):
            key = (row["design"], row["edge"], float(row["payload_offset_m"]), float(row["friction"]))
            if key in reference:
                raise ValueError(f"Duplicate winding sensitivity row {key}")
            reference[key] = (row["historical"], row["measured_current"])
    if observed != reference or len(observed) != 24:
        raise ValueError("Winding-law sensitivity differs from its named rows")
    new_successes = sum(after == "success" for before, after in observed.values())
    print(f"Compared 156 matched winding-law cases. {len(observed)} outcomes changed, including {new_successes} new successes.")


def planar():
    folder=ROOT/"sill"
    sys.path.insert(0,str(folder))
    from quasistatic_sill import h1_front, h2_rear, TAU_MAX
    cached_front = lru_cache(None)(h1_front)
    cached_rear = lru_cache(None)(h2_rear)
    legacy=json.loads((folder/"pilot_quick.json").read_text())
    strict_planar_record(legacy)
    archived=quick_grid(legacy)
    driver = folder / "planar_sill_pilot.py"
    with tempfile.TemporaryDirectory() as td:
        output=Path(td)/"quick.json"
        subprocess.run([sys.executable,"-B",str(driver),"--quick",
                        "--tag","quick","--out",str(output)],check=True,stdout=subprocess.PIPE)
        fresh=quick_grid(json.loads(output.read_text()))
        winding_law_check(folder, Path(td), archived, driver)
    if any(row["outcome"] != archived[key]["outcome"] or event_presence(row) != event_presence(archived[key])
           for key, row in fresh.items()):
        raise ValueError("Planar quick-grid labels or recorded event coverage changed")
    agreement = extra = opposite = 0
    for row in fresh.values():
        center=(row["rf"],row["rho"],row["pdx"])
        front, rear = cached_front(*center), cached_rear(*center)
        static = max(front[0],rear[0]) <= row["mu"] and max(front[1],rear[1]) <= TAU_MAX
        dynamic = row["outcome"]=="success"
        agreement += static == dynamic
        extra += dynamic and not static
        opposite += static and not dynamic
    if (agreement,extra,opposite)!=(94,62,0):
        raise ValueError(f"Planar/static agreement changed to {(agreement,extra,opposite)}")
    print("Reproduced 156 planar labels. Static agreement 94, additional planar successes 62, opposite disagreements 0.")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Export the original planar quick grid as strict JSON.")
    parser.add_argument("--export-planar-json", action="store_true", required=True)
    parser.parse_args()
    print(strict_planar_record(json.loads((ROOT/"sill/pilot_quick.json").read_text())))
