"""Small exact witnesses for Astra's proposed benchmark and refinement contracts."""

from fractions import Fraction as F
from math import comb, log, sqrt


def rare_slow_missions():
    n, horizon, gain = 24, 1000, 10
    rare = F(1, 100)
    fast_a, slow_a, baseline = 1, 999, 20
    mean_a = (1 - rare) * fast_a + rare * slow_a
    ratio = baseline / mean_a
    # Enumerate the actual number of rare pairs in a sealed IID campaign.
    count_probs = [comb(n, r) * rare**r * (1 - rare)**(n-r) for r in range(n+1)]
    assert sum(count_probs) == 1
    assert sum(r * prob for r, prob in enumerate(count_probs)) == n * rare
    assert ratio == F(1000, 549)
    assert count_probs[0] > F(78, 100)
    # A resample of a constant sample has no support outside that point.
    apparent_ratio = baseline / F(fast_a)
    assert apparent_ratio == 20 and ratio < gain
    common_case_diff = baseline - gain * fast_a
    pop_diff = baseline - gain * mean_a
    # For independent bounded pairs and fixed n, one-sided Hoeffding.
    # X = time_B - gain * time_A has range [-gain*H, H].
    lower_diff = common_case_diff - (gain + 1) * horizon * sqrt(log(1/.05)/(2*n))
    assert lower_diff < 0 and pop_diff < 0
    print(f"Rare-tail fixture: true restricted-time ratio {ratio}, all-fast {n}-pair probability {float(count_probs[0]):.9f}, constant resample ratio {apparent_ratio}")


def completed_throughput():
    # Sequential execution without setup overlap, all 25 missions assigned once.
    baseline = [(50, True)] * 25
    astra = [(1, True)] * 24 + [(100, False)]
    duration = lambda rows: sum(t for t, _ in rows)
    accepted = lambda rows: sum(ok for _, ok in rows)
    latency_ratio = F(duration(baseline), duration(astra))
    completion_ratio = F(accepted(astra), accepted(baseline))
    rate_ratio = F(accepted(astra), duration(astra)) / F(accepted(baseline), duration(baseline))
    assert rate_ratio == completion_ratio * latency_ratio
    assert latency_ratio == F(625, 62) > 10 > F(300, 31) == rate_ratio
    print(f"25 serial missions: restricted-time ratio {latency_ratio}, accepted-rate ratio {rate_ratio}")


def validation_looks():
    looks, size, p = 50, 30, F(89, 100)
    threshold, alpha = .9, .05
    # With all successes, the one-sided exact lower endpoint solves l**size = alpha.
    cp_lower = alpha**(1/size)
    at_least_one = 1 - (1-p**size)**looks
    assert cp_lower > threshold and p < F(9, 10)
    assert F(78, 100) < at_least_one < F(79, 100)
    # A fixed alpha-spending schedule remains valid even if looks are dependent,
    # provided each look supplies a valid conditional p-value for its selected policy.
    adjusted_lower = (alpha/looks)**(1/size)
    assert adjusted_lower < threshold
    print(f"Fixed 89% policy: 30/30 lower bound {cp_lower:.9f}, probability of at least one such look among 50 {float(at_least_one):.9f}")


def stochastic_refinement():
    source_success, target_success = 99, 1
    # Each matrix contains joint integer mass in units of 1/100.
    # Count disagreement for EVERY coupling on this one-tick example.
    all_joints = []
    for both in range(min(source_success, target_success) + 1):
        source_only = source_success - both
        target_only = target_success - both
        neither = 100 - both - source_only - target_only
        if neither >= 0:
            all_joints.append((both,source_only,target_only,neither))
    assert all(j[0] + j[1] == source_success and j[0] + j[2] == target_success for j in all_joints)
    min_disagreement = min(j[1] + j[2] for j in all_joints)
    assert len(all_joints) == 2 and min_disagreement == 98
    assert 0 < target_success < 95 < source_success < 100
    print(f"Equal success/failure support: minimum coupling disagreement {min_disagreement}/100")


if __name__ == "__main__":
    rare_slow_missions()
    completed_throughput()
    validation_looks()
    stochastic_refinement()
