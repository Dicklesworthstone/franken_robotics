"""Execute pinned owner stride constructors and compare independent in-bounds channel reads."""
from pathlib import Path
import subprocess
import sys
import tempfile

projects = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.home()/"projects"
numpy_pin = "e8cb85f4e5ac31ca7e7a2efd0ee26322e2f5451d"
torch_pin = "8165d6a18028b059027eabae1880181231f0b12d"

def pinned(name, pin, file):
    return subprocess.check_output(["git", "show", f"{pin}:{file}"], cwd=projects/name)

driver = """
mod np;
mod tensor;
fn main() {
    let shape = [2,2];
    let n = np::NdLayout::contiguous(shape.to_vec(), 4, np::MemoryOrder::C).unwrap();
    let t = tensor::contiguous_strides(&shape);
    let data: Vec<f32> = (0..16).map(|x| x as f32).collect();
    let index = [1,1];
    let convert = |stride: isize| usize::try_from(stride).unwrap()/4;
    let src = index[0]*convert(n.strides[0]) + index[1]*convert(n.strides[1]);
    let dst = index[0]*t[0] + index[1]*t[1];
    let naive = index[0]*n.strides[0] as usize + index[1]*n.strides[1] as usize;
    println!("f32[2,2]: numpy {:?} bytes, torch {:?} elements; [1,1] via direct metadata copy {}, through conversion {}, ground truth {}",n.strides,t,data[naive],data[dst],data[src]);
    assert_eq!((data[naive],data[dst],data[src]),(12.,3.,3.));
    let reverse = n.as_strided(shape.to_vec(),vec![8,-4]).unwrap();
    let reverse_origin: isize = 4;
    let get = |r: isize,c: isize| data[usize::try_from((reverse_origin+r*reverse.strides[0]+c*reverse.strides[1])/4).unwrap()];
    let copied = [get(0,0),get(0,1),get(1,0),get(1,1)];
    println!("offset=4 bytes, signed strides {:?}, channels in logical order {:?}",reverse.strides,copied);
    assert_eq!(copied,[1.,0.,3.,2.]);
}
"""
with tempfile.TemporaryDirectory() as td:
    root = Path(td)
    (root/"np.rs").write_bytes(pinned("franken_numpy",numpy_pin,"crates/fnp-ndarray/src/lib.rs"))
    tensor = pinned("frankentorch",torch_pin,"crates/ft-core/src/lib.rs")
    start = tensor.index(b"pub fn contiguous_strides(")
    end = tensor.index(b"\n}",start)+2
    (root/"tensor.rs").write_bytes(tensor[start:end])
    (root/"main.rs").write_text(driver)
    subprocess.run(["rustc","--edition=2024","-Awarnings","main.rs","-o","layout"],cwd=root,check=True)
    subprocess.run([str(root/"layout")],check=True)
