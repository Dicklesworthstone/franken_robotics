use fs_g1_train::ppo::{log_gaussian_prob, ppo_update, PolicyLogStd, PpoConfig, RunningNorm, Trajectory};
use fs_g1_train::transformer::{Config, GaitTransformer};

fn model() -> GaitTransformer {
    let config = Config { d_model: 4, n_heads: 1, head_dim: 4, n_kv_heads: 1,
        kv_dim: 4, n_layers: 1, mlp_hidden: 8, context: 4, n_inputs: 2, n_outputs: 1 };
    GaitTransformer::new(config, 0., 0.9, 0., &mut 7)
}

fn clipped_gradient(ratio: f32) {
    let mut model = model();
    model.policy_head.params.fill(0.0);
    model.value_w.params.fill(0.0);
    model.value_b.params[0] = 2.0;
    let mut scale = PolicyLogStd::new(1, 0., 0.);
    let config = PpoConfig { clip_ratio: 0.2, epochs_per_batch: 1, entropy_coef: 0.0,
        value_coef: 0.5, target_kl: None, ..PpoConfig::default() };
    let mut traj = Trajectory::new();
    traj.observations = vec![vec![1.,0.],vec![0.,1.]];
    traj.actions = vec![vec![0.],vec![1.]];
    traj.rewards = vec![0.,0.];
    traj.values = vec![0.,0.];
    traj.dones = vec![false,true];
    let old = vec![log_gaussian_prob(&[0.], &[0.], &[0.]).0-ratio.ln(),
                   log_gaussian_prob(&[0.], &[0.], &[1.]).0];
    ppo_update(&mut model,&RunningNorm::new(2),&mut scale,&traj,&[-1.,1.],&[0.,0.],&old,&config);
    let actual = scale.adam.grads[0] as f64;
    let independent_loss = |log_std: f64| {
        let advantage = [-1.0,1.0];
        let mut loss=0.0;
        for i in 0..2 {
            let a = i as f64;
            let r0 = if i == 0 {ratio as f64} else {1.0};
            let r = r0*(-log_std+0.5*a*a*(1.0-(-2.0*log_std).exp())).exp();
            loss -= 0.5*(r*advantage[i]).min(r.clamp(0.8,1.2)*advantage[i]);
        }
        loss
    };
    let eps = 1e-5;
    let fd = (independent_loss(eps)-independent_loss(-eps))/(2.*eps);
    let value_fd = ((2.0_f64+eps).powi(2)-(2.0_f64-eps).powi(2))/(4.*eps);
    let owner_critic = model.value_b.grads[0] as f64;
    println!("ratio={ratio:.2} PPO log_std gradient owner={actual:.6} finite_diff={fd:.6}; critic gradient owner={owner_critic:.6} finite_diff={value_fd:.6}");
    if ratio == 1. { assert!((actual-fd).abs()<1e-5); }
    else { assert!((actual-fd).abs()>0.2); }
    assert!((value_fd - 2.).abs()<1e-8 && owner_critic==0.);
}

fn reset_replay() {
    let mut model = model();
    // A transparent actor: embed the two labeled channels on e0/e1.
    // Q=K=0 produces uniform attention; V=O=I exposes the previous token.
    model.embed.params.fill(0.);
    model.embed.params[0] = 1.;
    model.embed.params[3] = 1.;
    let layer = &mut model.layers[0];
    layer.wq.weights.fill(0.);
    layer.wk.weights.fill(0.);
    layer.wv.weights.fill(0.);
    layer.wo.weights.fill(0.);
    layer.w_down.weights.fill(0.);
    for i in 0..4 {
        layer.wv.weights[5*i] = 1.;
        layer.wo.weights[5*i] = 1.;
    }
    model.policy_head.params = vec![1.,0.,0.,0.];
    let mut scale = PolicyLogStd::new(1,0.,0.);
    let mut traj = Trajectory::new();
    traj.observations = vec![vec![1.,0.], vec![0.,1.]];
    let mut old = Vec::new();
    for obs in &traj.observations {
        model.reset_cache();
        let (mean,value) = model.forward_step(obs,0);
        let action = vec![mean[0]+1.];
        old.push(log_gaussian_prob(&mean,&[0.],&action).0);
        traj.actions.push(action);
        traj.rewards.push(0.);
        traj.values.push(value);
        traj.dones.push(true);
    }
    let cfg = PpoConfig {epochs_per_batch:1, entropy_coef:0., value_coef:0., target_kl:None, ..PpoConfig::default()};
    let (joint_means,_,_) = model.forward_sequence_train(&traj.observations);
    let joint_ratio = (log_gaussian_prob(&joint_means[1],&[0.],&traj.actions[1]).0 - old[1]).exp();
    let owner = ppo_update(&mut model,&RunningNorm::new(2),&mut scale,&traj,&[-1.,1.],&[0.,0.],&old,&cfg);
    println!("two single-step episodes; frozen first-update mean abs log-ratio={owner:.6}, second replay ratio={joint_ratio:.6}; reset-correct reference=0.000000,1.000000");
    assert!(owner > 0.001 && (0.5*joint_ratio.ln().abs()-owner).abs()<1e-5);
}
fn main() {
    for r in [0.5,1.,2.] {clipped_gradient(r);}
    reset_replay();
}
