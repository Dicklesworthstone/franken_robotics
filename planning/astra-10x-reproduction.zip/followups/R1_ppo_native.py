"""Compile and call the pinned public owner with rustc and its checksum-locked libm source."""
import argparse
import hashlib
import subprocess
import tarfile
import tempfile
import tomllib
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--repo", type=Path, default=Path.home() / "projects/frankensim")
parser.add_argument("--cache", type=Path, default=Path.home() / ".cargo/registry/cache")
args = parser.parse_args()
pin = "483d09c682f24947008f2df43f53e6c3e1291c1e"
owner_crate = "crates/fs-g1-train/"
driver = Path(__file__).resolve().with_name("R1_ppo.rs")

def pinned(relative):
    return subprocess.check_output(["git", "show", f"{pin}:{owner_crate}{relative}"], cwd=args.repo)

required = next(pkg for pkg in tomllib.loads(pinned("Cargo.lock").decode())["package"] if pkg["name"] == "libm")
archive_name = "libm-" + required["version"]
archive = next(args.cache.glob(f"*/{archive_name}.crate"))
assert hashlib.sha256(archive.read_bytes()).hexdigest() == required["checksum"]
with tempfile.TemporaryDirectory() as directory:
    root = Path(directory)
    with tarfile.open(archive) as tar:
        tar.extractall(root, filter="data")
    manifest = tomllib.loads((root / archive_name / "Cargo.toml").read_text())
    compiler = ["rustc", "+nightly-2026-07-06", "-Awarnings"]
    subprocess.run(compiler + ["--edition",manifest["package"]["edition"],"--crate-name","libm",
                   "--crate-type","rlib",f"{archive_name}/src/lib.rs","-o","liblibm.rlib"],cwd=root,check=True)
    files = subprocess.check_output(["git","ls-tree","-r","--name-only",pin,owner_crate+"src"],cwd=args.repo,text=True).splitlines()
    for name in files:
        relative = name.removeprefix(owner_crate)
        path = root / relative
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(pinned(relative))
    subprocess.run(compiler + ["--edition=2021","--crate-name","fs_g1_train","--crate-type","rlib",
                   "src/lib.rs","--extern","libm=liblibm.rlib","-o","libfs_g1_train.rlib"],cwd=root,check=True)
    subprocess.run(compiler + ["--edition=2021","-L",".","--extern","fs_g1_train=libfs_g1_train.rlib",
                   str(driver),"-o","replay"],cwd=root,check=True)
    subprocess.run([str(root/"replay")],check=True)
