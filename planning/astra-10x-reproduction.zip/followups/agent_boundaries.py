"""Reference cases for writable views, modulo-angle sensing and invalid trial outcomes."""
from fractions import Fraction as F
from itertools import product

# Two worlds and two commands with an in-bounds, positive element stride on each axis.
addresses = {(world, channel): world + channel for world, channel in product(range(2), repeat=2)}
assert all(0 <= offset < 3 for offset in addresses.values())
assert addresses[0,1] == addresses[1,0]
def scatter(order):
    commands = [[2,7],[11,19]]
    out = [0]*3
    for world in order:
        for channel in range(2):
            out[addresses[world,channel]] = commands[world][channel]
    return out
assert scatter((0,1)) == [2,11,19]
assert scatter((1,0)) == [2,7,19]
print("overlapping writable view gives 11 or 7 at the shared element")

# A modulo-one-revolution POSITIONS sensor has no retained edge count. Its readings
# agree at every timestamp despite opposite directions. A single dropped sample also
# matters when qualifying the unwrapping bound against the delivered time gap.
sample_times = [F(t,100) for t in range(101)]
def angles(rate): return [(rate*t)%1 for t in sample_times]
assert angles(80) == angles(-20)
assert angles(50) == angles(-50)
gap = F(1,100)
err = F(1,200)
assert (48*gap + 2*err) < F(1,2)
assert (49*gap + 2*err) == F(1,2)
assert 48*(2*gap) + 2*err > F(1,2)
print("101 wrapped positions coincide at 80 and -20 turns/s; a dropped sample can defeat a previously valid unwrap bound")

# With binary mission success, unscored trials can range over both outcomes. The
# failure may depend on action choice. Success conditioned on solver completion
# can pick an inferior policy; the same observed rows also allow the other ranking.
safe = F(60,100)
complete_only = F(2,2)
possible = {F(2+i,100) for i in range(99)}
assert min(possible) == F(1,50) and max(possible)==1
assert min(possible) < safe < max(possible) and complete_only > safe
print("60/100 vs 2/2 with 98 invalid: candidate whole-cohort success lies in [0.02, 1]")
