"""Rigid-assembly, metric scene and SE(3) admission controls. Standard library only."""
import argparse
import ast
from decimal import Decimal as D
import hashlib
import io
import math
import os
from pathlib import Path
import re
import subprocess
import tarfile
import tempfile
import xml.etree.ElementTree as ET

SIM = "483d09c682f24947008f2df43f53e6c3e1291c1e"
URDF_BLOB = "ed990a66e6edc15cc398fdbf5be67b1f72e1e8ee"
OMITTED = {"head_link": D("1.036"), "logo_link": D("0.001"),
           "left_rubber_hand": D("0.170"), "right_rubber_hand": D("0.170")}

def mass_check(source=None, owner=None):
    # Symmetric left/right URDF rows are reported once per side.
    pelvis_and_torso = ["3.813", "0.214", "0.086", "6.78"]
    leg = ["1.35", "1.52", "1.702", "1.932", "0.074", "0.608"]
    arm = ["0.718", "0.643", "0.734", "0.6", "0.08544498", "0.48404956", "0.08457647"]
    retained = sum(map(D,pelvis_and_torso + 2*(leg+arm)))
    full = retained + sum(OMITTED.values())
    assert retained == D("31.96314202") and full == D("33.34014202")
    assert retained * D("9.81") < D("320") < full * D("9.81")
    print(f"G1 retained {retained} kg, full source {full} kg, gravity loads {retained*D('9.81'):.4f} vs {full*D('9.81'):.4f} N")
    if source is None:
        return
    raw = source.read_bytes()
    assert hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\x00"+raw).hexdigest()==URDF_BLOB
    tree = ET.fromstring(raw)
    masses = {link.get("name"):D(link.find("inertial/mass").get("value"))
              if link.find("inertial/mass") is not None else D(0) for link in tree.findall("link")}
    fixed = {joint.find("child").get("link") for joint in tree.findall("joint") if joint.get("type")=="fixed"}
    assert len(masses)==38 and len(fixed)==8
    assert {k:masses[k] for k in fixed if masses[k]} == OMITTED
    assert sum(masses.values())==full
    if owner:
        src=subprocess.check_output(["git","-C",str(owner),"show",SIM+":crates/fs-mbd/src/robot_models.rs"],text=True)
        body=src.split("const G1_LINKS: [SourceLink; 30] = ",1)[1].split("];",1)[0]+"]"
        rows=ast.literal_eval(re.sub(r"SourceLink::(?:revolute|fixed)\(", "(", body).replace("RobotJointMetadata::new(", "("))
        assert {row[0]:D(str(row[-3])) for row in rows} == {name:m for name,m in masses.items() if name not in fixed}
    print("Pinned source blob, per-link masses and eight fixed frames agree.")

def scene_check():
    scales = (2.,0.5,1.)
    radius = 0.15
    for axis, world_position, world_distance, expected_overlap in [(1,0.6,0.1,True),(0,2.2,0.2,False)]:
        local_distance = world_position/scales[axis]-1
        # Distance along either principal axis outside the ellipsoid is exact.
        actual = world_position-scales[axis]
        assert math.isclose(actual,world_distance)
        assert (actual<radius) == expected_overlap
        assert (local_distance<radius) != expected_overlap
        assert min(scales)*local_distance <= actual <= max(scales)*local_distance
        print(f"axis {axis}: local {local_distance:.2f}, world {actual:.2f}, probe radius {radius:.2f}")
    tangent=(2.,-.5)
    normal=(.5,2.)
    wrong=(2.,.5)
    assert sum(x*y for x,y in zip(tangent,normal)) == 0
    assert sum(x*y for x,y in zip(tangent,wrong)) == 3.75

def jacobian_check(owner):
    # [angular,linear] blocks: ad_xi has only a lower-left [p]_cross for pure translation.
    # Its square vanishes and the left/right dexp are I +/- ad_xi/2, determinant 1.
    distance = 33.
    h = 1e-4
    # Exp([yaw, (distance,0,0)]) follows a planar arc. Differentiate its y
    # translation, then shift the space twist to the world origin.
    def y(yaw):
        return distance * 2 * math.sin(yaw/2)**2 / yaw
    body_y = (y(h)-y(-h))/(2*h)
    space_y = body_y-distance
    assert math.isclose(body_y,16.5,abs_tol=2e-8) and math.isclose(space_y,-16.5,abs_tol=2e-8)
    print("33 m pure translation: exact left/right dexp on unit z rotation has linear y=-16.5/+16.5")
    if not owner:
        return
    driver = """
extern crate fs_ga;
use fs_ga::{Se3, Twist, Vec3};
fn main() {
    for distance in [1., 33.] {
        let t=Twist::new(Vec3::new(0.,0.,0.), Vec3::new(distance,0.,0.));
        let moved=Se3::exp(t).unwrap().translation();
        assert!((moved.x-distance).abs()<1e-12);
        let (l,r)=(Se3::left_jacobian(t),Se3::right_jacobian(t));
        if distance==1. {
            assert_eq!(l.unwrap().matrix.m[4*6+2],-0.5);
            assert_eq!(r.unwrap().matrix.m[4*6+2],0.5);
        } else {
            for result in [l,r] {
                assert!(matches!(result,Err(fs_ga::GaError::IllConditioned {measure:33.,limit:32.,..})));
            }
        }
        println!("owner pure translation {} m: exponential accepted; Jacobian accepted {}",distance,distance==1.);
    }
}
"""
    with tempfile.TemporaryDirectory(prefix="astra-catalog-") as tmp:
        root=Path(tmp)
        packed=subprocess.check_output(["git","-C",str(owner),"archive",SIM,"crates/fs-ga/src","crates/fs-math/src"])
        with tarfile.open(fileobj=io.BytesIO(packed)) as archive:
            archive.extractall(root,filter="data")
        (root/"driver.rs").write_text(driver)
        cmd=["rustc","+nightly-2026-07-06","-Awarnings","--edition=2024"]
        env={**os.environ,"CARGO_PKG_VERSION":"0.1.0"}
        def run(args):
            subprocess.run(cmd+args, cwd=root, env=env, check=True)
        run(["--crate-name","fs_math","--crate-type","rlib","crates/fs-math/src/lib.rs","-o","libfs_math.rlib"])
        run(["--crate-name","fs_ga","--crate-type","rlib","--extern","fs_math=libfs_math.rlib","crates/fs-ga/src/lib.rs","-o","libfs_ga.rlib"])
        run(["-L","dependency=.","--extern","fs_ga=libfs_ga.rlib","driver.rs","-o","probe"])
        subprocess.run([str(root/"probe")],check=True)

if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--urdf",type=Path)
    parser.add_argument("--frankensim",type=Path)
    args=parser.parse_args()
    mass_check(args.urdf,args.frankensim)
    scene_check()
    jacobian_check(args.frankensim)
