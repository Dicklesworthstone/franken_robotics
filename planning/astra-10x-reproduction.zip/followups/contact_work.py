"""Independent limiting cases for wheel admission, support work, force sensing, and sole yaw.

All force cutoffs here belong to the specified fixtures. No case approximates a full
cart crossing or a controller on a physical quadruped.
"""
from fractions import Fraction as F
from math import hypot, isclose, sqrt
from itertools import product


def wheel(radius, friction, maximum_torque):
    height, load = 0.012, 25.0
    horizontal = sqrt(2 * radius * height - height * height)
    vertical = radius - height
    # Center is behind and above the lip. Contact must push upward at zero axle push.
    normal = (-horizontal / radius, vertical / radius)
    tangent = (vertical / radius, horizontal / radius)
    contact = (0.0, load)
    normal_reaction = sum(f * u for f, u in zip(contact, normal))
    tangent_reaction = sum(f * u for f, u in zip(contact, tangent))
    clockwise_torque = load * horizontal
    assert isclose(hypot(normal_reaction, tangent_reaction), load)
    assert isclose(tangent_reaction * radius, clockwise_torque)
    supported = normal_reaction >= 0 and abs(tangent_reaction) <= friction * normal_reaction
    return horizontal / vertical, clockwise_torque, supported and clockwise_torque <= maximum_torque


def support_heat(ticks):
    # A 1 kg supported block, g=8 m/s², zero restitution/friction, one second.
    step = F(1, ticks)
    velocity = F(0)
    dissipation = F(0)
    gravity_work = F(0)
    real_displacement = F(0)
    for _ in range(ticks):
        free_velocity = velocity - 8 * step
        impulse = -free_velocity
        new_velocity = free_velocity + impulse
        gravity_work += -8 * step * (velocity + free_velocity) / 2
        dissipation += (free_velocity**2 - new_velocity**2) / 2
        real_displacement += new_velocity * step
        velocity = new_velocity
    assert gravity_work - dissipation == 0 and real_displacement == velocity == 0
    assert dissipation == F(32, ticks)
    return dissipation, -8 * real_displacement


def force_window(width):
    # Ideal rectangular contact force wholly inside a 20 ms exposure; force in N.
    exposure, impulse, clipping = F(1, 50), F(1), F(200)
    peak = impulse / width
    average = peak * width / exposure
    clip_first = min(clipping, peak) * width / exposure
    clip_last = min(clipping, average)
    return peak, average, clip_first, clip_last


def wrench_cases(low, high, normal):
    # Two point contacts, x=0, y=-/+0.02 m, fixed equal normals, no independent couples.
    # Lateral force has no yaw moment since x=0. Zero lateral forces attain the force bounds.
    a = F(1, 50)
    cap1, cap2 = low * normal/2, high * normal/2
    vertices = list(product((-cap1, cap1), (-cap2, cap2)))
    largest = max(f1+f2 for f1, f2 in vertices)
    net_yaw_at_largest = a * (cap1-cap2)
    # The line a*(f1-f2)=0 cuts the box at +/-min(cap1,cap2) on both coordinates.
    zero_yaw_max = max(2*v for v in (-min(cap1,cap2),min(cap1,cap2)))
    return largest, net_yaw_at_largest, zero_yaw_max


def main():
    for friction, cap, expected in [(0.70, 1.2, (False,True)), (0.80, 0.95, (True,False))]:
        answers = [wheel(r,friction,cap) for r in (0.060,0.075)]
        assert tuple(a[2] for a in answers) == expected
        print(f"lip mu={friction} limit={cap}: " + ", ".join(
            f"mu_min={mu:.6f} torque={torque:.6f} admit={ok}" for mu,torque,ok in answers))
    print("stationary support impulse losses at 32/64 Hz, physical gravity work:",
          support_heat(32), support_heat(64))
    short, long = force_window(F(1,1000)), force_window(F(1,100))
    assert short == (1000,50,10,50) and long == (100,50,50,50)
    print("force pulses (peak, exposure mean, clip then mean, mean then clip):",
          tuple(map(int,short)), tuple(map(int,long)))
    split, uniform = wrench_cases(F(1,4),F(4,5),F(100)), wrench_cases(F(2,5),F(2,5),F(100))
    assert split == (F(105,2),F(-11,20),25) and uniform == (40,0,40)
    print("patches (forward force N, yaw at maximum N m, zero-yaw force N):",split,uniform)


if __name__ == "__main__":
    main()
