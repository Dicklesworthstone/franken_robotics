"""Exact decision counterexamples for the Astra mission studio. Standard library only."""

from fractions import Fraction as F
from itertools import combinations, product
from math import sqrt


U = F(3, 4)
NOISE = F(1, 64)


def terminal(gain, commands):
    position = speed = F(0)
    for command in commands:
        assert abs(command) <= U
        acceleration = gain * command
        position += speed + acceleration / 2
        speed += acceleration
    return position, speed


def check_docking():
    # Any nonpositive probe leaves the gain-one position at most U at exact rest.
    # For 0 <= p <= U, terminal rest permits scaled displacement c in [2p-U,p+U].
    # All gains compatible with a packet share c; for [a,b] their preferred center
    # is 2/(a+b) with minimax error (b-a)/(b+a).  The worst unbounded-center
    # value is attained at the lowest gain with the widest compatible interval.
    def sharp_sign(delta):
        return 16 * delta**2 + 41 * delta - 1

    two_cm, two_and_a_half_cm = F(1, 50), F(1, 40)
    assert sharp_sign(two_cm) < 0 < sharp_sign(two_and_a_half_cm)
    # In the neighborhood delta < 1/4: probe must separate enough gains,
    # drive the gain-one destination, and remain able to brake the gain-two case.
    def probe_bounds(delta):
        low = max(NOISE * (1 - delta) / delta, 1 - delta - U)
        high = min(U, (1 + delta + 2 * U) / 4)
        return low, high

    assert probe_bounds(two_cm)[0] > probe_bounds(two_cm)[1]
    probe = F(5, 8)
    lo, hi = probe_bounds(two_and_a_half_cm)
    assert lo <= probe <= hi
    # Execute a selected causal policy through raw tick transitions at all
    # piecewise-rational envelope endpoints and additional interior observations.
    critical = {probe - NOISE, probe + NOISE, 2 * probe - NOISE, 2 * probe + NOISE}
    packets = sorted(critical | {probe - NOISE + i * (probe + 2 * NOISE) / 128 for i in range(129)})
    max_error = F(0)
    for reading in packets:
        g_min = max(F(1), (reading - NOISE) / probe)
        g_max = min(F(2), (reading + NOISE) / probe)
        assert g_min <= g_max
        c = min(probe + U, max(2 * probe - U, 2 / (g_min + g_max)))
        second = c - 2 * probe
        commands = (probe, second, -probe - second)
        for gain in (g_min, (g_min + g_max) / 2, g_max):
            x, v = terminal(gain, commands)
            assert v == 0 and abs(x - 1) <= two_and_a_half_cm
            max_error = max(max_error, abs(x - 1))
    assert max_error == F(1, 41)
    # The two lower bounds are tight together at the positive root.
    lower, upper = F(24162410887838, 10**15), F(24162410887839, 10**15)
    assert sharp_sign(lower) < 0 < sharp_sign(upper)
    optimum = (sqrt(1745) - 41) / 32
    winning_probe = (39 + sqrt(1745)) / 128
    print(f"continuous gain [1,2], exact rest: optimal probe {winning_probe:.12f}, error {optimum:.12f} m")
    print(f"2 cm impossible; 2.5 cm feasible; explicit 5/8 probe worst error {max_error} m")


def received(word, failure):
    if failure == "clean":
        return {word}
    if failure == "erasure":
        return {word} | {
            word[:index] + ("?",) + word[index + 1:] for index in range(len(word))
        }
    if failure == "flip":
        return {word} | {
            word[:index] + (1 - bit,) + word[index + 1:] for index, bit in enumerate(word)
        }
    raise ValueError(failure)


def check_channel():
    # The three exogenous public histories conflict on AB, BC and CA respectively.
    # If two words collide, the remaining history picks a case demanding opposite bits.
    for failure, expected in (("clean", 2), ("erasure", 3), ("flip", 5)):
        for nbits in range(1, expected + 1):
            words = list(product((0, 1), repeat=nbits))
            outcomes = {word: received(word, failure) for word in words}
            witness = next((triple for triple in combinations(words, 3)
                            if all(outcomes[left].isdisjoint(outcomes[right])
                                   for left, right in combinations(triple, 2))), None)
            assert (witness is not None) == (nbits == expected)
        print(f"3 factory labels, {failure}: minimum {expected} precommit bits")


def check_frontier():
    strategies = ((0, 6), (4, 4), (6, 0))
    front = {s for s in strategies if not any(
        t != s and all(a <= b for a, b in zip(t, s)) for t in strategies
    )}
    assert front == set(strategies)
    # Equal weight gives the largest possible winning weighted value (3).
    # The two extreme strategies average to (3,3), which scores below (4,4)
    # for every nonnegative normalized weighting, inclusive of both endpoints.
    assert tuple((a + b) / 2 for a, b in zip(strategies[0], strategies[2])) == (3, 3)
    for budget, selected in ((0, (6, 0)), (4, (4, 4)), (6, (0, 6))):
        assert min(s for s in strategies if s[1] <= budget) == selected
    print("3 nondominated plans, 2 attainable by linear scalarization, budget 4 selects the omitted plan")


if __name__ == "__main__":
    check_docking()
    check_channel()
    check_frontier()
