"""Independent challenge of the fixed-horizon, tag and Pareto findings (requires z3 CLI)."""
from itertools import combinations
from subprocess import run


def solve(declarations, conditions, expectation):
    code = "(set-logic QF_NRA)\n" + "".join(
        f"(declare-const {v} Real)\n" for v in declarations.split()
    ) + "\n".join(f"(assert {form})" for form in conditions) + "\n(check-sat)\n"
    result = run(["z3", "-in"], input=code, text=True, capture_output=True, check=True)
    assert result.stdout.strip() == expectation, result


U = "(/ 3 4)"
E2 = "(/ 1 32)"


def abs_within(z, bound):
    return f"(and (<= (- {bound}) {z}) (<= {z} {bound}))"


def raw_terminal(gain, u, last):
    # Total displacement after three constant-acceleration holds of one second,
    # computed by superposition of the held accelerations. Keep both commands.
    x3 = f"(* {gain} (/ (+ (* 5 p) (* 3 {u}) {last}) 2))"
    v3 = f"(* {gain} (+ p {u} {last}))"
    return [f"(= {v3} 0)", abs_within(f"(- {x3} 1)", "d")]


def necessary_below_threshold():
    # The reader must distinguish only three mandatory histories here. Giving it
    # extra freedom to choose the third pair of commands can only help.
    shared = (f"(ite (<= (* (ite (< p 0) (- p) p) 1) {E2}) (= h 2) "
              f"(= (* (ite (< p 0) (- p) p) (- h 1)) {E2}))")
    constraints = [
        "(>= d 0)", "(< (+ (* 16 d d) (* 41 d) -1) 0)",
        "(<= 1 h)", "(<= h 2)", shared,
        *[abs_within(name, U) for name in ("p", "u", "a", "w", "b")],
        *raw_terminal("1", "u", "a"), *raw_terminal("h", "u", "a"), *raw_terminal("2", "w", "b")
    ]
    # p ranges over ALL [-3/4,+3/4], including zero and all negative probes.
    solve("p d h u a w b", constraints, "unsat")


def sufficient_at_threshold(threshold, probe):
    # One common reading y admits g and h. For final rest and a candidate second
    # command u, each one-dimensional actuator/position constraint is an interval.
    # Empty intersection of any number requires two incompatible endpoints.
    # g may supply the lower endpoint and h the upper. Search for an obstruction.
    decreases = [f"(- {U})", f"(- 0 p {U})", "(- (/ (- 1 d) g) (* 2 p))"]
    increases = [U, f"(- {U} p)", "(- (/ (+ 1 d) h) (* 2 p))"]
    obstruction = "(or " + " ".join(f"(> {lo} {hi})" for lo in decreases for hi in increases) + ")"
    solve("p d g h y",
          [threshold, probe, "(> d 0)", "(<= 1 g)", "(<= g h)", "(<= h 2)",
           abs_within("(- y (* p g))", "(/ 1 64)"),
           abs_within("(- y (* p h))", "(/ 1 64)"), obstruction], "unsat")


def tag_channel():
    def outputs(word, length, mode):
        if mode == "clean":
            return {word}
        if mode == "flip":
            return {word} | {word ^ (1 << k) for k in range(length)}
        # Output includes the erased position and the surviving bits; at most one.
        return {(None, word)} | {(k, word & ~(1 << k)) for k in range(length)}
    answer = []
    for mode in ("clean", "erasure", "flip"):
        for n in range(1, 6):
            sets = [outputs(w, n, mode) for w in range(1 << n)]
            valid = [pair for pair in combinations(range(1, 1 << n), 2)
                     if not sets[0] & sets[pair[0]] and not sets[0] & sets[pair[1]]
                     and not sets[pair[0]] & sets[pair[1]]]
            if valid:
                answer.append(n)
                break
    assert answer == [2, 3, 5]
    print("three-label receiver-set exhaustive minimum lengths (clean, erasure, flip)", answer)


def pareto():
    options = [(0,6),(4,4),(6,0)]
    costs = [min((b,a) for a,b in options if a <= budget) for budget in range(7)]
    assert costs == [(6,0)]*4 + [(4,4)]*2 + [(0,6)]
    solve("w", ["(<= 0 w)", "(<= w 1)", "(<= 4 (* 6 w))", "(<= 4 (* 6 (- 1 w)))"], "unsat")
    print("budget-optimal facility/body points", [entry[::-1] for entry in costs])


if __name__ == "__main__":
    necessary_below_threshold()
    sufficient_at_threshold("(= (+ (* 16 d d) (* 41 d) -1) 0)", "(= p (+ (/ 5 8) (/ d 4)))")
    sufficient_at_threshold("(= d (/ 1 40))", "(= p (/ 5 8))")
    print("raw terminal equations UNSAT below positive root; interval-obstruction UNSAT at root and at 25 mm with p=5/8")
    tag_channel()
    pareto()
