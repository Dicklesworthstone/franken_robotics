"""Check which hidden-gain supports the scalar docking classifier can certify."""
from fractions import Fraction
import subprocess

HALF = 1 << 27


def compare_corpus(scale):
    positives = ambiguous = 0
    for n in range(65536):
        u = HALF + (n * 65537) % (HALF + 1)
        e = (u + HALF) // 4 + (n % 9 - 4) * scale
        positives += 4 * e < u + HALF
        # |p| <= U implies that the centers from 1 and 33/32 differ by at
        # most U/32. Each closed observation interval has radius epsilon.
        ambiguous += u <= 64 * e
    assert (positives, ambiguous) == (34590, 65536)
    print(f"scale {scale}: nominal positives {positives}/65536; "
          f"rows forcing ambiguous close gains for every first pulse {ambiguous}/65536")


def smt_checks():
    # Recursive zero-order-hold kinematics. The same late commands q and r
    # apply at the shared reading, since this mission has no further packet.
    plant = """
(set-logic QF_LRA)
(declare-const p Real)
(declare-const q Real)
(declare-const r Real)
(define-fun ab ((x Real)) Real (ite (< x 0) (- x) x))
(define-fun xstep ((x Real) (v Real) (a Real)) Real (+ x v (/ a 2)))
(define-fun x3 ((a Real) (b Real) (c Real)) Real
  (xstep (xstep (xstep 0 0 a) a b) (+ a b) c))
(define-fun x1 () Real (x3 p q r))
(define-fun x2 () Real (x3 (* (/ 33 32) p) (* (/ 33 32) q) (* (/ 33 32) r)))
(define-fun v1 () Real (+ p q r))
(define-fun v2 () Real (* (/ 33 32) (+ p q r)))
(assert (and (<= (ab p) (/ 3 4)) (<= (ab q) (/ 3 4)) (<= (ab r) (/ 3 4))))
"""
    tests = [
        ("a first command avoiding this midpoint", """
(define-fun y () Real (* (/ 65 64) p))
(assert (or (> (ab (- y p)) (/ 1 64))
            (> (ab (- y (* (/ 33 32) p))) (/ 1 64))))""", "unsat"),
        ("common exact docking", "(assert (and (= x1 1) (= x2 1) (= v1 0) (= v2 0)))", "unsat"),
        ("common position error strictly under 1/65", """
(assert (and (< (ab (- x1 1)) (/ 1 65)) (< (ab (- x2 1)) (/ 1 65))))""", "unsat"),
        ("bound attained for close pair at zero final velocity", """
(assert (and (= v1 0) (= v2 0) (= p (/ 1 2))
             (<= (ab (- x1 1)) (/ 1 65)) (<= (ab (- x2 1)) (/ 1 65))))""", "sat"),
    ]
    for name, condition, expected in tests:
        result = subprocess.run(["z3", "-T:5", "-in"], input=plant + condition + "\n(check-sat)\n",
                                text=True, capture_output=True, check=True, timeout=8)
        if result.stdout.strip() != expected:
            raise ValueError(f"{name}: {result.stdout!r}")
        print(f"{name}: {expected}")


if __name__ == "__main__":
    assert Fraction(1, 64) < (Fraction(3, 4) + Fraction(1, 2)) / 4
    smt_checks()
    for spacing in (1, 2048):
        compare_corpus(spacing)
