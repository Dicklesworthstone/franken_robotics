"""Replay the 75 mm sharp-edge triplet on three numerical profiles with a 1 ms scorer clock."""
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from tempfile import TemporaryDirectory
import math

ROOT = Path(__file__).resolve().parents[1]


def run():
    source = (ROOT / "sill/planar_sill_pilot.py").read_text()
    clock = "if n < n_settle or n % 20:"
    if source.count(clock) != 1:
        raise ValueError("Historical event sampling line changed")
    cases = [dict(rf=0.075, rho=0.0, pdx=-0.04, mu=mu) for mu in (0.500, 0.525, 0.550)]
    profiles = (
        (50e-6, 200_000, 2000, ["success", "timeout", "success"]),
        (25e-6, 200_000, 2000, ["timeout", "timeout", "success"]),
        (25e-6, 400_000, 2828, ["success", "success", "success"]),
    )
    with TemporaryDirectory() as temp:
        for index, (dt, stiffness, damping, expected) in enumerate(profiles):
            strides = round(0.001 / dt)
            assert math.isclose(strides*dt, 0.001)
            module_path = Path(temp) / f"profile{index}.py"
            module_path.write_text(source.replace(clock, f"if n < n_settle or n % {strides}:"))
            spec = spec_from_file_location(f"profile{index}", module_path)
            model = module_from_spec(spec)
            spec.loader.exec_module(model)
            result = model.simulate(cases, dt=dt, k=stiffness, cn=damping)
            if result["outcome"] != expected:
                raise ValueError(f"Wheel boundary triplet changed at {(dt, stiffness, damping)}")
            print(f"{dt*1e6:.0f} us, {stiffness} N/m, {damping} N s/m: {result['outcome']}")


if __name__ == "__main__":
    run()
