"""Exact stride-map composition and battery fixed-point acceptance controls."""
from fractions import Fraction as Q
from math import sqrt

def stride_a(x):
    u,v=x
    return (u/2+v,v/2)

def stride_b(x):
    u,v=x
    return (u/2,u+v/2)

def gait():
    x=(Q(1,2),Q(1))
    # A and B are upper/lower triangular with identical diagonal (1/2,1/2).
    # The identical maps repeat only within their original contact history.
    for step in [stride_a,stride_b]:
        fixed=x
        for _ in range(24):
            fixed=step(fixed)
        assert max(fixed)<Q(1,10000)
    combined=stride_b(stride_a(x))
    assert combined==(Q(5,8),Q(3,2))
    assert all(v>=Q(5,4)*u for u,v in zip(x,combined))
    # The two-step matrix has nonnegative entries, so the inequality iterates.
    pert=x
    for _ in range(8):
        pert=stride_b(stride_a(pert))
    assert all(v>=Q(5,4)**8*u for u,v in zip(x,pert))
    print(f"fixed-mode stride multipliers both 1/2; alternating two-stride multiplier {0.75+sqrt(0.5):.9f}")

def resource():
    # 1 kg of base pack capacity plus 0.99 kg of required pack per kg carried.
    demand=lambda pack: 1 + Q(99,100)*pack
    lower=Q(199,2)
    remaining=demand(lower)-lower
    assert remaining==Q(1,200) and demand(lower)>lower
    smallest=Q(1)/(1-Q(99,100))
    assert smallest==100 and smallest-lower==Q(1,2)
    assert demand(smallest)==smallest
    # An actual upper certificate U must satisfy demand(U) <= U.
    assert demand(101)<=101
    print(f"99.5 kg iterate misses per-update load by {remaining} kg and required capacity by {smallest-lower} kg; minimum {smallest} kg")

if __name__=="__main__":
    gait()
    resource()
