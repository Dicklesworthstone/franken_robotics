"""Independent exact checks of sensor timing, mechanical measurements and ray distances."""
import argparse
import io
from fractions import Fraction as F
from pathlib import Path
import subprocess
import tarfile
import tempfile

THREED_PIN = "bf7abe16367e0f2ea3194ff40c59a6e80dcb77e2"


def integrated_accelerometer():
    # Point velocity increases discontinuously at impact. Before/after it the
    # smooth world acceleration is gravity. The mounting axes are fixed here.
    gravity = -F(981, 100)
    half_exposure = F(1, 200)
    exposure = 2 * half_exposure
    v_minus, v_plus = F(-1), F(1)
    v_open = v_minus - gravity * half_exposure
    v_close = v_plus + gravity * half_exposure
    smooth_mean = gravity - gravity
    ideal_mean = (v_close - v_open) / exposure - gravity
    assert smooth_mean == 0
    assert ideal_mean == smooth_mean + (v_plus - v_minus) / exposure == 200
    # No reset: exact ideal ballistic control. With a purely angular jump,
    # a 0.2 m x-arm sees 0.6 m/s along y, while the origin sees no jump.
    v_close_ballistic = v_minus + gravity * half_exposure
    assert (v_close_ballistic - v_open) / exposure - gravity == 0
    assert F(1, 5) * 3 == F(3, 5)
    print("10 ms ideal specific-force mean: smooth 0; integrated rebound +200 m/s^2")


def cut_wrench():
    gravity = -F(981, 100)
    mass = F(2)

    def distal_on_parent(contact_up, acceleration_up):
        return contact_up + mass * gravity - mass * acceleration_up

    assert distal_on_parent(100, 0) == F(8038, 100)
    assert distal_on_parent(0, 2) == -F(2362, 100)
    assert distal_on_parent(0, gravity) == 0
    # RNEA sign cross-check through the force on the distal free body.
    for f, a in ((100, 0), (0, 2), (0, gravity)):
        assert -distal_on_parent(f, a) + f + mass * gravity == mass * a
    print("distal-on-proximal loads: +80.38 N supported; -23.62 N in upward swing")


def calibration():
    # A planar target is fixed at world x=10. A sensor points forward without rotation.
    # The capture event is at reported time plus delta. The mount is ahead by b.
    def read(timestamp, velocity, delta, b):
        return 10 - velocity * (timestamp + delta) - b

    delayed = (F(1, 50), F(0))
    advanced_mount = (F(0), F(1, 25))
    timestamps = [F(i, 100) for i in range(101)]
    assert all(read(t, 2, *delayed) == read(t, 2, *advanced_mount) for t in timestamps)
    assert all(read(t, -2, *delayed) - read(t, -2, *advanced_mount) == F(2, 25)
               for t in timestamps)
    assert read(0, 0, *delayed) - read(0, 0, *advanced_mount) == F(1, 25)
    print("time offset vs mount offset: 101 identical forward samples; reverse separates by 80 mm")


def range_units():
    world_x = (F(2), F(3))
    scale_x = (F(1, 2), F(3))
    local_hits = tuple(x / scale for x, scale in zip(world_x, scale_x))
    assert local_hits == (4, 1)
    assert min(range(2), key=local_hits.__getitem__) == 1
    assert min(range(2), key=world_x.__getitem__) == 0
    assert [x <= F(5, 2) for x in world_x] == [True, False]
    assert [x <= F(5, 2) for x in local_hits] == [False, True]
    print("opaque planes: normalized local hit distances 4, 1; world ranges 2, 3 m")


RUST_EXAMPLE = """
use f3d_math::{Matrix4, Plane, Ray, Vector3};

fn main() {
    let world_ray = Ray::new(Vector3::zero(), Vector3::new(1.0, 0.0, 0.0));
    let mut hits = Vec::new();
    for (world_x, scale) in [(2.0, 0.5), (3.0, 3.0), (2.0, 1.0)] {
        let mut world_from_object = Matrix4::default();
        world_from_object.make_scale(scale, 1.0, 1.0);
        let mut object_from_world = world_from_object;
        object_from_world.invert();
        let mut local_ray = world_ray;
        local_ray.apply_matrix4(&object_from_world);
        assert_eq!(local_ray.direction, Vector3::new(1.0, 0.0, 0.0));
        let local_plane = Plane::new(Vector3::new(-1.0, 0.0, 0.0), world_x / scale);
        let local_t = local_ray.distance_to_plane(&local_plane).unwrap();
        let mut hit = local_ray.intersect_plane(&local_plane).unwrap();
        hit.apply_matrix4(&world_from_object);
        let world_range = hit.distance_to(&world_ray.origin);
        assert_eq!(world_range, world_x);
        hits.push((local_t, world_range));
    }
    assert_eq!(hits, vec![(4.0, 2.0), (1.0, 3.0), (2.0, 2.0)]);
    println!("pinned f3d-math (local t, world m): {:?}", hits);
}
"""


def verify_owner(owner):
    source_paths = ("crates/f3d-core/src", "crates/f3d-math/src")
    payload = subprocess.check_output(["git", "-C", str(owner), "archive", "--format=tar",
                                       THREED_PIN, *source_paths])
    with tempfile.TemporaryDirectory() as temp:
        root = Path(temp)
        with tarfile.open(fileobj=io.BytesIO(payload)) as archive:
            archive.extractall(root, filter="data")
        # The owner pins the dated nightly and both original crates are dependency-free
        # in this std profile (f3d-math depends on f3d-core). No working tree is edited.
        rustc = ["rustc", "+nightly-2026-08-31", "--edition=2024"]
        for crate in ("f3d_core", "f3d_math"):
            source = root / "crates" / crate.replace("_", "-") / "src" / "lib.rs"
            cmd = [*rustc, "--crate-name", crate, "--crate-type", "rlib", "--cfg", 'feature="std"',
                   str(source), "--out-dir", str(root)]
            if crate == "f3d_math":
                cmd += ["--extern", f"f3d_core={root / 'libf3d_core.rlib'}"]
            subprocess.run(cmd, check=True)
        example = root / "sensor.rs"
        example.write_text(RUST_EXAMPLE)
        exe = root / "sensor"
        subprocess.run([*rustc, str(example), "-L", str(root), "--extern",
                        f"f3d_math={root / 'libf3d_math.rlib'}", "-o", str(exe)], check=True)
        subprocess.run([str(exe)], check=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--franken-threed", type=Path, help="checkout containing the pinned git object")
    options = parser.parse_args()
    integrated_accelerometer()
    cut_wrench()
    calibration()
    range_units()
    if options.franken_threed is not None:
        verify_owner(options.franken_threed)
