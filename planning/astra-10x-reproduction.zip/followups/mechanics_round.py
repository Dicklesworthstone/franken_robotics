#!/usr/bin/env python3
"""Design and numerical integration fixtures. Optional --frankensim PATH compiles an isolated pinned assembler and broad-phase probe."""
import argparse
from fractions import Fraction
import math
from pathlib import Path
import subprocess
import tempfile

PIN = "483d09c682f24947008f2df43f53e6c3e1291c1e"

def differential():
    # Motor angle 10(q1+q2), ideal transmission, motor fixed to the base.
    n = 10
    inertia, torque_limit = Fraction(1, 100), Fraction(1, 10)
    def joint_torque(motor_torque):
        return (n * motor_torque, n * motor_torque)
    for torque in (-torque_limit, Fraction(0), torque_limit):
        for rates in [(1, -1), (1, 1), (2, -3)]:
            shaft_rate = n * sum(rates)
            efforts = joint_torque(torque)
            assert sum(x*y for x, y in zip(efforts, rates)) == torque * shaft_rate
    def feasible(target):
        motor_torque = Fraction(target[0], n)
        return abs(motor_torque) <= torque_limit and joint_torque(motor_torque) == target
    assert feasible((1, 1)) and not feasible((1, -1))
    axis_inertia = inertia * n*n
    for rates, expected in [((1, -1), 0), ((1, 1), 2)]:
        physical = inertia * (n*sum(rates))**2 / 2
        lost_cross_term = axis_inertia * sum(x*x for x in rates)/2
        assert physical == expected and lost_cross_term == 1
    print("transmission: (1,1) Nm feasible, (1,-1) infeasible; rotor energy 0/2 J at differential/common rates, diagonal model 1/1 J")

def sample_and_hold():
    mass, initial_speed = Fraction(1), Fraction(1)
    step = Fraction(1, 100)
    for damping, expected in [(100, Fraction(-1, 2)), (200, 0), (300, Fraction(3, 2))]:
        force = -damping * initial_speed
        final_speed = initial_speed + step*force/mass
        travel = step * (initial_speed + final_speed)/2
        work = force * travel
        assert work == expected == mass * (final_speed**2 - initial_speed**2)/2
        if damping == 300:
            assert force * initial_speed * step == -3 and final_speed == -2
    print("held damper: left-endpoint predicted work -3 J, exact work +1.5 J, final speed -2 m/s; bh/m = 2 is zero net work")

def swept_arm():
    # A 1 m link sweeps from -60 to +60 degrees. Its spherical tip passes (1,0).
    tip_radius = Fraction(1, 20)
    stop_radius = Fraction(1, 20)
    endpoint_tip_x = Fraction(1, 2)
    stop_x = 1
    assert endpoint_tip_x + tip_radius < stop_x - stop_radius
    assert math.hypot(1.0-0.5, math.sqrt(3)/2) > float(tip_radius + stop_radius)
    assert 1 - endpoint_tip_x == Fraction(1,2)
    assert Fraction(1) >= stop_x - stop_radius
    # For 0 <= angular extent <= pi, r*(1-cos(delta/2)) bounds arc distance from its chord.
    for i in range(121):
        a = math.radians(i-60)
        assert 0 <= max(0.0, math.cos(a) - 0.5) <= 0.5
    print("rotating tip: a straight chord's maximum x with 5 cm tip padding is 0.55 m; the mid-arc tip center hits (1,0), sagitta 0.5 m")

def port_sign():
    effort = (2, 3)
    def field(r):
        return (r * effort[1], -r * effort[0])
    for ratio, expected in [(4,(12,-8)),(-4,(-12,8))]:
        q = field(ratio)
        assert q == expected and sum(x*y for x, y in zip(q,effort)) == 0
    print("power port: both orientations conserve energy; the labeled effort (2,3) gives opposite derivatives (12,-8) / (-12,8)")

RUST = r"""
extern crate self as fs_geom;
mod broad_phase;
mod interconnection;
use interconnection::{InterconnectionBudget, transformer, interconnect_mapped};
use broad_phase::{swept_sphere_aabb, sweep_candidates, SweepItem, SweepConfig};

// Unit-test carriers for the original interconnection module. They simply retain
// assembled J,R,G. No dynamic integrator or physical admission logic is modeled.
#[derive(Debug)]
pub enum PhsError { BadPortPairing, Dimension{what:&'static str}, Unadmitted{what:&'static str} }
pub struct PortHamiltonian {
    n:usize, m:usize, j:Vec<f64>, r:Vec<f64>, g:Vec<f64>,
    storage:Box<dyn std::any::Any>, resistance_witness:Option<()>,
}
pub struct SumStorage {
    a:(Box<dyn std::any::Any>,usize), b:(Box<dyn std::any::Any>,usize)
}
fn compose_resistance_witness(_systems:&[&PortHamiltonian],_n:usize,_r:&[f64])->Result<Option<()>,PhsError>{ Ok(None) }
impl PortHamiltonian {
    fn new(n:usize,m:usize,j:Vec<f64>,r:Vec<f64>,g:Vec<f64>,storage:Box<dyn std::any::Any>)->Result<Self,PhsError>{
        Ok(Self{n,m,j,r,g,storage,resistance_witness:None})
    }
}
fn unit()->PortHamiltonian {
    PortHamiltonian::new(1,1,vec![0.],vec![0.],vec![1.],Box::new(())).unwrap()
}
fn mapped(r: f64) -> PortHamiltonian {
    let budget=InterconnectionBudget{max_states:2,max_total_ports:2,max_dense_bytes:10000,max_coupling_multiply_terms:10000};
    interconnect_mapped(unit(),unit(),&[0],&[0],&[r],budget).unwrap()
}
fn main(){
    for (s,expected) in [(transformer(unit(),unit(),0,0,4.).unwrap(),[12.,-8.]),
                         (mapped(4.),[-12.,8.]),(mapped(-4.),[12.,-8.])]{
        assert_eq!(s.j.len(),4);
        let vel=[s.j[0]*2.+s.j[1]*3.,s.j[2]*2.+s.j[3]*3.];
        assert_eq!(vel,expected);
        let power=2.*vel[0]+3.*vel[1];
        assert_eq!(power,0.);
        println!("pinned port field {vel:?}, net power {power}");
    }
    let y=3.0_f64.sqrt()/2.;
    let block=swept_sphere_aabb([1.,0.,0.],[1.,0.,0.],0.05,0.).unwrap();
    for (pad,n) in [(0.,0), (0.5,1)]{
        let arm=swept_sphere_aabb([0.5,-y,0.],[0.5,y,0.],0.05,pad).unwrap();
        let items=[SweepItem{id:0,bounds:arm},SweepItem{id:1,bounds:block}];
        let report=sweep_candidates(&items,SweepConfig{max_candidates:1,max_comparisons:1},||false).unwrap();
        assert_eq!(report.pairs.len(),n);
        println!("pinned broad phase: requested chord padding {pad} m, {n} candidate pair(s)");
    }
}
"""

def native(owner):
    # Compile the exact interconnection, compensated contraction and broad-phase modules.
    # Handoff from the public transformer to the owner's internal assembler is source checked.
    def source(rel):
        return subprocess.check_output(["git","-C",str(owner.resolve()),"show",PIN+":"+rel],text=True)
    with tempfile.TemporaryDirectory(prefix="astra-mechanics-") as tmp:
        root=Path(tmp)
        phs=source("crates/fs-phs/src/lib.rs")
        assert "interconnection::transformer(a, b, port_a, port_b, ratio)" in phs
        assert "pub use interconnection::{InterconnectionBudget, interconnect_mapped}" in phs
        (root/"interconnection").mkdir()
        for rel in ("interconnection.rs","interconnection/accumulation.rs"):
            (root/rel).write_text(source("crates/fs-phs/src/"+rel))
        (root/"broad_phase.rs").write_text(source("crates/fs-contact/src/broad_phase.rs"))
        # Retain the real coordinate types and box operations used by broad phase.
        geom=source("crates/fs-geom/src/lib.rs")
        first=geom.index("/// A point in")
        end=geom.index("\n}",geom.index("fn axis_bounds("))+2
        (root/"driver.rs").write_text(geom[first:end]+"\n"+RUST)
        subprocess.run(["rustc","+nightly-2026-07-06","--edition=2024","-Awarnings","driver.rs","-o","probe"],cwd=root,check=True)
        subprocess.run([str(root/"probe")],check=True)

if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--frankensim",type=Path)
    args=parser.parse_args()
    differential()
    sample_and_hold()
    swept_arm()
    port_sign()
    if args.frankensim:
        native(args.frankensim)
