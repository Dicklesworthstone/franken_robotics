"""Reproduce a binary32 cancellation in two-group population normalization.

Each input pair contains the means of two equally sized constant shards. This
isolates the merge arithmetic. Native modes run the same merge on each named
device. They do not time a learner or exchange gradients between devices.
"""
import argparse
from pathlib import Path
import struct
import subprocess
import tempfile

CENTERS = (0, 4096, 8192)
RECORDS = [(float(center-1),float(center+1)) for center in CENTERS]
def f32(x):
    return struct.unpack("=f",struct.pack("=f",x))[0]
def reference(a,b):
    mean=f32(f32(a+b)*0.5)
    raw=f32(f32(f32(f32(a*a)+f32(b*b))*0.5)-f32(mean*mean))
    half_delta=f32(f32(b-a)*0.5)
    return (mean,raw,f32(half_delta*half_delta))

BODY = """
    float a = x[2*i], b = x[2*i+1];
    float mean = (a+b)*0.5f;
    float raw = (a*a+b*b)*0.5f - mean*mean;
    float half_delta = (b-a)*0.5f;
    y[3*i] = mean;
    y[3*i+1] = raw;
    y[3*i+2] = half_delta*half_delta;
"""
SHADER = """#include <metal_stdlib>
using namespace metal;
kernel void moments(device const float *x [[buffer(0)]], device float *y [[buffer(1)]],
                    uint i [[thread_position_in_grid]]) {
""" + BODY + "}"
METAL = r"""
#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <stdio.h>
int main() { @autoreleasepool {
    id<MTLDevice> device = MTLCreateSystemDefaultDevice();
    if (!device) return 1;
    NSError *error = nil;
    NSString *source = [NSString stringWithContentsOfFile:@"probe.metal"
                          encoding:NSUTF8StringEncoding error:&error];
    MTLCompileOptions *options = [MTLCompileOptions new];
    if (@available(macOS 15.0, *)) {
        options.mathMode = MTLMathModeSafe;
    } else {
        fprintf(stderr,"This replay requires the macOS 15 or newer safe-math profile.\n");
        return 2;
    }
    id<MTLLibrary> library = [device newLibraryWithSource:source options:options error:&error];
    if (!library) { NSLog(@"%@", error); return 2; }
    id<MTLComputePipelineState> pipe = [device newComputePipelineStateWithFunction:
        [library newFunctionWithName:@"moments"] error:&error];
    if (!pipe) { NSLog(@"%@", error); return 3; }
    float x[6] = {-1,1,4095,4097,8191,8193};
    id<MTLBuffer> input = [device newBufferWithBytes:x length:sizeof(x) options:MTLResourceStorageModeShared];
    id<MTLBuffer> output = [device newBufferWithLength:9*sizeof(float) options:MTLResourceStorageModeShared];
    id<MTLCommandQueue> queue = [device newCommandQueue];
    id<MTLCommandBuffer> command = [queue commandBuffer];
    id<MTLComputeCommandEncoder> encoder = [command computeCommandEncoder];
    if (!input || !output || !encoder) return 4;
    [encoder setComputePipelineState:pipe];
    [encoder setBuffer:input offset:0 atIndex:0];
    [encoder setBuffer:output offset:0 atIndex:1];
    [encoder dispatchThreads:MTLSizeMake(3,1,1) threadsPerThreadgroup:MTLSizeMake(3,1,1)];
    [encoder endEncoding]; [command commit]; [command waitUntilCompleted];
    if (command.status != MTLCommandBufferStatusCompleted) { NSLog(@"%@",command.error); return 5; }
    const float *v = (const float *)output.contents;
    for (int i=0; i<3; ++i) printf("%g %g %g\n",v[3*i],v[3*i+1],v[3*i+2]);
    fprintf(stderr,"%s\n",[[device name] UTF8String]);
    return 0;
} }
"""
CUDA = r"""
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>
#define CHECK(expr) do { cudaError_t e=(expr); if(e!=cudaSuccess) {fprintf(stderr,"%s\n",cudaGetErrorString(e)); return 1;} } while(0)
__global__ void moments(const float *x, float *y) {
    unsigned int i = threadIdx.x;
""" + BODY + r"""
}
int main(int argc, char **argv) {
    if (argc!=2) return 1;
    int id=atoi(argv[1]);
    CHECK(cudaSetDevice(id));
    cudaDeviceProp p; CHECK(cudaGetDeviceProperties(&p,id));
    float x[6]={-1,1,4095,4097,8191,8193}, y[9], *dx, *dy;
    CHECK(cudaMalloc(&dx,sizeof(x))); CHECK(cudaMalloc(&dy,sizeof(y)));
    CHECK(cudaMemcpy(dx,x,sizeof(x),cudaMemcpyHostToDevice));
    moments<<<1,3>>>(dx,dy); CHECK(cudaGetLastError()); CHECK(cudaDeviceSynchronize());
    CHECK(cudaMemcpy(y,dy,sizeof(y),cudaMemcpyDeviceToHost));
    for(int i=0;i<3;++i) printf("%g %g %g\n",y[3*i],y[3*i+1],y[3*i+2]);
    CHECK(cudaFree(dx)); CHECK(cudaFree(dy));
    fprintf(stderr,"CUDA device %d %s\n",id,p.name);
    return 0;
}
"""
def run(backend,devices,compiler):
    expected=[reference(a,b) for a,b in RECORDS]
    assert [row[1] for row in expected]==[1.,0.,0.]
    assert all(row[2]==1 for row in expected)
    print("CPU (mean, raw variance, centered variance):",expected,flush=True)
    if backend=="cpu":return
    with tempfile.TemporaryDirectory() as temp:
        root=Path(temp)
        if backend=="metal":
            (root/"probe.metal").write_text(SHADER)
            (root/"probe.mm").write_text(METAL)
            build=["xcrun","clang++","-O2","-fobjc-arc","probe.mm","-framework","Metal","-framework","Foundation","-o","probe"]
            commands=[["./probe"]]
        else:
            (root/"probe.cu").write_text(CUDA)
            build=["nvcc","--fmad=false","-O2","-arch=sm_89","probe.cu","-o","probe"]
            if compiler:build+=["-ccbin",compiler]
            commands=[["./probe",str(i)] for i in devices]
        subprocess.run(build,cwd=root,check=True)
        for command in commands:
            result=subprocess.run(command,cwd=root,check=True,text=True,capture_output=True)
            observed=[tuple(map(float,line.split())) for line in result.stdout.splitlines()]
            assert observed==expected,(command,observed,expected)
            print(result.stderr.strip(),observed,flush=True)
if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("backend",choices=["cpu","metal","cuda"],nargs="?",default="cpu")
    parser.add_argument("--devices",nargs="+",type=int,default=[0])
    parser.add_argument("--ccbin")
    args=parser.parse_args()
    run(args.backend,args.devices,args.ccbin)
