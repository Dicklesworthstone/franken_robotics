"""Exercise the pinned public policy sampler. Optional arguments match R1_ppo_native.py."""
from fractions import Fraction
from pathlib import Path
from tempfile import TemporaryDirectory
import math
import shutil
import subprocess
import sys

# The owner's two multiplications advance the cosine phase by a constant.
# Before finite-precision rounding the sign can change only across a boundary
# of a half-circle, so a uniform phase has P(same sign) = 1 - 2*delta.
modulus = 1 << 64
advance = Fraction((0x9E3779B97F4A7C15 * 0x94D049BB133111EB) % modulus, modulus)
delta = min(advance, 1 - advance)
prediction = float(1 - 2 * delta)
independent_same_sign = 0.5
driver = """
use fs_g1_train::ppo::gaussian_action;
fn main() {
    let n = 100_000;
    for seed in [0_u64, 7, 1234567] {
        let mut state=seed;
        let mut same_sign=0;
        let mut positive=[0,0];
        for _ in 0..n {
            let sample=gaussian_action(&[0.,0.], &[0.,0.], &mut state);
            assert!(sample.iter().all(|x| x.is_finite()));
            for axis in 0..2 { positive[axis] += u32::from(sample[axis] > 0.); }
            same_sign += u32::from((sample[0]>0.) == (sample[1]>0.));
        }
        println!("{seed} {n} {same_sign} {} {}",positive[0],positive[1]);
    }
}
"""
with TemporaryDirectory() as tmp:
    work = Path(tmp)
    loader = work / "R1_ppo_native.py"
    shutil.copyfile(Path(__file__).with_name(loader.name), loader)
    (work / "R1_ppo.rs").write_text(driver)
    rows = subprocess.check_output([sys.executable, str(loader), *sys.argv[1:]], text=True).splitlines()
assert len(rows) == 3
for row in rows:
    seed, n, same, px, py = map(int, row.split())
    assert n == 100_000 and abs(same/n - prediction) < .001
    assert abs(px/n - .5) < .001 and abs(py/n - .5) < .001
    print(f"seed {seed}: {same}/{n} same-sign pairs, positive marginals {px}/{n} and {py}/{n}")
assert abs(prediction-independent_same_sign) > .16
print(f"fixed phase advance predicts {prediction:.8f}; the independent Gaussian law assigns 0.5")
