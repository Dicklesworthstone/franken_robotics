"""Exact independent contract counterexamples for the November Astra recheck."""
from fractions import Fraction as Q
from itertools import product
import json


def inertia_support():
    mass = Q(1)
    radius = Q(1, 10)
    moments = [Q(1, 125)] * 3
    second = [sum(moments) / 2 - m for m in moments]
    assert all(x > 0 for x in second)
    assert all(i <= mass * radius**2 for i in moments)
    assert all(i <= sum(moments) - i for i in moments)
    rms_squared = sum(second) / mass
    assert rms_squared > radius**2
    shell_moment = Q(2, 3) * mass * radius**2
    assert 3 * shell_moment / (2 * mass) == radius**2
    return {"input_principal_moments": moments, "second_moment_eigenvalues": second,
            "required_mean_squared_radius": rms_squared, "available_squared_radius": radius**2,
            "equality_shell_principal_moment": shell_moment}


def design_load():
    endpoints = [(Q(0), Q(19, 10)), (Q(9, 10), Q(1))]
    midpoint = tuple((x + y) / 2 for x, y in zip(*endpoints))
    outcome = []
    for e, weight in [*endpoints, midpoint]:
        # Sum y moments to zero with opposite-side equal front/back forces.
        right = weight * (1 + e) / 2
        left = weight - right
        assert (1-e) * right + (-1-e) * left == 0
        outcome.append({"stance_shift_e": e, "load": weight, "side_forces": [right, left],
                        "feasible": 0 <= min(right, left) and max(right, left) <= 1})
    assert [x["feasible"] for x in outcome] == [True, True, False]
    return outcome


def calibration_alias():
    records = {"A": ("left", "shared"), "B": ("shared", "right")}
    actions = {"A": 0, "B": 1}
    input_records = ("left", "shared", "right")
    # Every encoder followed by a controller induces a single function from record to action.
    robust_decoders = [bits for bits in product(range(2), repeat=3)
                       if all(bits[input_records.index(r)] == actions[s]
                              for s, visits in records.items() for r in visits)]
    exact_measured_variants = list(product(range(2), repeat=2))
    winners = [v for v in exact_measured_variants if v == (0, 1)]
    assert not robust_decoders and len(winners) == 1
    return {"record_decisions_tested": 8, "winning_record_decisions": len(robust_decoders),
            "distinguishable_record_decisions_tested": 4, "winning_distinguishable_decisions": len(winners)}


def handoff():
    worlds = (0, 1)
    # Sender knows the bit; receiver's command cannot use any sender action or packet before commitment.
    local_counts = [sum(action == bit for bit in worlds) for action in worlds]
    timely_channel_counts = [sum(answers[bit] == bit for bit in worlds)
                             for answers in product(worlds, repeat=2)]
    assert local_counts == [1, 1] and timely_channel_counts == [1, 2, 0, 1]
    return {"common_receiver_policy_win_counts": local_counts,
            "bit_visible_receiver_policy_win_counts": timely_channel_counts}


def range_alias():
    anchors = [(-1,0), (1,0)]
    squared = lambda p, a: sum((x-y)**2 for x,y in zip(p,a))
    reports = []
    for target in [(0,1), (0,-1)]:
        distances = [squared(target,a) for a in anchors]
        # Outer product of a unit range Jacobian needs only the squared range.
        gram = [[sum(Q((target[i]-a[i])*(target[j]-a[j]),d)
                     for a,d in zip(anchors,distances)) for j in range(2)] for i in range(2)]
        reports.append({"squared_ranges": distances, "local_fisher": gram,
                        "new_squared_range": squared(target,(0,2))})
    assert all(r["squared_ranges"] == [2,2] and r["local_fisher"] == [[1,0],[0,1]] for r in reports)
    assert [r["new_squared_range"] for r in reports] == [1,9]
    assert 1+1 == 3-1
    return reports


def equivariant_actions():
    actions = list(product(range(2), repeat=2))
    fixed = [a for a in actions if a == a[::-1]]
    winners = [a for a in actions if sum(a) == 1]
    assert len(fixed) == len(winners) == 2 and set(fixed).isdisjoint(winners)
    symmetric_distribution = {a: Q(1,2) if a in winners else Q(0) for a in actions}
    assert all(symmetric_distribution[a] == symmetric_distribution[a[::-1]] for a in actions)
    return {"unrestricted_action_count": len(actions), "unrestricted_winners": winners,
            "equivariant_deterministic_actions": fixed,
            "equivariant_randomized_success": sum(symmetric_distribution[a] for a in winners)}


def gain_persistence():
    # A prescribed out/back proof motion with gain positive and fixed across both one-second moves.
    admitted = [(1,1), (2,2)]
    rectangular = list(product((1,2), repeat=2))
    total = lambda gains: gains[0] - gains[1]
    true_exits = sorted(set(map(total, admitted)))
    enlarged_exits = sorted(set(map(total, rectangular)))
    assert true_exits == [0] and enlarged_exits == [-1,0,1]
    return {"constant_gain_exits":true_exits,"resampled_gain_exits":enlarged_exits}


if __name__ == "__main__":
    print(json.dumps({f.__name__: f() for f in (inertia_support, design_load, calibration_alias,
          handoff, range_alias, equivariant_actions, gain_persistence)}, default=str, indent=2))
