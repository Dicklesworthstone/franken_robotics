"""Independent, reproducible checks of proposed agent, physics and evidence contracts."""
from fractions import Fraction as F
from math import erf, exp, isclose, log, ceil, sqrt
from statistics import NormalDist

# Policy importance at the unit upper servo limit is a ratio of tail masses.
old=NormalDist(0,1); new=NormalDist(1,1)
tail=(1-new.cdf(1))/(1-old.cdf(1))
density=new.pdf(1)/old.pdf(1)
assert 3.1514<tail<3.1516 and isclose(density,exp(.5))
print('applied action mass ratio',tail,'point-density ratio',density)

# Both body and obstacle boundaries move into nominal free space.
assert 6-4-4==-2
nominal_gap=F(6,1000);surface_error=F(4,1000)
assert nominal_gap-2*surface_error<0
print('6 mm proxy gap can be real 2 mm penetration')

# One clock tie cannot identify two parameters. Fitting the evaluated event hides its error.
base=lambda t:t
fast=lambda t:F(10001,10000)*t
assert base(0)==fast(0)
assert fast(8)-base(8)==F(8,10000)
print('unobserved 100 ppm drift produces 0.8 ms at 8 s')

# Fitting a scale factor conceals a doubled metric displacement. A rigid gauge preserves lengths.
assert abs(2-1)==1 and F(1,2)*2==1
print('scale fit masks one metre of displacement error')

# A returning witness can remain feasible while a rival becomes the cheapest.
winner=lambda pool:min((cost,n) for n,cost,ok in pool if ok)
before=[('cart',9,True),('relay',5,False)]
after=[('cart',9,True),('relay',5,True)]
assert before[0]==after[0] and winner(before)==(9,'cart') and winner(after)==(5,'relay')
print('unchanged feasible cart: optimal cost moves from 9 to 5')

# Rare latency: for continuous i.i.d. observations, the maximum misses the upper 1% with P=.99**n.
assert ceil(log(.05)/log(.99))==299
print('five latency draws all below p99 with probability',.99**5)

# Marginal stage certificates alone do not identify joint mission reliability.
worlds=set(range(20)); a=worlds-{0};b=worlds-{1}
assert F(len(a),20)==F(len(b),20)==F(19,20)
assert F(len(a&b),20)==F(9,10)<F(19,20)**2 and F(len(a&a),20)==F(19,20)
print('same 95% stage marginals permit 90% or 95% whole-mission success')

# Inferring time-to-go via a noncausal scorer should not select the clock offset.
assert F(5)-F(47,10)==F(3,10)
