"""Follow-ups on the registered stance, material and binary-sensor experiments."""
import argparse
import json
import math
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SIGNS = ((1,1), (1,-1), (-1,1), (-1,-1))


def stance(linprog_check=False):
    historical = json.loads((ROOT / "mor/repro/P01-results.json").read_text())
    corner_forces = [list(map(F, row[2])) for row in historical["boundary_witnesses"]]
    # Any affine scalar on a rectangle has equal diagonal sums.
    pp = [forces[0] for forces in corner_forces]
    assert pp == [160,130,110,0] and pp[0]+pp[3] != pp[1]+pp[2]
    a, b = F(1,3), F(3,14)

    def check(forces, x, y, width):
        assert all(0 <= value <= 160 for value in forces)
        assert sum(forces) == 400
        assert a*sum(sx*f for (sx,sy),f in zip(SIGNS,forces)) == 60*x
        assert width*sum(sy*f for (sx,sy),f in zip(SIGNS,forces)) == 30*y

    for (x,y), forces in zip(SIGNS,corner_forces):
        check(forces,x,y,b)
    for x,y in product((F(-1),F(-1,3),F(0),F(1,2),F(1)),repeat=2):
        weights = [(1+sx*x)*(1+sy*y)/4 for sx,sy in SIGNS]
        assert min(weights)>=0 and sum(weights)==1
        nonlinear = [sum(w*corner[f] for w,corner in zip(weights,corner_forces)) for f in range(4)]
        check(nonlinear,x,y,b)

    # The admissible domain and actuator box are invariant under each reflection.
    # Averaging a feasible affine map and its reflected maps yields a feasible
    # equivariant affine map. Equilibrium fixes its three coefficients below.
    def equivariant(x,y,width):
        return [100+sx*60*x/(4*a)+sy*30*y/(4*width) for sx,sy in SIGNS]

    affine_width = F(30)/(4*(160-100-F(60)/(4*a)))
    assert affine_width == F(1,2) and affine_width/b==F(7,3)
    for x,y in SIGNS:
        check(equivariant(x,y,affine_width),x,y,affine_width)
    assert max(equivariant(1,1,F(49,100)))>160

    if linprog_check:
        from scipy.optimize import linprog
        # Unrestricted forces f_i = intercept_i + x*xcoef_i + y*ycoef_i,
        # x,y in {-1,1}. Maximize inverse width v, including no symmetry constraint.
        eq, rhs, ine, ceiling = [], [], [], []
        for x,y in SIGNS:
            for multipliers, demand, vcoef in (([1]*4,400,0),([sx for sx,_ in SIGNS],180*x,0),
                                               ([sy for _,sy in SIGNS],0,-30*y)):
                eq.append([k*t for k in multipliers for t in (1,x,y)] + [vcoef])
                rhs.append(demand)
            for i in range(4):
                basis=[t*int(j==i) for j in range(4) for t in (1,x,y)]+[0]
                ine.extend([basis,[-k for k in basis]])
                ceiling.extend([160,0])
        result=linprog([0]*12+[-1],A_eq=eq,b_eq=rhs,A_ub=ine,b_ub=ceiling,
                       bounds=[(None,None)]*12+[(0,None)],method="highs")
        assert result.success and abs(result.x[-1]-2)<1e-10
    print("stance: adjustable half-width 3/14 m; one affine map needs 1/2 m; width ratio 7/3")


def sensor():
    n = 7
    count_prob = {1:F(43,64),2:F(3,64),3:F(9,64),4:F(9,64)}
    assert sum(count_prob.values())==1
    histories = list(product((0,1),repeat=n))

    def mass(obs, label):
        k = sum(bit != label for bit in obs)
        return count_prob.get(k,F(0))/math.comb(n,k)

    for label in (0,1):
        assert sum(mass(obs,label) for obs in histories)==1
        for i,j in combinations(range(n),2):
            for a,b in product((0,1),repeat=2):
                expected=[F(1,4),F(3,4)]
                joint=sum(mass(obs,label) for obs in histories if obs[i]==a and obs[j]==b)
                assert joint==expected[a==label]*expected[b==label]
    optimum=sum(max(mass(obs,0),mass(obs,1)) for obs in histories)/2
    iid = sum(F(math.comb(n,k)*3**(n-k),4**n) for k in range(4))
    assert optimum==F(55,64)<F(9,10)<iid==F(3807,4096)
    # Majority attains the Bayes bound separately for each class here.
    for label in (0,1):
        assert sum(mass(obs,label) for obs in histories if int(sum(obs)>3)==label)==optimum
    print("sensor: all 21 read pairs per class match independence; 128 histories give 55/64 Bayes success")
    return optimum


def material():
    with localcontext() as context:
        context.prec=50
        one=D(1)
        lowq,highq=D(".18"),D(".22")
        lowtau,hightau=D(".9"),D("1.1")
        eps=D(".02")
        laws="VPCD"

        def response(law,r,t,q,tau):
            s=t/tau
            if law=="V": exposure=s
            elif law=="C": exposure=s/min(r,one)**2
            elif law=="P" or r<one: exposure=s/r**2
            else:
                k=one/r**2
                exposure=k*min(s,D(".25"))+(1+(1-k)/3)*max(s-D(".25"),0)
            return q+(1-q)*(-exposure).exp()

        # Every response is nondecreasing in q and tau. Bounds include closed read error.
        def envelope(law,r,t):
            return (response(law,r,t,lowq,lowtau)-eps,response(law,r,t,highq,hightau)+eps)

        # Conservative positive lower bound for the *coupled* delayed-law difference.
        lower=10*lowq+(1-highq)*(-one/lowtau).exp()*(60-50*((one-one/hightau)/4).exp())
        assert D("4.07") < lower < D("4.08")
        indep=60*response('D',one,one,lowq,lowtau)-50*response('D',D(2),one,highq,hightau)
        assert D("-.078") < indep < 0
        # Nominal margins for V/C are 10*R>0 at mission radius; P has opposite ranking.
        assert 60*response('P',one,one,highq,hightau)-50*response('P',D(2),one,lowq,lowtau)<0
        times=tuple(map(D,(".0625",".125",".25",".5","1","2")))
        radii=tuple(map(D,(".25",".5","1","1.5","2","3")))
        options=[]
        for t,r in product(times,radii):
            readings={law:envelope(law,r,t) for law in laws}
            if all(readings['P'][1]<readings[l][0] or readings[l][1]<readings['P'][0] for l in 'VCD'):
                options.append((t,r))
        t,r=min(options)
        assert (t,r)==(D(".5"),D("1.5"))
        assert max(envelope(l,r,t)[1] for l in "VCD")<D(".788")<D(".8")<envelope("P",r,t)[0]
        gap=envelope("P",r,t)[0]-max(envelope(l,r,t)[1] for l in "VCD")
        assert D(".0128")<gap<D(".0129")
        for short in times[:3]:
            for radius in radii:
                assert response("P",radius,short,lowq,hightau)==response("D",radius,short,lowq,hightau)
        for small_radius in radii[:3]:
            assert response("P",small_radius,t,lowq,hightau)==response("C",small_radius,t,lowq,hightau)

        rows=0
        for law,iq,it,archive_noise,probe_noise in product(laws,range(5),range(5),(-eps,0,eps),(-eps,0,eps)):
            q=lowq+D(".01")*iq
            tau=lowtau+D(".05")*it
            true_a=60*response(law,one,one,q,tau)>50*response(law,D(2),one,q,tau)
            read=response(law,r,t,q,tau)+probe_noise
            assert (read<D(".794"))==true_a
            rows+=1
        assert rows==900
        print(f"material: delayed-law lower bound {lower:.6f} N; first probe r={r}, t={t}; "
              f"gap {gap:.6f}, {rows} grid cases; incremental modeled time ratio 5/3")
        return float(lower),float(gap)


if __name__=="__main__":
    args=argparse.ArgumentParser()
    args.add_argument("--linprog",action="store_true")
    stance(args.parse_args().linprog)
    sensor()
    material()
