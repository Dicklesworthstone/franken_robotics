"""Compare three plant updates under one sampled PD controller with held input.

Coordinates are displacement in mm and velocity times the control period in mm.
A row is (world, update, displacement, scaled velocity) after 16 controller ticks.
A positive error uses negative acceleration. Input data are synthetic.
"""
import argparse
import hashlib
import json
import math
import struct
import subprocess
import tempfile
from fractions import Fraction as Q
from pathlib import Path

N = 64
STEPS = 16
MODES = ("exact-hold", "kick-drift", "two-half-steps")
TOL = Q(1, 32)


def terminal(i, mode):
    x, w = Q(i % 8 - 3), Q(i // 8 - 3)
    alpha = (Q(1, 2), Q(1), Q(3, 4))[mode]
    for _ in range(STEPS):
        u = -Q(3, 2) * (x + w)
        x, w = x + w + alpha * u, w + u
    return x, w


# The native kernels do two actual half steps for mode 2. The rational referee
# integrates the same held input with its independently derived coefficient 3/4.
BODY = """
    int i = id % 64, mode = id / 64;
    float x = float(i % 8 - 3), w = float(i / 8 - 3);
    for (int t = 0; t < 16; ++t) {
        float u = -1.5f * (x + w);
        if (mode == 0) {
            x += w + 0.5f * u;
            w += u;
        } else {
            int substeps = mode;
            float dt = 1.0f / substeps;
            for (int j = 0; j < substeps; ++j) {
                w += dt * u;
                x += dt * w;
            }
        }
    }
    out[2*id] = x; out[2*id+1] = w;
"""
METAL_SRC = '#include <metal_stdlib>\nusing namespace metal;\nkernel void servo(device float* out [[buffer(0)]], uint id [[thread_position_in_grid]]) {' + BODY + '}'
METAL_HOST = r'''
#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <cstdio>
int main() { @autoreleasepool {
    id<MTLDevice> d=MTLCreateSystemDefaultDevice();
    if (!d) return 1;
    NSError *err=nil;
    NSString *src=[NSString stringWithContentsOfFile:@"servo.metal" encoding:NSUTF8StringEncoding error:&err];
    MTLCompileOptions *options=[MTLCompileOptions new]; options.mathMode=MTLMathModeSafe;
    id<MTLLibrary> lib=[d newLibraryWithSource:src options:options error:&err];
    if (!lib) { NSLog(@"%@",err); return 2; }
    id<MTLComputePipelineState> p=[d newComputePipelineStateWithFunction:[lib newFunctionWithName:@"servo"] error:&err];
    if (!p) { NSLog(@"%@",err); return 3; }
    id<MTLBuffer> b=[d newBufferWithLength:384*sizeof(float) options:MTLResourceStorageModeShared];
    id<MTLCommandQueue> q=[d newCommandQueue]; id<MTLCommandBuffer> cmd=[q commandBuffer];
    id<MTLComputeCommandEncoder> enc=[cmd computeCommandEncoder];
    if (!b || !enc) return 4;
    [enc setComputePipelineState:p]; [enc setBuffer:b offset:0 atIndex:0];
    [enc dispatchThreads:MTLSizeMake(192,1,1) threadsPerThreadgroup:MTLSizeMake(32,1,1)];
    [enc endEncoding]; [cmd commit]; [cmd waitUntilCompleted];
    if (cmd.status != MTLCommandBufferStatusCompleted) { NSLog(@"%@",cmd.error); return 5; }
    std::fprintf(stderr,"%s\n",d.name.UTF8String);
    return std::fwrite(b.contents,sizeof(float),384,stdout)==384 ? 0 : 6;
} }
'''
CUDA = r'''
#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#define CHECK(call) do { cudaError_t e=(call); if(e!=cudaSuccess){std::fprintf(stderr,"%s\n",cudaGetErrorString(e));return 1;} } while(0)
__global__ void servo(float *out) {
    unsigned int id=blockIdx.x*blockDim.x+threadIdx.x;
''' + BODY + '''
}
int main(int argc,char** argv) {
    if (argc!=2) return 1;
    int device=std::atoi(argv[1]);
    CHECK(cudaSetDevice(device)); cudaDeviceProp p; CHECK(cudaGetDeviceProperties(&p,device));
    float host[384], *out; CHECK(cudaMalloc(&out,sizeof(host)));
    servo<<<6,32>>>(out); CHECK(cudaGetLastError()); CHECK(cudaDeviceSynchronize());
    CHECK(cudaMemcpy(host,out,sizeof(host),cudaMemcpyDeviceToHost)); CHECK(cudaFree(out));
    std::fprintf(stderr,"CUDA device %d %s\\n",device,p.name);
    return std::fwrite(host,sizeof(float),384,stdout)==384 ? 0 : 2;
}
'''


def verdict(pair):
    return max(map(abs, pair)) <= TOL


def reference():
    rows = [[terminal(i, j) for i in range(N)] for j in range(len(MODES))]
    return rows, [sum(map(verdict, group)) for group in rows]


def measured(payload, expected, counts):
    values = list(struct.iter_unpack("<ff", payload))
    if len(values) != N * len(MODES):
        raise ValueError("Missing terminal states")
    for j, group in enumerate(expected):
        for i, pair in enumerate(group):
            got = values[N*j+i]
            if any(not math.isclose(g, float(e), rel_tol=3e-5, abs_tol=5e-5)
                   for g,e in zip(got, pair)):
                raise ValueError(f"Terminal state mismatch in world {i} for {MODES[j]}")
            if verdict(got) != verdict(pair):
                raise ValueError(f"Terminal decision mismatch in world {i} for {MODES[j]}")
    return {"accepted": counts, "terminal_sha256": hashlib.sha256(payload).hexdigest()}


def binary32_reference():
    def f32(value):
        return struct.unpack("<f", struct.pack("<f", value))[0]
    buffer = bytearray()
    for mode in range(len(MODES)):
        for i in range(N):
            x, w = i % 8 - 3, i // 8 - 3
            for _ in range(STEPS):
                u = f32(-1.5 * f32(x + w))
                if mode == 0:
                    x = f32(x + f32(w + u/2))
                    w = f32(w + u)
                else:
                    for _ in range(mode):
                        w = f32(w + u/mode)
                        x = f32(x + w/mode)
            buffer.extend(struct.pack("<ff", x, w))
    return bytes(buffer)


def check_receipts(records):
    rows, counts = reference()
    if counts != [64, 1, 15]:
        raise ValueError("Exact held-input verdicts changed")
    expected = measured(binary32_reference(), rows, counts)
    devices = ["Apple M5 Ultra", "CUDA device 0 NVIDIA GeForce RTX 4090",
               "CUDA device 1 NVIDIA GeForce RTX 4090"]
    if records != [{"device": device, **expected} for device in devices]:
        raise ValueError("Native servo receipt differs from the ordered binary32 reference")
    return expected


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("cpu", "metal", "cuda"), default="cpu", nargs="?")
    parser.add_argument("--devices", nargs="+", type=int, default=[0])
    parser.add_argument("--ccbin")
    args = parser.parse_args()
    rows, counts = reference()
    print("Exact 64-world acceptance", counts, flush=True)
    if args.mode == "cpu":
        return
    with tempfile.TemporaryDirectory() as temp:
        root = Path(temp)
        if args.mode == "metal":
            (root/"servo.metal").write_text(METAL_SRC)
            (root/"servo.mm").write_text(METAL_HOST)
            build=["xcrun","clang++","-O2","-fobjc-arc","servo.mm","-framework","Foundation","-framework","Metal","-o","servo"]
            targets=[[]]
        else:
            (root/"servo.cu").write_text(CUDA)
            build=["nvcc","-O2","--fmad=false","-arch=sm_89","servo.cu","-o","servo"]
            if args.ccbin:
                build += ["-ccbin",args.ccbin]
            targets=[[str(i)] for i in args.devices]
        subprocess.run(build,cwd=root,check=True)
        for target in targets:
            proc=subprocess.run(["./servo",*target],cwd=root,capture_output=True,check=True)
            result=measured(proc.stdout,rows,counts)
            print(json.dumps({"device":proc.stderr.decode().strip(),**result},sort_keys=True))


if __name__ == "__main__":
    main()
