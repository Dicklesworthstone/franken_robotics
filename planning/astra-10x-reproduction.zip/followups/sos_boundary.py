"""Compile and call the pinned fs-sos public model constructor and radius-scoped bound."""
from fractions import Fraction
from pathlib import Path
from tempfile import TemporaryDirectory
import argparse
import os
import io
import tarfile
import subprocess

PIN = "483d09c682f24947008f2df43f53e6c3e1291c1e"
DRIVER = r"""
use fs_sos::{Poly, SosCertificate};

fn main() {
    let one = SosCertificate { squares: vec![], lower_bound: 1.0 };
    let tiny_slope = Poly::new(vec![1.0, -2_f64.powi(-50)]);
    let tick = 2_f64.powi(28);
    let scoped = one.certified_bound_on(&tiny_slope, tick).unwrap();
    println!("{} {} {} {}", tiny_slope.degree(), tiny_slope.eval(tick),
             scoped, one.certified_bound_global(&tiny_slope).unwrap());
    let retained = Poly::new(vec![1.0, -0.5]);
    let narrow = 2_f64.powi(-55);
    println!("{} {:.17} {:.17}", retained.degree(),
             one.certified_bound_on(&retained, narrow).unwrap(),
             one.certified_bound_on(&retained, 1.0).unwrap());
    // y=x/2^28 puts the same physical interval into [-1,1].
    let equivalent = Poly::new(vec![1.0, -2_f64.powi(-22)]);
    println!("{} {:.17}", equivalent.degree(),
             one.certified_bound_on(&equivalent, 1.0).unwrap());
}
"""

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", type=Path, default=Path.home()/"projects/frankensim")
    args=ap.parse_args()
    repo=args.repo.resolve()
    # Build the seven production crates from pinned Git bytes with no Cargo workspace resolution.
    graph = {
        "fs-blake3": (), "fs-math": (), "fs-obs": (), "fs-qty": ("fs-blake3",),
        "fs-evidence": ("fs-blake3","fs-obs","fs-qty"), "fs-ivl": ("fs-evidence","fs-math"),
        "fs-sos": ("fs-ivl","fs-math"),
    }
    with TemporaryDirectory() as temp:
        root=Path(temp)
        src=subprocess.check_output(["git","-C",str(repo),"archive",PIN,
                                     *[f"crates/{name}/src" for name in graph]])
        with tarfile.open(fileobj=io.BytesIO(src)) as tf:
            tf.extractall(root,filter="data")
        compiler=["rustc","+nightly-2026-07-06","--edition=2024","-Awarnings","-L",str(root)]
        env=dict(os.environ,CARGO_PKG_VERSION="0.0.1")
        for name,dependencies in graph.items():
            krate=name.replace("-","_")
            command=compiler+["--crate-type=rlib","--crate-name",krate,
                              "-o",str(root/f"lib{krate}.rlib")]
            for dependency in dependencies:
                dep=dependency.replace("-","_")
                command.extend(["--extern",f"{dep}={root}/lib{dep}.rlib"])
            subprocess.run(command+[str(root/"crates"/name/"src/lib.rs")],env=env,cwd=root,check=True)
        (root/"main.rs").write_text(DRIVER)
        subprocess.run(compiler+["--extern",f"fs_sos={root}/libfs_sos.rlib","main.rs","-o","probe"],
                       env=env,cwd=root,check=True)
        result=subprocess.run([str(root/"probe")],cwd=root,text=True,capture_output=True,check=True)
    a,b,c=result.stdout.strip().splitlines()
    degree,at_tick,scoped,global_bound=map(float,a.split())
    assert (degree,at_tick,scoped,global_bound)==(0,1,1,1)
    exact=1-Fraction(1,2**50)*2**28
    assert exact==1-Fraction(1,2**22) and Fraction(scoped)>exact
    degree,small_radius,large_radius=map(float,b.split())
    minimum=1-Fraction(1,2**56)
    assert degree==1 and Fraction(small_radius)>minimum
    assert Fraction(large_radius)<=Fraction(1,2)
    normalized_degree,normalized_bound=map(float,c.split())
    assert normalized_degree==1 and Fraction(normalized_bound)<=exact<Fraction(scoped)
    print(f"authored slope -2^-50, stored degree {int(float(a.split()[0]))}; owner scoped/global lower bounds {scoped:g}/{global_bound:g}; exact at 2^28 = {exact}")
    print(f"retained slope -1/2, radius 2^-55: lower bound {small_radius:g}; exact minimum {minimum}; radius-one lower bound {large_radius:.17g}")
    print(f"same first polynomial in normalized coordinates: stored degree {int(normalized_degree)} and valid scoped bound {normalized_bound:.17g}")

if __name__ == "__main__":
    main()
