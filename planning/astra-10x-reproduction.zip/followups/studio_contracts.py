"""Exact small admission examples for the Astra simulation and agent contracts."""
from fractions import Fraction as F
import json
import math

def dock(gain, commands):
    x = v = F(0)
    for u in commands:
        x, v = x + v + gain*u/2, v + gain*u
    return x, v

# A policy observing the first shaping reward can recover the hidden gain even
# when no velocity packet has yet arrived. Initial conditions are both zero.
p = F(1,4)
receipts = {}
for g in (F(1), F(2)):
    x1, _ = dock(g, [p])
    reward = -abs(1-x1)
    decoded = 8*(1+reward)
    assert decoded == g
    q = 1/decoded-2*p
    actions = (p,q,-p-q)
    assert max(map(abs,actions)) <= F(3,4)
    assert dock(g, actions) == (1,0)
    receipts[str(g)] = [str(reward), [str(u) for u in actions]]
assert receipts["1"][0] != receipts["2"][0]
# Even matching the targets in position alone is impossible for a common command
# sequence because each coefficient of terminal position scales with g.
for i in range(3):
    basis = tuple(F(int(j == i)) for j in range(3))
    assert dock(F(2),basis)[0] == 2*dock(F(1),basis)[0]
print("gain -> reward, successful actions", receipts)

# Positions in SO(2) are identical; the linear spring is on a lifted angle.
k = 0.5
one_turn = math.tau
assert math.isclose(math.cos(one_turn),1.) and abs(math.sin(one_turn)) < 1e-15
assert math.isclose(-k*one_turn, -math.pi)
assert math.isclose(k*one_turn**2/2,math.pi**2)
print("one turn: restoring torque", -k*one_turn, "N m; stored work", k*one_turn**2/2, "J")

# Duplicate input members disappear if validation is deferred until after map
# construction. The two valid parsers illustrate the receiving-side ambiguity.
raw = r'{"wheel_radius_mm":60,"wheel_radius_\u006dm":75}'
def first(pairs):
    result = {}
    for key, value in pairs:
        result.setdefault(key,value)
    return result
def strict(pairs):
    out = {}
    for key,value in pairs:
        if key in out:
            raise ValueError("ambiguous member")
        out[key] = value
    return out
assert json.loads(raw,object_pairs_hook=first)["wheel_radius_mm"] == 60
assert json.loads(raw)["wheel_radius_mm"] == 75
try:
    json.loads(raw,object_pairs_hook=strict)
except ValueError as error:
    assert str(error) == "ambiguous member"
else:
    raise AssertionError("duplicate member accepted")
print("escaped duplicate wheel key: first=60 mm, last=75 mm, strict decoding refuses")
