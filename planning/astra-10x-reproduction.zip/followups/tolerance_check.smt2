(set-logic QF_NRA)
; Two centimetres. For gains 1 and 25/24 the centered velocity
; reading is possible for each plant at every permitted first command.
(declare-fun p () Real)
(declare-fun a () Real)
(declare-fun b () Real)
(assert (and (<= (- (/ 3 4)) p (/ 3 4)) (<= (- (/ 3 4)) a (/ 3 4)) (<= (- (/ 3 4)) b (/ 3 4))))
(define-fun v1 ((g Real)) Real (* g p))
(define-fun x1 ((g Real)) Real (/ (v1 g) 2))
(define-fun v2 ((g Real)) Real (+ (v1 g) (* g a)))
(define-fun x2 ((g Real)) Real (+ (x1 g) (v1 g) (/ (* g a) 2)))
(define-fun v3 ((g Real)) Real (+ (v2 g) (* g b)))
(define-fun x3 ((g Real)) Real (+ (x2 g) (v2 g) (/ (* g b) 2)))
(assert (= (v3 1) 0 (v3 (/ 25 24))))
(assert (<= (/ 49 50) (x3 1) (/ 51 50)))
(assert (<= (/ 49 50) (x3 (/ 25 24)) (/ 51 50)))
(check-sat)
(reset)
(set-logic QF_NRA)
; Two and a half centimetres. Seek any conditional gain range for which
; a common bounded continuation of probe 5/8 would be impossible.
(declare-fun a () Real)
(declare-fun b () Real)
(declare-fun r () Real)
(assert (<= 1 a b 2))
(assert (<= (- (/ 1 64)) (- r (* a (/ 5 8))) (/ 1 64)))
(assert (<= (- (/ 1 64)) (- r (* b (/ 5 8))) (/ 1 64)))
; [1/2,11/8] is the reachability interval for x/g at zero terminal speed.
; The requested common command must intersect [39/(40a),41/(40b)].
(assert (or (> (* (/ 1 2) b) (/ 41 40)) (> (/ 39 40) (* (/ 11 8) a)) (> (* 39 b) (* 41 a))))
(check-sat)
