"""Local ZOH wheel and winding stability at a constant-torque sliding operating point."""
import numpy as np
from scipy.linalg import expm

RADIUS = 0.075
ROTOR = 0.0002
DAMPING = 0.002
TORQUE_CONSTANT = 0.2
GAIN = 2.0
PERIOD = 0.01
STEP = 0.00005
INERTIA = 0.5 * (0.2 * (RADIUS / 0.060)**2) * RADIUS**2 + ROTOR


def exact_map(tau):
    # Augment [wheel rate, winding current] with the held current target.
    flow = [[-DAMPING / INERTIA, TORQUE_CONSTANT / INERTIA, 0],
            [0, -1 / tau, 1 / tau], [0, 0, 0]]
    sampled = expm(PERIOD * np.array(flow))
    return sampled[:2, :2] + np.outer(sampled[:2, 2], [-GAIN, 0])


def simulated_map(tau, h):
    # Match the historical explicit order: advance current, then wheel rate
    # with that new current. At each controller tick hold proportional feedback.
    columns = []
    for omega, current in ((1., 0.), (0., 1.)):
        target = -GAIN * omega
        for _ in range(round(PERIOD / h)):
            current += h * (target - current) / tau
            omega += h * (TORQUE_CONSTANT * current - DAMPING * omega) / INERTIA
        columns.append((omega, current))
    return np.array(columns).T


def radius(matrix):
    return max(abs(np.linalg.eigvals(matrix)))


if __name__ == "__main__":
    print(f"effective inertia {INERTIA:.11f} kg m^2; "
          f"instantaneous-current scalar magnitude {abs(1 - GAIN * TORQUE_CONSTANT * PERIOD / INERTIA):.4f}")
    for law, tau, expected in (("target-current feedforward", .002, 1.4820),
                               ("measured-current feedforward", .0025, .9207)):
        exact = exact_map(tau)
        historical_step = simulated_map(tau, STEP)
        fine = simulated_map(tau, STEP / 8)
        assert abs(radius(exact) - expected) < 0.00005
        assert (radius(historical_step) < 1) == (expected < 1)
        assert np.linalg.norm(fine - exact) < np.linalg.norm(historical_step - exact) / 7
        print(f"{law}: continuous-flow spectral radius {radius(exact):.4f}; "
              f"50 us substep {radius(historical_step):.4f}; 6.25 us substep {radius(fine):.4f}")
