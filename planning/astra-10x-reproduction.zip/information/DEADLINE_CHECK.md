# COD3 · Observation deadline versus support width

Independent MO-quickie-pilot on the factory-tag question. RoseHorse did not originate COD3.

**Pre-run lock.** Predict that a timely tag expands the winning payload support beyond one common action, and that exact belief-game elimination recovers the same frontier. An exact common or late-label win above the one-action boundary, or a disagreement between methods, falsifies the predicted result. Agreement kills a distinct-query claim for this toy.

**Toy assumptions.** A simulated 1D gripper commits one signed placement correction `u ∈ [−1/2,1/2]` mm at time 1, then releases irreversibly. A linear spring under gravity gives residual placement `e = u − bᵢ − q − 5(p−1.05)` mm, with assumed effective compliance 5 mm/kg and SKU fixture offsets `bᵢ ∈ {−1/4,0,1/4}` mm. Within each SKU an unknown fixed manufacturing offset `q ∈ [−1/32,1/32]` mm gives a continuous design family. The unknown fixed payload ranges independently over `1.05 ± w/5` kg for support half-width `w ∈ [0,1/2]` mm. Success is `|e| ≤ 3/8` mm. No other disturbance, actuation, or state feedback exists. The controller knows the model and support, sees only the clock and delivered tag, and has no informative prefix or probing action. Factory tags are deterministic functions of SKU alone. One shared policy chooses a command from its deadline history. Early tags arrive at time 0, late tags at time 2. The common-action mutant receives early tags and ties all action branches.

**Frozen check.** Compute the exact continuous width frontier for 1, 2, and 3 tags and both mutants. Compare belief-window intersection with symbolic Fourier–Motzkin elimination over the deadline histories. Expect closed thresholds `3/32, 7/32, 11/32` mm for early tags, and `3/32` mm for each mutant even with three nominal tags. Check a boundary policy at `w=7/32` and a strict conflict for the mutants at `w=1/8`.

**Result.** Both methods agreed for all five cases and every enumerated tag assignment. For each deadline belief, the first method intersects bounded action windows derived from the spring and tolerance. The comparator eliminates that belief’s command from signed affine error inequalities at every manufacturing and payload corner. These corners prove the bounds over the continuous boxes. Every width from zero through the reported limit is feasible.

| Information at release | Maximum payload half-width `w` |
|---|---:|
| Early, 1 / 2 / 3 tags | 3/32 / 7/32 / 11/32 mm |
| Early, one common action | 3/32 mm |
| Late, up to 3 tags | 3/32 mm |

At `w=7/32`, group the two lowest biases at command `−1/8` mm and send the highest to `1/4` mm. All 12 placement corners pass. At `w=1/8`, opposite SKU and load corners demand `u ≥ 1/32` and `u ≤ −1/32` mm from the shared action. The frozen payload [1, 1.1] kg corresponds to `w=1/4` and needs three early tags in this fixture.

**Disposition.** The deadline changes feasibility, and exact elimination already recovers the query. Retire novelty for this scalar model. The mechanical bridge remains open. A gripper model must derive when commitment becomes irreversible, which measurements are indistinguishable through that deadline, and which command bounds follow from contact. Here the deadline and information are stipulated, and a scalar spring law supplies the action windows. The planar three-way intersection was outside this test.

First result at 18:21:50 EST, 1m57s after the first recorded checkpoint. Rerun with `python3 -B information/deadline_check.py`. [Exact runner](deadline_check.py)
