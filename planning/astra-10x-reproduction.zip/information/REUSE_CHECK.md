# CC3 · Locked camera-delivery check

## Protocol locked before execution

A camera captures a single “go” packet at tick 0. Two paired scenes commit at ticks 2 and 4. Delivery happens before control at a shared tick. A holds position at 0. B moves from 0 to 1 if the packet has arrived by its commit, and otherwise holds. Position 1 is success. Promote B only if it succeeds in both scenes. The display title is metadata.

| State | Camera delay | Display title | Expected successful B scenes | Expected verdict |
|---|---:|---|---|---|
| Seed | 1 | Original | Early and late | Promote |
| Irrelevant | 1 | Renamed | Early and late | Promote |
| Harmless relevant | 2 | Renamed | Early and late | Promote |
| Tick crossing | 3 | Renamed | Late | Decline |

Compare a semantic receipt with per-pair fallback against a hermetic DAG that keys a pair by its immutable scene, clock and certified controller-visible input. Both arms receive the exact guard `commit − delivery ≥ 0`, including equality, and can reuse the verdict if the pair results stay valid. Count pair evaluations and verdict reductions separately. Independently replay every state by advancing the clock tick by tick. The negative control deliberately omits the delivery dependency.

**Falsifiers.** Any accepted reuse that disagrees with fresh replay falsifies its soundness. Equal skipped pair evaluations and reductions under the equally informed DAG falsify unique reuse on this sequence. Require the negative control to return a stale promotion at tick crossing. Predict 2, 0, 0, 1 pair evaluations and 1, 0, 0, 1 reductions per arm, with a fresh decline at the crossing.

## Result

| State | Fresh verdict | Receipt pairs / reductions | DAG pairs / reductions |
|---|---|---:|---:|
| Seed | Promote | 2 / 1 | 2 / 1 |
| Irrelevant | Promote | 0 / 0 | 0 / 0 |
| Harmless relevant | Promote | 0 / 0 | 0 / 0 |
| Tick crossing | Decline | 1 / 1 | 1 / 1 |
| **Total** | | **3 / 2** | **3 / 2** |

Both arms matched fresh replay on all four verdicts and all eight scene-pair labels. Each reused both pairs and the verdict on the rename and same-tick delivery edits. When delivery moved to tick 3, each recomputed only the early pair and reduced the verdict again. The late pair retained its result. The omitted-dependency control returned the stale promotion.

Neither arm skipped an evaluation or reduction the other performed. On this fixture the exact eligibility guard accounts for the reuse after the relevant clock edit. The DAG uses that same guard in its pair keys. This test measures work counts for an in-memory model with a supplied certificate. Timing and the cost of obtaining sound margins for contact-rich dynamics are outside the fixture.

Reproduce from the workspace with `python3 -B information/reuse_check.py`. The protocol and script hashes were verified before execution.

- Locked protocol SHA-256 `70fb3a3f3803be133262aa2a7f2f22d218dd118f9660bae2b9a07b093d8f883d`
- Script SHA-256 `9ef3651d9a0caf052cb17288947535299cc5f0364fb250fc78f3d6b6f9bb93e0`
