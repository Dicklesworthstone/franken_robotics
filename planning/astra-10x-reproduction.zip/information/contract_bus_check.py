"""Check time-correlated power contracts for two simulated gripper fingers."""
from itertools import product
import subprocess

def enumerate_actions(ticks):
    actions = tuple(product((0, 1), repeat=2))
    return [schedule for schedule in product(actions, repeat=ticks)
            if all(sum(slot) <= 1 for slot in schedule)
            and all(sum(slot[i] for slot in schedule) >= 1 for i in range(2))]

def generic_check(ticks):
    vars = [[f"i_{t}_{k}" for k in range(2)] for t in range(ticks)]
    smt = ["(set-logic QF_LIA)"]
    for slot in vars:
        for motor in slot:
            smt.extend([f"(declare-const {motor} Int)",f"(assert (and (<= 0 {motor}) (<= {motor} 1)))"])
        smt.append(f"(assert (<= (+ {' '.join(slot)}) 1))")
    for motor in range(2):
        smt.append(f"(assert (>= (+ {' '.join(v[motor] for v in vars)}) 1))")
    smt.append("(check-sat)")
    return subprocess.check_output(["z3","-in"], input="\n".join(smt), text=True).strip()

for ticks in (1,2):
    schedules = enumerate_actions(ticks)
    exact = generic_check(ticks)
    assert (exact == "sat") == bool(schedules)
    print(f"deadline={ticks}; schedules={len(schedules)}; Z3={exact}; example={schedules[:1]}")
