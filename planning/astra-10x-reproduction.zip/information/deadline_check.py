"""Exact COD3 deadline quickie. Run with python3 -B analyses/deadline_check.py."""

from fractions import Fraction as F
from itertools import product


BIAS = (F(-1, 4), F(0), F(1, 4))
MANUFACTURING = F(1, 32)
TOLERANCE = F(3, 8)
ACTION = F(1, 2)
MAX_WIDTH = F(1, 2)
COMMIT_TIME = 1


def window_frontier(belief):
    low, high = min(belief), max(belief)
    padding = TOLERANCE - MANUFACTURING
    return min(MAX_WIDTH, padding - (high - low) / 2,
               ACTION + padding - high, ACTION + padding + low)


def elimination_frontier(belief):
    # Rows a*w + b*u <= c. Check both affine payload endpoints, both
    # manufacturing endpoints, and both signs of the placement error.
    rows = [(0, -1, ACTION), (0, 1, ACTION)]
    for offset, sku_sign, payload_sign, error_sign in product(
        belief, (-1, 1), (-1, 1), (-1, 1)
    ):
        rhs = TOLERANCE + error_sign * (offset + sku_sign * MANUFACTURING)
        rows.append((-error_sign * payload_sign, error_sign, rhs))

    lower = [(a, c) for a, b, c in rows if b == -1]
    upper = [(a, c) for a, b, c in rows if b == 1]
    lo, hi = F(0), MAX_WIDTH
    for (a, c), (b, d) in product(lower, upper):
        slope, bound = a + b, c + d
        if slope > 0:
            hi = min(hi, bound / slope)
        elif slope < 0:
            lo = max(lo, bound / slope)
        elif bound < 0:
            return None
    return hi if lo <= hi else None


def belief_groups(tags, delivery, common_action):
    groups = {}
    for bias, tag in zip(BIAS, tags):
        history = tag if delivery <= COMMIT_TIME and not common_action else None
        groups.setdefault(history, []).append(bias)
    return groups.values()


def synthesize(frontier, budget, delivery=0, common_action=False):
    candidates = []
    for tags in product(range(budget), repeat=len(BIAS)):
        groups = belief_groups(tags, delivery, common_action)
        widths = [frontier(belief) for belief in groups]
        if all(width is not None for width in widths):
            candidates.append((min(widths), tags))
    return max(candidates, key=lambda candidate: candidate[0])


def check_policy(width, commands):
    for offset, command in zip(BIAS, commands):
        assert -ACTION <= command <= ACTION
        for q, payload in product((-MANUFACTURING, MANUFACTURING), (-width, width)):
            assert abs(command - offset - q - payload) <= TOLERANCE


def main():
    scenarios = [
        ("early, one tag", 1, 0, False, F(3, 32)),
        ("early, two tags", 2, 0, False, F(7, 32)),
        ("early, three tags", 3, 0, False, F(11, 32)),
        ("common-action mutant", 3, 0, True, F(3, 32)),
        ("late-label mutant", 3, 2, False, F(3, 32)),
    ]
    for name, budget, delivery, common, expected in scenarios:
        window = synthesize(window_frontier, budget, delivery, common)
        exact = synthesize(elimination_frontier, budget, delivery, common)
        assert window == exact and exact[0] == expected
        # Compare every assignment, including those that lose at the optimum.
        for tags in product(range(budget), repeat=len(BIAS)):
            for belief in belief_groups(tags, delivery, common):
                assert window_frontier(belief) == elimination_frontier(belief)
        print(f"{name}: closed frontier w <= {exact[0]} mm")

    width = F(7, 32)
    check_policy(width, (F(-1, 8), F(-1, 8), F(1, 4)))
    width = F(1, 8)
    required = BIAS[-1] + MANUFACTURING + width - TOLERANCE
    allowed = BIAS[0] - MANUFACTURING - width + TOLERANCE
    assert required == F(1, 32) and allowed == F(-1, 32) and required > allowed
    print("two-tag boundary policy passed all 12 placement corners")
    print(f"mutant witness at w={width}: u >= {required}, u <= {allowed}")


if __name__ == "__main__":
    main()
