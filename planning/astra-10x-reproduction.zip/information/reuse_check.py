"""Exact CC3 duel over the four edits frozen in REUSE_CHECK.md."""

SCENES = (2, 4)
EDITS = (
    ("seed", 1, "Original"),
    ("irrelevant", 1, "Renamed"),
    ("harmless relevant", 2, "Renamed"),
    ("tick crossing", 3, "Renamed"),
)
MODEL = ("camera capture at 0", "deliver before control", "A holds", "B obeys")


def receipt_arm():
    pairs = {}
    prior_scope = None
    for _, delay, _ in EDITS:
        scope = tuple(commit - delay >= 0 for commit in SCENES)
        if scope == prior_scope:
            yield labels, verdict, 0, 0
            continue
        evaluations = 0
        for commit, timely in zip(SCENES, scope):
            previous = pairs.get(commit)
            if previous is None or previous[0] != timely:
                pairs[commit] = timely, evaluate_pair(delay, commit)
                evaluations += 1
        labels = tuple(pairs[commit][1] for commit in SCENES)
        verdict = promote(labels)
        prior_scope = scope
        yield labels, verdict, evaluations, 1


def dag_arm():
    pair_cache, verdict_cache = {}, {}
    for _, delay, _ in EDITS:
        # Canonicalize only after evaluating the same exact clock guard.
        parents = tuple((MODEL, commit, commit - delay >= 0) for commit in SCENES)
        evaluations = 0
        for parent in parents:
            if parent not in pair_cache:
                pair_cache[parent] = evaluate_pair(delay, parent[1])
                evaluations += 1
        labels = tuple(pair_cache[parent] for parent in parents)
        reductions = int(parents not in verdict_cache)
        if reductions:
            verdict_cache[parents] = promote(labels)
        yield labels, verdict_cache[parents], evaluations, reductions


def evaluate_pair(delay, commit):
    """Closed-form positions at the committed action in each design."""
    positions = (0, int(delay <= commit))
    return tuple(position == 1 for position in positions)


def promote(labels):
    return all(not a and b for a, b in labels)


def fresh_replay(delay):
    """Independent time-stepping oracle with no guard or result cache."""
    observations = []
    packet_ready = False
    for tick in range(max(SCENES) + 1):
        if tick == delay:
            packet_ready = True
        if tick in SCENES:
            observations.append((False, packet_ready))
    return tuple(observations), sum(b for _, b in observations) == len(SCENES)


def main():
    expected_work = ((2, 1), (0, 0), (0, 0), (1, 1))
    expected_verdicts = (True, True, True, False)
    print("state | fresh verdict | receipt pairs/reductions | DAG pairs/reductions")
    stale_verdict = fresh_replay(EDITS[0][1])[1]
    for idx, (edit, receipt, dag) in enumerate(zip(EDITS, receipt_arm(), dag_arm())):
        state, delay, _ = edit
        fresh = fresh_replay(delay)
        assert fresh[1] == expected_verdicts[idx]
        print(f"{state} | {fresh[1]} | {receipt[2:]} | {dag[2:]}")
        assert receipt[:2] == dag[:2] == fresh
        assert receipt[2:] == dag[2:] == expected_work[idx]
    assert stale_verdict and not fresh_replay(EDITS[-1][1])[1]
    print("Negative control caught: omitted delivery would inherit Promote.")


if __name__ == "__main__":
    main()
