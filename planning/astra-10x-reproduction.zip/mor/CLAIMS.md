# Claims and audit dispositions

The disposition and any corrected wording come from the signed-off independent record. The claim IDs correspond to the three passes in one study. See the audit JSONL for evidence and counterexamples.

## C001 · VERIFIED

Two exact classifiers agreed on all 11,520 static body–load cases and both the projected and lifted robust LPs attained the same minimum half-width, 3/14 m, in one optimization call apiece.

## C002 · VERIFIED

On the asymmetric corner at half-width 1/4 m the independent-force model admits a maximum load of 155 N in its given witness while the specified equal-spring model yields 175 N on one foot.

## C003 · VERIFIED

The three-law early gripper probe chose the correct pad in 675/675 in-class cases and misranked 225/225 delayed-law cases. Direct target-dwell comparison chose correctly in 900/900 cases.

## C004 · VERIFIED

At binary per-read accuracy 0.75, seven independent measurements yield optimal success 3807/4096, whereas repetitions of a perfectly shared error stay at 0.75.

## C005 · PARTIALLY_SUPPORTED

At the centered nominal readings (q=0.20, tau=1 s, zero realized read errors) with the stated per-pad error intervals, independent additive modules and a 75 N target, the certified minimum masses are 300 g for three compact pads under V and 240 g for two broad pads under P.

## C006 · HYPOTHESIS

Prototype a scoped interface for checked inclusions, exclusions and unresolved cells. Return a distinguishing intervention when one is established in the permitted family, and an ambiguity witness or refusal when none is established. Its integrated utility remains a hypothesis.

## C007 · VERIFIED

Pursue a tenfold reduction in time to an accepted design answer only in workload strata where matched baseline accounting and a sealed comparison show that enough of the critical path can be removed.
