# Robotics design research

## Decision contract

Which research bets would justify pursuing a tenfold reduction in total time or cost per correctly validated robot design decision against the strongest applicable composed existing workflow, or enable a checkable family-level inverse design query? Project author decides. Horizon spans two initial experiments and a later integrated release. Higher loss attaches to a false certificate than to an abandoned prototype. Preserve physics ownership, sensing, native Metal/CUDA and simulation-only experiments. Initial algorithms and benchmark choices are reversible before evaluation. A useful answer specifies mechanisms, competing explanations, refusal behavior, matched baselines and kill tests.

## Evidence index

- E001 Original Astra design, immutable copy in .mor/run-20261121T230034Z/repro/ASTRA-before.md. Sections 4–6 and 13–15 define geometry, contact and existing research bets.
- E002 https://playground.mujoco.org/ documents large-batch policy workflows, system identification and agent-oriented workflows.
- E003 https://developer.nvidia.com/isaac/lab and https://developer.nvidia.com/newton-physics document GPU learning and multiple physics backends.
- E004 https://github.com/allanzhao/RoboGrammar and https://people.csail.mit.edu/jiex/papers/DiffHand/paper.pdf describe graph synthesis and contact-aware design optimization.
- E005 Owner asks for realistic indoor/outdoor worlds, diverse bodies, an algebraic, agent-oriented design studio and a tenfold ambition.
- E006 FrankenSim inspected mechanisms in E001 §2.1. The sustained contact owner uses fixed material witnesses on its admitted interval.
- E007 Calculations or pilot outputs generated under this run's repro directory, to be identified by filename and exact inputs when cited.

- E008 Certified polyhedral collision-free regions at https://arxiv.org/abs/2302.12219 and authored scenario distributions at https://scenic-lang.org/.
- E009 Sensor-alias pilot P03 in the run repro directory. Preregistered equal-prior binary fixture, finite evidence channel and common-mode mutation.
- E010 Inspected sibling source fs-voi/src/lib.rs, fs-sos/src/lib.rs, fs-eproc/src/lib.rs, fs-checker/src/lib.rs and fs-regime/src/lib.rs under frankensim/crates.

## Pivotal unknowns

Which queries admit sound shortcuts at scale? Under what conditions does extra observability actually change the chosen design? How strong a comparator can use the same structure? How should a negative experiment narrow the claim?

## Source access

Public primary sources, pinned local owner checkouts and the original Astra plan. Empirical simulator, robot, native device and field comparisons for these research bets are open.
