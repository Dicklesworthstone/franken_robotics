RESULT_STATUS: MATERIAL_INCREMENT

## Decision

Add a small inverse-design operation to the Astra morphology compiler. Given a fixed planar contact template, a hull of static load wrenches, a declared actuator authority and a packaging domain, return the entire family of allowable stance dimensions and per-foot force ratings, a boundary design and force witnesses or an infeasible load vertex. This is a concrete new advertised query relative to Astra's §§4.2, 5.7, 9.4 and 14.1. Existing convex projection methods provide an equally strong comparator. Fund the typed query and a passive-load-sharing falsifier on one simulation fixture. The experiment provides no support for a tenfold speed claim or a claim of algorithmic priority.

## Family theorem

Take m point contacts with fixed template coordinates q_i in the plane. The physical contacts are p_i=A q_i+d. Let W be the positive net vertical force and P=(Px,Py) its two spatial first moments, in N and N m. A bounded wrench set is supplied as the convex hull of V vertices. Each contact can take any normal force in [0,c_i], simultaneously and independently, with zero tangential demands. Pose, contact set and force authority stay fixed for the mission. Permit a new force allocation for every known static wrench. Distinct dimensions, offsets and leg ratings are shared across all mission vertices.

Set B=A⁻¹, e=−Bd and g_i=(1,q_i). Force/moment balance becomes
```
Σ_i f_i = W                 Σ_i q_i f_i = B P + e W.
```
For a fixed template and mission vertex this is linear in the morphology parameters B,e, in c_i and in vertex-specific f_i. The allowed family is the projection of these equations with 0≤f_i≤c_i onto B,e,c. Intersect it with an affine packaging domain that admits invertible B. For the rectangle take positive bounded inverse half-length and inverse half-width u=1/a,v=1/b. For unrestricted B, determinant/nonconvex packaging must be handled explicitly and may destroy convexity. Applying the inverse transformation to a polyhedron does not make its image polyhedral in physical lengths.

There is also a direct half-space output. In three normalized wrench coordinates, the achievable wrench zonotope is Σ_i [0,c_i]g_i. For each nonzero n=g_i×g_j and every mission vertex v, emit
```
Σ_k min(0,n·g_k)c_k  ≤  n·(W_v, B P_v+e W_v)  ≤  Σ_k max(0,n·g_k)c_k.
```
Necessity follows by projecting each force segment onto n. Sufficiency follows because every facet of the full-dimensional zonotope is parallel to at least two independent generators. Zero ratings are handled by decreasing positive perturbations, compactness and passage to the limit, provided the original template spans three dimensions. Lower-rank templates need their span equations or a separate reduction. Joint validity over the vertices extends to the entire hull by convex combinations, including the force assignments. This is ∃body ∀load ∃forces. A policy can interpolate vertex solutions only with usable wrench observations or a separately validated load-sharing response.

The compiler emits at most 2 V binom(m,2) rows for one full-rank planar template. Pairwise normal precomputation with sign coefficients costs O(m³) scalar operations and storing every dense force-capacity coefficient costs O(m³) before mission instantiation. For general templates the shared-variable lifted LP is often preferable, with Vm force variables and 3V balance equalities. A passed body may still need independent force witnesses or a live contact allocation. Correlated external loads belong in a joint hull. Coupled force authority, unknown contact transitions, finite friction under lateral demand, changing joint-torque leverage, pose-dependent collision, unmodeled changes in body weight and non-affine geometry require a different model, explicit constraints or refusal. A static projection never certifies the run-up, slope, landing or recovery in Astra §13.2.

## Rectangular instance and exact certificate

Foot order is ++,+−,−+,−− at (±a,±b). Define R=(W+u Px)/2 and T=(W+v Py)/2. For any admissible t the normal forces are (t,R−t,T−t,W−R−T+t). The exact interval is
```
max(0,R−c+−,T−c−+,R+T−W) ≤ t ≤ min(c++,R,T,c−−+R+T−W).
```
All 4×4 lower/upper comparisons are affine rows over (u,v,c++,c+−,c−+,c−−) per mission vertex. Conflicting bounds form a short dual certificate through elimination of t. A feasible interval yields a direct independent primal check by force and moment balance.

In Mission A, W=400 N, Px=±60 N m, Py=±30 N m (all four corners and their convex hull). The physical CoM offsets therefore span ±150 mm and ±75 mm. With fixed a=1/3 m and each cap 160 N, minimum half-track b is exactly 3/14 m (full foot-centre spacing 3/7 m), achieved at v=14/3 per metre. At the positive corner, f++≥R+T−W=90+15v and f++≤160 prove v≤14/3. At equality the forces (160,130,110,0) N satisfy all equations. The reflected witnesses prove coverage. This boundary has an unloaded foot and zero overload margin. A strict contact margin must be an input, such as f_i≥f_min>0 and a spare margin on each cap, before re-solving. At b=0.20 m the same corner requires 165 N from a foot limited to 160 N. No candidate sampling or resolution threshold enters this result.

## Preregistered pilot outcome

Preregistered files under .mor/run-20261121T230034Z/repro are P01-prereg.md (SHA-256 e5101ac3ff0a93c82189567670f36ee2f69695bfeaf5033f47e7573200505d9f), P01-inverse.py and P01-results.json. Reproduce with `python3 P01-inverse.py` there. SciPy 1.18.1 HiGHS is used for baseline LP calls. Rational arithmetic carries the equality/witness checks.

| Check | Outcome |
|---|---|
| 2,304 bodies, 4 hull corners and centroid each | 11,520/11,520 classifications agreed between emitted rows and separately constructed physical wrench-zonotope support inequalities. The interval agreed too. |
| Direct allocation checks | 2,254/2,254 feasible body-load states met every bound and all three physical equilibrium equations exactly. 114/2,304 bodies admitted the full hull. |
| Independent conventional fixed-design LP | 102/102 deterministic HiGHS spot checks agreed. |
| Weak comparator | Support polygon plus total capacity accepted 1,596 bodies the model rejects. At u=v=2, caps (80,80,80,160) N and the positive corner, f++≥180 N and f++≤80 N. |
| Strong comparator | One lifted robust LP (22 variables, 12 equalities, 16 inequalities apart from variable bounds) and one projected LP (6 variables, 32 unique inequalities apart from variable bounds) found the same boundary in one optimization call each. Both can retain their formulation for more objectives. No timing result or advantage asserted. |

## Direct falsifier

At a=1/3 m, b=1/4 m, the +60,+30 corner admits the active normal allocation (155,135,105,5) N. Four equal linear passive springs beneath a rigid planar body at small attitude satisfy `f[++] + f[--] = f[+-] + f[-+]`, since spring deflections are affine in position. All four remain loaded. Combining this equation with static balance gives (175,115,85,25) N, exceeding the declared 160 N foot cap by 15 N. The same body, nominal conditions, wrench and individual ratings lead to opposite hardware-design decisions under distinct, plausible authority models. This counterexample is not a general model of a rectangular suspension. It suffices to invalidate unconditional physical admission from the independent-capacity box.

A typed result should carry whether its set is an outer bound, a simultaneously realizable inner set, or exact under stated assumptions. An outer-bound violation can reject an unsupported static load if the bound encloses all physical reactions. A positive only certifies commanded static feasibility with a validated inner support set and sensing/actuation authority. If admission uses a conservative lower rating, failure can mean merely that the proof is inconclusive. A zero contact-load boundary or an unsupported dynamic or sensing assumption should route to the appropriate qualified simulation module. A positive static test cannot stand in for delivery success.

## Costs, comparator and kill experiment

Let baseline end-to-end time per correct decision be T0=S+F, replacement time S/r+F+H, where H includes certificate checking, compilation and integration that the baseline did not need. Tenfold requires (S/T0)(1−1/r) ≥ 0.9 + H/T0. A perfect shortcut with zero overhead must eliminate at least 90% of the strongest workflow's total cost. This pilot's strongest inverse comparator takes one solve and exposes the same family via an extended formulation. Generic projection and actuation-aware static feasibility are established. The opportunity is a verifiable query in the design studio with explicit admissibility, packaging and contact-authority semantics. Cross-template, native-device and whole-decision savings are unmeasured.

For a simulation-only follow-up, give both implementations the same typed stance, mission hull, allowable conservative force model and optimization backend. Compare a stored generic lifted robust LP plus certificate extraction against an emitted projected family on identical new packaging inequalities, disabled feet (zero caps) and alternate cost objectives. Include solver warm start, compilation, source-data preparation, sensor admission, exact verification and owner-side validation of decision finalists in both totals. For a separate correctness kill, simulate the exact equal-spring variant first with neither method permitted to assume arbitrary load redistribution. One false positive fails the certifying interface. If same certificates, inverse queries and costs are available through the lifted formulation, ship the generic implementation and retire the proposed speed advantage. Adding hexapod or skewed templates must not precede a demand or cost case. The general template theorem above is a deduction; only the rectangular instance was run.

## Anchors

- Original plan, immutable reproduction in `.mor/run-20261121T230034Z/repro/ASTRA-before.md`, §§4.1–4.2 (typed model, observation and patch), 5.7–5.8 (viability and symbolic arithmetic), 6.1–6.2 (contact ownership), 9.1/9.4 (stance allocator and joint search), 13.2 (separate dynamic landing mission), 14.1 (compiler and co-design).
- Bretl & Lall, 2008, projection and amortized static-equilibrium testing. [Primary paper](https://lall.stanford.edu/papers/bretl_eqmcut_ieee_tro_projection_2008_08_01_01/pubdata/entry.pdf)
- Orsolino et al., 2020, actuation-aware feasible support regions including joint/contact limits, a stronger physical prior art baseline than support-polygon screening. [Authors' publication page](https://scaron.info/publications/tro-2020.html)
