"""Independent checks for AUD01. Run from this repro directory with Python/SciPy."""
from collections import Counter
from fractions import Fraction as F
from itertools import product
from math import comb, exp
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import numpy as np
from scipy.optimize import linprog

files = [("P01-inverse.py", "P01-results.json"), ("P02-identification.py", "P02-identification-results.json"),
         ("P02-identification-family.py", "P02-identification-family.json"), ("P03-sensor.py", "P03-results.txt")]
for script, receipt in files:
    observed = subprocess.check_output([sys.executable, script])
    assert observed == Path(receipt).read_bytes()
    print("reproduced", script, hashlib.sha256(observed).hexdigest())

def stance():
    loads = [(400, x, y) for x, y in product((60, -60), (30, -30))] + [(400, 0, 0)]
    signs = np.asarray([(1, 1, 1), (1, 1, -1), (1, -1, 1), (1, -1, -1)]).T
    states = feasible = families = 0
    for u, v in product((2,3,4), repeat=2):
        physical = signs / np.array([[1], [u], [v]])
        for caps in product((0,80,160,240), repeat=4):
            labels = []
            for W, X, Y in loads:
                res = linprog([0]*4, A_eq=physical, b_eq=[W,X,Y], bounds=[(0,c) for c in caps], method="highs")
                assert res.status in (0,2)
                R, T = F(W + X*u, 2), F(W + Y*v, 2)
                exact = max(0,R-caps[1],T-caps[2],R+T-W) <= min(caps[0],R,T,caps[3]+R+T-W)
                assert res.success == exact
                labels.append(res.success)
                feasible += res.success
                states += 1
            families += all(labels[:4])
    print("physical LP versus exact interval", states, feasible, families)
    assert (states, feasible, families) == (11520,2254,114)
    forces = np.linalg.solve([[1,1,1,1],[1,1,-1,-1],[1,-1,1,-1],[1,-1,-1,1]],[400,180,120,0])
    assert np.allclose(forces,[175,115,85,25])
    print("passive forces", forces)
    assert F(160-90, 15) == F(14,3)

def response(law, r, t, q, tau):
    s = t/tau
    rate = dict(V=1,P=r**-2,C=min(r,1)**-2,D=r**-2)[law]
    exponent = rate*s
    if law == "D" and r >= 1 and s > .25:
        exponent += ((4-rate)/3-rate)*(s-.25)
    return q+(1-q)*exp(-exponent)

def gripper():
    err = (-.02, 0, .02)
    outcomes = {law: Counter() for law in "VPCD"}
    for law in outcomes:
        for q,tau,e1,e2 in product((.18,.19,.20,.21,.22),(.9,.95,1,1.05,1.1),err,err):
            A = 60*response(law,1,1,q,tau)
            B = 50*response(law,2,1,q,tau)
            direct = A+60*e1-B-50*e2
            assert abs(direct) > 2.2 and (direct>0) == (A>B)
            obs = response(law,2,.125,q,tau)+e2
            # Independently choose a threshold in the certified gap.
            early_A = obs < .944
            outcomes[law]['early_correct' if early_A == (A>B) else 'early_wrong'] += 1
            outcomes[law]['direct_correct'] += 1
    print("synthetic pad grid",outcomes)
    for law in "VP":
        A=60*response(law,1,1,.2,1); B=50*response(law,2,1,.2,1)
        mass,na,nb=min((100*a+120*b,a,b) for a,b in product(range(11),repeat=2) if a*(A-1.2)+b*(B-1)>=75)
        best_lighter=max(a*(A+1.2)+b*(B+1) for a,b in product(range(11),repeat=2) if 100*a+120*b<mass)
        assert best_lighter <75
        print("nominal min mass, counts, best lighter upper", law,mass,na,nb,best_lighter)
    low=3*60*(response("V",1,1,.18,.9)-.04)
    print("three-pad lower for allowed low V reading", low)
    assert low < 75
    high=60*(response("P",1,1,.22,1.1)+.04)+50*(response("P",2,1,.22,1.1)+.04)
    print("lighter one-of-each upper for allowed high P readings", high)
    assert high >=75

def sensor():
    p=F(3,4); q=1-p
    n=7
    majority=sum(F(comb(n,k))*p**k*q**(n-k) for k in range((n+1)//2,n+1))
    assert majority==F(3807,4096)
    # Stop when the running vote difference first reaches magnitude two.
    # Equal pairs resolve a decision; successive mixed pairs restart the experiment.
    confidence=p*p/(p*p+q*q)
    expected=2/(p*p+q*q)
    assert confidence==F(9,10) and expected==F(16,5)
    print("fixed 7 majority; accuracy, expected length under adaptive stopping",majority,confidence,expected)
    
if __name__ == "__main__":
    stance()
    gripper()
    sensor()
