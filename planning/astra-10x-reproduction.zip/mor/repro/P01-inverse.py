"""Exact family-envelope pilot. Run python3 P01-inverse.py; scipy used for baseline LPs."""
from fractions import Fraction as Q
from functools import lru_cache
from itertools import combinations, product
import json
import scipy
from scipy.optimize import linprog

SIGNS = ((1, 1), (1, -1), (-1, 1), (-1, -1))
MISSION = tuple((400, 60 * x, 30 * y) for x, y in SIGNS)
WRENCHES = MISSION + ((400, 0, 0),)


def add(*vectors):
    return tuple(map(sum, zip(*vectors)))


def neg(vector):
    return tuple(-c for c in vector)


def dot(x, y):
    return sum(a*b for a, b in zip(x, y, strict=True))


def cross(a, b):
    return (a[1]*b[2] - a[2]*b[1], a[2]*b[0] - a[0]*b[2], a[0]*b[1] - a[1]*b[0])


@lru_cache(None)
def family_rows(wrench):
    # Inputs (1,u,v,c++,c+-,c-+,c--). Each row tests twice (lower - upper) <= 0.
    w, px, py = wrench
    zero = (0,)*7
    r = (w, px, 0, 0, 0, 0, 0)
    s = (w, 0, py, 0, 0, 0, 0)
    h = (0, px, py, 0, 0, 0, 0)  # twice (R+T-W)
    caps = [tuple(2*int(i == j+3) for i in range(7)) for j in range(4)]
    lower = (zero, add(r, neg(caps[1])), add(s, neg(caps[2])), h)
    upper = (caps[0], r, s, add(caps[3], h))
    return tuple(add(lo, neg(hi)) for lo in lower for hi in upper)


def interval(wrench, design):
    w, px, py = wrench
    u, v, c0, c1, c2, c3 = design
    r, s = Q(w+px*u, 2), Q(w+py*v, 2)
    lo, hi = max(0, r-c1, s-c2, r+s-w), min(c0, r, s, c3+r+s-w)
    if lo > hi:
        return lo, hi, None
    t = Q(lo+hi, 2)
    return lo, hi, (t, r-t, s-t, w-r-s+t)


@lru_cache(None)
def geometry(u, v):
    cols = tuple((1, Q(x,u), Q(y,v)) for x,y in SIGNS)
    return cols, tuple(tuple(cross(a,b)) for a,b in combinations(cols, 2))


@lru_cache(None)
def slabs(u, v, caps):
    # Every facet of a full-dimensional 3D zonotope is parallel to two generators.
    # Zero-cap cases follow by closedness on decreasing positive cap perturbations.
    cols, normals = geometry(u,v)
    out = []
    for normal in normals:
        weighted = [dot(normal,g)*c for g,c in zip(cols,caps)]
        out.append((normal, sum(min(0,d) for d in weighted),sum(max(0,d) for d in weighted)))
    return tuple(out)


def static_lp(wrench, design):
    u,v,*caps = design
    cols,_ = geometry(u,v)
    result = linprog([0]*4, A_eq=list(zip(*cols)), b_eq=wrench, bounds=[(0,c) for c in caps],
                     method="highs")
    assert result.status in (0,2), result.message
    return result.success


def lifted_inverse():
    # Ambient variables u,v,c0..c3, then four force allocations (one per corner).
    n = 6+4*len(MISSION)
    eq, rhs, ineq = [], [], []
    for j,(w,px,py) in enumerate(MISSION):
        start = 6+4*j
        for k,coeff in enumerate(((1,)*4, tuple(x for x,y in SIGNS), tuple(y for x,y in SIGNS))):
            row = [0]*n
            row[start:start+4] = coeff
            if k:
                row[k-1] = (-px,-py)[k-1]
            eq.append(row)
            rhs.append(w if k == 0 else 0)
        for i in range(4):
            row = [0]*n
            row[start+i], row[2+i] = 1, -1
            ineq.append(row)
    objective = [0,-1]+[0]*(n-2)
    bounds = [(3,3),(2,6)]+[(160,160)]*4+[(0,None)]*(n-6)
    result = linprog(objective,A_eq=eq,b_eq=rhs,A_ub=ineq,b_ub=[0]*len(ineq),bounds=bounds,method="highs")
    assert result.success
    return result.x[1], {"variables":n,"eq":len(eq),"ineq":len(ineq),"optimization_calls":1}


def projected_inverse():
    rows = sorted(set(row for w in MISSION for row in family_rows(w)))
    result = linprog([0,-1,0,0,0,0],A_ub=[r[1:] for r in rows], b_ub=[-r[0] for r in rows],
                     bounds=[(3,3),(2,6)]+[(160,160)]*4, method="highs")
    assert result.success
    return result.x[1], {"variables":6,"eq":0,"ineq":len(rows),"optimization_calls":1}


def run():
    states = feasible_states = robust_designs = lp_checks = designs = weak_false_approvals = 0
    weak_example = None
    for u,v in product((2,3,4),repeat=2):
        for caps in product((0,80,160,240), repeat=4):
            design=(u,v,*caps)
            admitted, weak_admitted = [], []
            for wrench in WRENCHES:
                h = all(dot(row,(1,*design)) <= 0 for row in family_rows(wrench))
                z = all(lo <= dot(normal,wrench) <= hi for normal,lo,hi in slabs(u,v,caps))
                lo,hi,force = interval(wrench, design)
                assert h == z == (force is not None), (design,wrench,h,z,lo,hi)
                if force is not None:
                    cols,_=geometry(u,v)
                    assert all(0<=f<=c for f,c in zip(force,caps))
                    assert tuple(dot(row,force) for row in zip(*cols)) == wrench
                    feasible_states += 1
                if states % 113 == 37:
                    assert h == static_lp(wrench, design)
                    lp_checks+=1
                admitted.append(h)
                w,px,py=wrench
                weak_admitted.append(sum(caps)>=w and abs(px*u)<=w and abs(py*v)<=w)
                states+=1
            robust_designs += int(all(admitted[:4]))
            if all(weak_admitted[:4]) and not all(admitted[:4]):
                weak_false_approvals += 1
                if weak_example is None and min(caps) > 0:
                    j = admitted.index(False)
                    weak_example = {"design":design,"wrench":WRENCHES[j],"conflicting_t_interval":
                                    interval(WRENCHES[j],design)[:2]}
            designs+=1
    v1,p = projected_inverse()
    v2,l = lifted_inverse()
    optimum=Q(14,3)
    assert abs(v1-float(optimum)) < 1e-12 and abs(v2-float(optimum)) < 1e-12
    corner = MISSION[0]
    boundary = [interval(w,(3,optimum,160,160,160,160)) for w in MISSION]
    assert all(f is not None for lo,hi,f in boundary)
    assert interval(corner,(3,5,160,160,160,160))[:2] == (165,160)
    passive_design=(3,4,160,160,160,160)
    w,px,py=corner
    r,s=Q(w+px*3,2),Q(w+py*4,2)
    t=(2*r+2*s-w)/4
    passive_force=(t,r-t,s-t,w-r-s+t)
    assert min(passive_force)>0 and max(passive_force)-160==15
    return {"scipy":scipy.__version__,"designs":designs,"robust_feasible_designs":robust_designs,
            "states":states,"feasible_states_primal_verified":feasible_states,
            "exact_mismatches":0,"highs_fixed_lp_checks":lp_checks,"weak_false_approvals":weak_false_approvals,
            "weak_counterexample":weak_example,"projected":dict(p,optimum_v=v1),"lifted":dict(l,optimum_v=v2),
            "exact_optimum_v":optimum,"exact_minimum_halftrack_m":1/optimum,
            "boundary_witnesses":boundary,"beyond_boundary_t_conflict":[165,160],
            "adjustable_example":interval(corner,passive_design),"passive_spring_forces":passive_force,
            "passive_spring_excess_N":15}


if __name__ == "__main__":
    print(json.dumps(run(), default=str, indent=2))
