"""Post-pilot calculation: enumerate the independently supported-pad assembly family."""
import itertools
import json
import pathlib

root = pathlib.Path(__file__).resolve().parent
data = json.loads((root / "P02-identification-results.json").read_text())
# At the mission dwell use centered synthetic measurements. Each sample has bounded
# normalized error 0.02 and conversion to pull is mu times the initial normal force.
error = {"A": 1.2, "B": 1.0}
rows = {}
for law, loads in data["nominal_pull_capacity_N"].items():
    assemblies = []
    for a, b in itertools.product(range(4), repeat=2):
        lo = a * (loads["A"] - error["A"]) + b * (loads["B"] - error["B"])
        hi = a * (loads["A"] + error["A"]) + b * (loads["B"] + error["B"])
        assemblies.append({"mass_g": 100*a + 120*b, "a": a, "b": b,
                           "lower_N": lo, "upper_N": hi})
    best = min((row for row in assemblies if row["lower_N"] >= 75), key=lambda row: row["mass_g"])
    lighter = [row for row in assemblies if row["mass_g"] < best["mass_g"]]
    runner = max(lighter, key=lambda row: row["upper_N"])
    assert runner["upper_N"] < 75
    # At least four pads are heavier than the witnessed optimum.
    assert 4 * 100 > best["mass_g"]
    rows[law] = {"best": best, "highest_upper_bound_among_lighter": runner}
print(json.dumps(rows, indent=2))
