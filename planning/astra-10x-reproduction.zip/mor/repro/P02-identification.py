"""Finite, preregistered contact-witness discrimination pilot; uses only stdlib."""
import itertools
import json
import math
from collections import Counter

RADII = (0.25, 0.5, 1, 1.5, 2, 3)
TIMES = (0.0625, 0.125, 0.25, 0.5, 1, 2)
Q_GRID = (0.18, 0.19, 0.20, 0.21, 0.22)
TAU_GRID = (0.90, 0.95, 1.0, 1.05, 1.10)
EPSILON = 0.02
ERRORS = (-EPSILON, 0, EPSILON)
LAWS = ("V", "P", "C", "D")
SETUP = 0.25
MU = 0.5
F0_A = 120
F0_B = 100
MISSION = (2, 1)
PROBES = tuple(itertools.product(RADII, TIMES))


def ratio(law, r, t, q, tau):
    s = t / tau
    if law == "V":
        exposure = s
    elif law == "P":
        exposure = s / r**2
    elif law == "C":
        exposure = s / min(r, 1)**2
    elif law == "D":
        if r < 1:
            exposure = s / r**2
        else:
            k = 1 / r**2
            exposure = k * min(s, 0.25) + (1 + (1-k)/3) * max(s-0.25, 0)
    else:
        raise ValueError(law)
    return q + (1 - q) * math.exp(-exposure)


def predictions(law, probe, error=EPSILON):
    # For each law, positive exposure decreases with tau and load increases with q.
    lo = ratio(law, *probe, min(Q_GRID), min(TAU_GRID))
    hi = ratio(law, *probe, max(Q_GRID), max(TAU_GRID))
    return lo - error, hi + error


def side(lo, hi):
    if lo > 0:
        return "A"
    if hi < 0:
        return "B"
    return "refusal"


def decision_enclosure(law):
    # Independent outward bounds suffice; retaining shared q/tau can tighten them.
    a0, a1 = predictions(law, (1, 1), 0)
    b0, b1 = predictions(law, MISSION, 0)
    return (MU * (F0_A * a0 - F0_B * b1),
            MU * (F0_A * a1 - F0_B * b0))


def strict_separation(interval1, interval2):
    return interval1[1] < interval2[0] or interval2[1] < interval1[0]


def synthesize(laws):
    labels = {law: side(*decision_enclosure(law)) for law in laws}
    if "refusal" in labels.values():
        raise ValueError("generating model can reverse its choice within a nuisance cell")
    opposite = [(x, y) for x, y in itertools.combinations(laws, 2) if labels[x] != labels[y]]
    feasible = []
    for r, t in PROBES:
        outcome = {law: predictions(law, (r, t)) for law in laws}
        if all(strict_separation(outcome[x], outcome[y]) for x, y in opposite):
            feasible.append((SETUP + t, r, t))
    if not feasible:
        raise ValueError("no single probe separates all opposite decisions")
    _, r, t = min(feasible)
    return r, t


def hand_expert():
    # V/C select A, P selects B. Scan in cost order, treating all geometry as available.
    for t in TIMES:
        for r in RADII:
            p = predictions("P", (r, t))
            v = predictions("V", (r, t))
            c = predictions("C", (r, t))
            if strict_separation(v, p) and strict_separation(c, p):
                return r, t
    raise ValueError("expert found no probe")


def choose_from_sample(laws, probe, y):
    choices = set()
    for law in laws:
        lo, hi = predictions(law, probe)
        if lo <= y <= hi:
            choices.add(side(*decision_enclosure(law)))
    return choices.pop() if len(choices) == 1 else "refusal"


def direct_choice(archived, observed):
    margin = MU * (F0_A * archived - F0_B * observed)
    uncertainty = MU * (F0_A + F0_B) * EPSILON
    return side(margin - uncertainty, margin + uncertainty)


def evaluate(name, probe, laws):
    r, t = probe
    scored = {}
    for truth in LAWS:
        counts = Counter({"correct": 0, "wrong": 0, "refusal": 0})
        example = None
        for q, tau, ea, ep in itertools.product(Q_GRID, TAU_GRID, ERRORS, ERRORS):
            a = ratio(truth, 1, 1, q, tau)
            b = ratio(truth, *MISSION, q, tau)
            true_margin = MU * (F0_A * a - F0_B * b)
            true_label = side(true_margin, true_margin)
            assert true_label != "refusal"
            observation = ratio(truth, r, t, q, tau) + ep
            if name == "direct":
                label = direct_choice(a + ea, observation)
            elif name == "passive":
                label = "refusal"
            else:
                label = choose_from_sample(laws, probe, observation)
            category = "refusal" if label == "refusal" else ("correct" if label == true_label else "wrong")
            counts[category] += 1
            if category == "wrong" and example is None:
                example = dict(q=q, tau=tau, archived_error=ea, sample_error=ep,
                               y=observation, chosen=label, true=true_label, true_margin_N=true_margin)
        scored[truth] = {"counts": dict(counts), "first_wrong": example}
    return {"probe": probe if name != "passive" else None,
            "modeled_cost_seconds": SETUP + t if name != "passive" else 0,
            "per_law": scored}


def main():
    schedules = {
        "sealed_two": (synthesize(("V", "P")), ("V", "P")),
        "sealed_three": (synthesize(("V", "P", "C")), ("V", "P", "C")),
        "hand_expert_three": (hand_expert(), ("V", "P", "C")),
        "direct": (MISSION, ()),
        "passive": ((1, 1), ()),
    }
    results = {name: evaluate(name, probe, laws) for name, (probe, laws) in schedules.items()}
    for record in results.values():
        assert all(sum(row["counts"].values()) == 225 for row in record["per_law"].values())
    print(json.dumps({
        "nuisance_count_per_law": 25, "error_pairs_per_nuisance": 9, "n_probes": len(PROBES),
        "nominal_pull_capacity_N": {
            law: {"A": MU * F0_A * ratio(law, 1, 1, 0.2, 1),
                  "B": MU * F0_B * ratio(law, *MISSION, 0.2, 1)} for law in LAWS
        },
        "conservative_margin_enclosure_N": {law: decision_enclosure(law) for law in LAWS},
        "observed_intervals": {
            name: {law: predictions(law, probe) for law in LAWS}
            for name, (probe, _) in schedules.items() if name in ("sealed_two", "sealed_three")
        },
        "results": results
    }, indent=2))


if __name__ == "__main__":
    main()
