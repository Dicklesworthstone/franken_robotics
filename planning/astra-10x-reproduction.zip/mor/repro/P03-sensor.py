from fractions import Fraction as F
from itertools import product
from math import comb

def likelihood(seq, latent, errors, shared):
    mismatches = sum(x != latent for x in seq)
    if not seq:
        return F(1)
    if shared:
        if mismatches == len(seq):
            return errors
        return 1 - errors if mismatches == 0 else 0
    return errors**mismatches * (1-errors)**(len(seq)-mismatches)

def optimal(n, error, shared):
    histories = list(product(range(2),repeat=n))
    pairs = [(likelihood(h,0,error,shared),likelihood(h,1,error,shared)) for h in histories]
    assert all(sum(p[i] for p in pairs)==1 for i in range(2))
    success = sum(max(p) for p in pairs)/2
    tv = sum(abs(a-b) for a,b in pairs)/2
    assert success == (1+tv)/2
    return success

for n in (0,1,3,5,7,9):
    print(f"n={n} independent={optimal(n,F(1,4),False)} common={optimal(n,F(1,4),True)}")
print("one independent alternative sensor",optimal(1,F(1,20),False))
