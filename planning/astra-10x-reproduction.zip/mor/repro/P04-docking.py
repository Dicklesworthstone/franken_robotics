"""Exact constructive and late-observation checks for a three-tick docking mission."""
from fractions import Fraction as F
from itertools import product

def simulate(gain, commands):
    position = velocity = F(0)
    for command in commands:
        assert abs(command) <= F(3, 4)
        position += velocity + gain * command / 2
        velocity += gain * command
        yield position, velocity

for gain in [1, 2]:
    first = F(1, 4)
    first_position, observed_velocity = next(simulate(gain, [first]))
    estimated_gain = 4 * observed_velocity
    second = 1 / estimated_gain - F(1, 2)
    commands = (first, second, -first - second)
    path = list(simulate(gain, commands))
    assert path[-1] == (F(1), F(0))
    print("observed gain", gain, "commands", *(str(v) for v in commands), "final", *(str(v) for v in path[-1]))
# For any common command vector, x3 scales linearly with gain. Check the
# three unit input responses exactly by using a common in-bounds amplitude.
gains = (1, 2)
for axis in range(3):
    commands = [F(1, 4) if i == axis else F(0) for i in range(3)]
    final = [list(simulate(g, commands))[-1] for g in gains]
    assert all(v2 == 2 * v1 for v1, v2 in zip(*final))
print("late-only observation: incompatible required base positions 1 and 1/2")
