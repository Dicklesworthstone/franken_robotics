"""Cross-check exact three-tick docking region with a scenario-tree linear program."""
from fractions import Fraction as F
from scipy.optimize import linprog

def integrate(gain, inputs):
    pos, vel = F(0), F(0)
    for command in inputs:
        pos += vel + gain * command / 2
        vel += gain * command
    return pos, vel

def model(gain):
    columns = [integrate(gain, [F(j == k) for j in range(3)]) for k in range(3)]
    return list(zip(*columns))

def compare_commands(bound, locked=None):
    rows, target = [], []
    for gain, indices in [(1,(0,1,2)), (2,(0,3,4))]:
        for coefficients,rhs in zip(model(gain),(1,0)):
            row = [0.0]*5
            for idx,k in zip(indices,coefficients):
                row[idx] = float(k)
            rows.append(row)
            target.append(rhs)
    bounds = [(-float(bound),float(bound))]*5
    if locked is not None:
        bounds[0] = (float(locked),float(locked))
    separation = []
    for sign in [-1,1]:
        obj = [-sign,0,0,0,0]   # difference of first readings in the two gains is u0
        sol = linprog(obj,A_eq=rows,b_eq=target,bounds=bounds,method='highs')
        assert sol.success
        separation.append(-sol.fun)
    equality = [[0,1,0,-1,0],[0,0,1,0,-1]]
    shared = linprog([0]*5,A_eq=rows+equality,b_eq=target+[0,0],bounds=bounds,method='highs')
    assert shared.status == 2
    return max(separation)

counts = dict(cells=0, admitted=0, excluded=0, equality=0, late_excluded=0)
for idx in range(17):
    bound = F(1,2)+F(idx,32)
    exact = (bound+F(1,2))/2
    lp = compare_commands(bound)
    assert abs(float(exact)-lp) < 1e-9
    for j in range(33):
        eps = F(j,64)
        expected = 2*eps < exact
        observed = lp-2*float(eps) > 1e-9
        assert observed == expected
        counts['cells'] += 1
        counts['admitted' if expected else 'excluded'] += 1
        counts['equality'] += (2*eps == exact)
        counts['late_excluded'] += 1
    probe = exact
    for g in (1,2):
        second = F(1,g)-2*probe
        commands = [probe,second,-probe-second]
        assert all(abs(u) <= bound for u in commands)
        assert integrate(g,commands) == (1,0)
print(counts)
bound = F(3,4)
assert compare_commands(bound,F(1,4)) == 0.25
print("U=3/4: fixed first command 1/4: epsilon < 1/8; optimized first command 5/8: epsilon < 5/16")
center = F(15,16)
assert center == F(5,8)+F(5,16) == 2*F(5,8)-F(5,16)
print("at epsilon=5/16 both gains admit reading", center, "but require distinct second commands -1/4 and -3/4")
