# Franken Robotics · reproducible design experiments

Unzip the companion into an empty directory. From the directory containing this README, run the standard-library checks with

```sh
python3 -B verify.py
```

For all checks install NumPy and SciPy into your selected Python environment and place the Z3 executable on PATH. The recorded native environment used CPython 3.15.0, NumPy 2.5.4, SciPy 1.18.1 with its bundled HiGHS interface, and Z3 4.15.4 on arm64 macOS. Use those versions for strict byte comparisons. A library version appears in the P01 JSON, and other environments can differ in last-place floating-point output.

```sh
python3 -B verify.py --all
```

The runner checks SHA-256 for each bundled file except the checksum list itself. Each pilot can also be run separately. Standard output carries the new result. The commands below preserve the reference receipts.

## What is in the archive

| Location | Question and checks |
|---|---|
| `mor/MOR_CASE.md`, `mor/CLAIMS.md`, `mor/audit/` | Decision contract, seven audited claim dispositions and independent findings. P01–P03 were three passes within run 20261121T230034Z. Evidence ID E001 refers to the original Astra plan held in the source study. Each fixture here contains its own numerical inputs. |
| `mor/raw/` | Original author notes from all three passes. Consult the independent audit for subsequent corrections and bounds. Paths beginning with `.mor/run-20261121T230034Z/` in the notes correspond to `mor/` in this archive. |
| `mor/repro/P01-*` | Protocol, driver and original result for static stance feasibility. The projected and lifted formulations both return half-width 3/14 m under adjustable force authority. The passive equal-spring example violates one 160 N rating by 15 N. |
| `mor/repro/P02-*` | Protocol, driver, force-law results and post-pilot additive-pad family calculation. The three-law early observation failed on all 225 delayed-law cases. The direct target-dwell method succeeded on all 900 deterministic combinations. The 300 g and 240 g designs are certified at the centered nominal readings. The independent audit supplies counterexamples to extending those certificates over all readings. |
| `mor/repro/P03-*` | Binary-sensor protocol, script and exact Bayes results for fixed horizons and two error-dependence assumptions. The independent audit also considers an adaptive stopping rule. |
| `mor/repro/AUD01-recheck.py` | Independent recheck of the published P01–P03 outputs, including a generic four-force linear program on all 11,520 stance cases, gripper counterexamples and the sensor calculation. |
| `mor/repro/P04-docking.*` | Subsequent exact three-tick construction for gains 1 and 2, a bounded command, a first-pulse velocity measurement, and the common-command late-observation comparison. Both observed-gain schedules reach position 1 with zero velocity. This fixture was added after the seven-claim audit. |
| `mor/repro/P05-docking-family.*`, `P05-docking-family-prereg.md` | Protocol, scenario-tree LP driver and receipt for a noisy early velocity reading. Across 561 error/bound pairs, 344 admit exact docking and 217 fail, including nine closed-boundary equalities. All 561 late-only observations fail. The archive verifier also derives the feasible first-command interval directly using rational inequalities. |
| `pusher/PILOT_LOCK.md`, `pilot.py`, `pilot_check.py`, `PILOT_RUN.json` | Locked 10-fixture pusher protocol, two solution methods, separate checker and original timing receipt. Each arm matched 20 intervals and the checker rejected six deliberately wrong certificates. The recorded composed/specialized median ratios were 1.345× warm and 1.088× cold. Timings include certificate acceptance and follow the locked host protocol. |
| `pusher/check_locked_pusher_z3.py`, `pusher/queries/`, `pusher/pusher-z3*.json` | Independent SMT generator, 21 literal SMT-LIB queries, final receipt and two earlier tactic receipts. The final run returned UNSAT on all 20 mismatch queries and SAT on the deliberate over-exclusion. The QSAT attempt returned unknown on all queries. QE2 timed out on the `shared-tight/shared` query and the mutant. |
| `sill/promotion_rule.*` | Enumeration of the original 64-pair development decision rule over 2,145 legal discordance-count pairs. Zero qualify for a practical tie. When A-only count is zero, B needs 15 B-only results for promotion. The all-concordant interval first fits the tie margin at 86 pairs. |
| `sill/quasistatic_sill.*` | Two-stage planar statics for 12 wheel/edge/payload combinations. Each stage samples 400 edge angles. Under the modeled uniform friction range, 3/12 design cells have positive modeled success fraction. The calculation excludes impact momentum, active controller transients, other collision modes and out-of-plane motion. Sampled maxima provide a diagnostic baseline. They do not prove dynamic mission success or continuous-angle sufficiency. |

## Selected commands

```sh
(cd mor/repro && python3 -B P01-inverse.py)
(cd mor/repro && python3 -B P02-identification.py)
(cd mor/repro && python3 -B P02-identification-family.py)
(cd mor/repro && python3 -B P03-sensor.py)
(cd mor/repro && python3 -B P04-docking.py)
(cd mor/repro && python3 -B P05-docking-family.py)
(cd mor/repro && python3 -B AUD01-recheck.py)
python3 -B pusher/pilot.py --arm specialized
python3 -B pusher/pilot.py --arm composed
python3 -B pusher/pilot.py
python3 -B pusher/check_locked_pusher_z3.py
z3 -T:5 pusher/queries/wide-adjustable.smt2
z3 -T:5 pusher/queries/mutant-wide-adjustable.smt2
python3 -B sill/promotion_rule.py
python3 -B sill/quasistatic_sill.py
```

The pusher driver without `--arm` runs the original negative controls and nine warm and nine fresh-process timing pairs; elapsed times vary by host and load. The Z3 generator reconstructs its queries from the fixture table. A real discrepancy is satisfiable. Solver timeouts and unknowns leave that check unresolved.

The original three protocols, source, raw notes, receipts and audit are included. The archived pusher lock localizes its final source-footnote links. Its source-file SHA-256 before that editorial change was `a25ee5b331516a060c84056b83bdfe38cbca0f27b59665eb48c87c68f750ef30`. This package covers bounded scalar, statistical and analytic work. Whether it speeds a complete, independently validated robot design decision remains open. Native dynamics, device execution and physical acquisition require their own evidence.

## Native screens, planar comparison and information experiments

The default verifier rechecks the native source manifests, regenerates the ordered binary32 and integer outputs on any platform with standard Python, compares the results with both native receipts, and replays two information experiments. The full verifier also reproduces the 156-condition planar calculation and compares the labels with sampled statics. Native dispatch is optional for replay; its original device evidence is bundled.

| Location | Contents |
|---|---|
| `native/metal/`, `native/metal/integer/` | Apple M5 Ultra guarded float32 and exact uint32. Each folder has its separate prediction lock, Objective-C++ host, MSL, Python driver, source checksums, complete receipt, and build/run instructions in its README. |
| `native/cuda/` | RTX 4090 guarded float32 on device 0, device 1, and both devices. The signed-int32 follow-up used device 0. TOOLCHAIN.md gives exact compiler options and commands. Protocols, source, terminal results, ordered output digests, SM 8.9 disassembly and the aggregate JSON receipt are included. |
| `sill/CRITIC.md` | Corrected scope of the planar and static experiments, final critic source, independent audit, 156-case detailed output and compact sensitivity results. |
| `information/` | Exact deadline/tag script and notes, plus independent fresh replay versus two update-reuse methods on four camera delivery states. The stored stdout transcripts were regenerated while packaging. |
| `original-package/` | Original README, verifier, and checksum list from the first 59-file companion. All original study files retain their previous bytes. Run the current verifier from the archive root. |

Fresh host timing depends on driver, cache state, scheduling and hardware. The Metal warm timer covers input packing through completed host result buffers; the independent Python audit runs separately. CUDA's warm timer includes host auditing. CUDA receipts retain first-call timing and the minimum, median and maximum of 21 warm calls; Metal receipts also retain individual repetitions. Compare each native path with its same-host baseline under the same harness. These devices executed a scalar docking-boundary test. End-to-end robot dynamics, sensor pipelines and integrated product speed remain open.
