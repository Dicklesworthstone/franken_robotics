# CUDA strict-facet decision pilot

Two physical RTX 4090s ran the registered float32 kernel on the 65,536-row near grid and again on the 65,536-row separated grid. Each card ran both grids individually, then both ran concurrent contiguous half-grids. All three placements produced identical raw, three-way and final decision bytes. All 18 SHA-256 comparisons to the Metal receipt matched. Each arm has 34,590 exact includes, 30,946 excludes and 1,820 exact ties.

| Arm | Raw false include | Raw false exclude | Device decisions outside guard | Exact host fallback | Guarded mistakes |
|---|---:|---:|---:|---:|---:|
| Near | 452 | 23,438 | 0 / 65,536 (0%) | 65,536 | 0 |
| Separated | 110 | 4,779 | 58,254 / 65,536 (88.8885%) | 7,282 | 0 |

Each concurrent near shard fell back on all 32,768 rows. The first shard corrected 11,935 raw mistakes, the second 11,955. Each separated shard resolved 29,127/32,768 on device and used 3,641 host fallbacks. Those corrected 2,442 and 2,447 raw mistakes respectively. RECEIPT.json contains full per-shard counts, ties and timing ranges.

## Placement economics

Times are milliseconds. Each cold observation comes from one fresh-process call on pre-generated host inputs, including runtime and allocation. Warm observations are medians from 21 calls with retained device allocations. CUDA measurements include input copy, kernel, device fence, host copy, any exact fallback and final audit. The two-device run includes host worker dispatch. CPU timing includes results materialization and the same audit. Data generation, compilation, SSH, disk and process startup before the timer are excluded.

| Execution | Near cold | Near warm | Separated cold | Separated warm |
|---|---:|---:|---:|---:|
| CPU exact integer | 2.113 | 0.781 | 0.786 | 0.423 |
| Guarded float32 CUDA, GPU 0 | 2,241.26 | 1.660 | 1,312.99 | 1.363 |
| Guarded float32 CUDA, GPU 1 | 1,641.33 | 1.248 | 1,637.91 | 1.631 |
| Guarded float32 CUDA, two shards | 6,054.83 | 2.555 | 15,136.30 | 4.392 |
| Exploratory direct int32 CUDA, GPU 0 | 1,145.42 | 0.947 | 877.882 | 1.157 |

The single-host-thread integer implementation won both warm medians on these host-resident decisions. Clocks, driver initialization and system scheduling were uncontrolled. The arm order was fixed and each cold call has one observation. Device-resident inputs and full controller pipelines require a separate measurement.

## Roundoff and exact integer comparison

U is in [0.5,1] and E is near [0.25,0.375], with perturbations at most 8,192 ticks of 2^-28 plus one truncation tick. Original integer ticks reach device memory. Under correctly rounded conversions and exact power-of-two scaling, U's error is at most 2^-25 and E's is at most 2^-26. The rounded addition U+0.5 contributes at most 2^-24. Multiplication of E by four is exact, and subtraction of these neighboring positive floats is exact by Sterbenz's lemma. Total residual error is at most 5·2^-25, below 2^-21. A residual outside that guard has the correct strict sign under these assumptions. Exact fallback requires original tick data.

The separately registered exploratory CUDA int32 kernel evaluated the inequality directly. Both products and sums fit signed int32 on this domain. On GPU 0 it classified every row on device in both arms with zero errors and zero fallback. The result gives a stronger comparator for rational, range-checked facets. An approximate fitted coefficient or a potentially overflowing product requires different error analysis.

## Reproduction

The toolchain was CUDA 12.4.131 and g++-13 13.4 on Linux, with native sm_89 machine code and floating contraction disabled. The kernel, complete host path and CPU comparator are in screen.cu. Use either near or far for each mode. Build native-int32.cu with identical options to reproduce the exploratory device 0 run.

```sh
nvcc -O3 --std=c++17 --fmad=false -arch=sm_89 -ccbin=/usr/bin/g++-13 -Xcompiler=-pthread screen.cu -o screen
./screen cpu near
./screen 0 near
./screen 1 near
./screen dual near
```

The directory also includes both registrations, original native timing records, device identities and driver versions, disassembly, a companion canonical byte emitter and its terminal digest record. The machine-readable summary is RECEIPT.json.
