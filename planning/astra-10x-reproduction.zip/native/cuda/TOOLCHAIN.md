# CUDA build and replay

The recorded Linux x86-64 system used CUDA 12.4.131, NVIDIA driver 595.99.02 and host g++-13 13.4.0. Both device indices 0 and 1 were GeForce RTX 4090 GPUs with compute capability 8.9 and 24,564 MiB each. The CPU comparator ran on an AMD Ryzen Threadripper PRO 5995WX. Device UUIDs and bus addresses are omitted. Original timing receipts retain hashes of the measured executables for identification. Rebuild the three sources locally.

From this directory, the original compiler options were

```sh
nvcc -O3 --std=c++17 --fmad=false -arch=sm_89 -ccbin=/usr/bin/g++-13 -Xcompiler=-pthread screen.cu -o screen
nvcc -O3 --std=c++17 --fmad=false -arch=sm_89 -ccbin=/usr/bin/g++-13 -Xcompiler=-pthread native-int32.cu -o native-int32
nvcc -O3 --std=c++17 --fmad=false -arch=sm_89 -ccbin=/usr/bin/g++-13 -Xcompiler=-pthread emit-canonical.cu -o emit-canonical
for arm in near far; do
  ./screen cpu "$arm"
  ./native-int32 0 "$arm"
  for mode in 0 1 dual; do
    ./screen "$mode" "$arm"
    ./emit-canonical "$mode" "$arm"
  done
done
sha256sum -c canonical-hashes.txt
```

The dual mode needs two supported GPUs. On one GPU, run device 0 and compare only the corresponding digest rows. The canonical emitter produces raw, three-way guarded, and exact-resolved bytes for the guarded CUDA implementation. The exact-device variant was exercised on GPU 0. Its receipt records per-row mismatches against the independent integer referee.
