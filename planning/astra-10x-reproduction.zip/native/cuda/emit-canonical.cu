// Optional third-party comparison. Reuse the timed kernel, preserve row order, and serialize
// native, three-way (unknown=2), then host-refereed decisions after the fenced copy.
#define main timed_program_main
#include "screen.cu"
#undef main
#include <fstream>

int main(int argc,char** argv) {
    if (argc != 3) return 2;
    const std::string mode=argv[1], arm=argv[2], prefix=mode+"-"+arm;
    const int scale=arm=="near"?1:2048;
    std::vector<Input> inputs;
    std::vector<byte> reference;
    for(int i=0;i<count_rows;++i) {
        int u=half_ticks+((int64_t(i)*65537)%(half_ticks+1LL));
        int e=(u+half_ticks)/4+(i%9-4)*scale;
        inputs.push_back({u,e});
        reference.push_back(e<=(static_cast<int64_t>(u)+half_ticks-1)/4);
    }
    std::vector<Worker> jobs;
    if(mode=="dual") {
        jobs.push_back({0,0,count_rows/2});
        jobs.push_back({1,count_rows/2,count_rows/2});
    } else {
        jobs.push_back({std::stoi(mode),0,count_rows});
    }
    if(jobs.size()==2) {
        auto second=std::async(std::launch::async,[&]{ return jobs[1].call(inputs,reference); });
        jobs[0].call(inputs,reference); second.get();
    } else jobs[0].call(inputs,reference);
    std::ofstream raw(prefix+".raw",std::ios::binary);
    std::ofstream tri(prefix+".tri",std::ios::binary);
    std::ofstream final(prefix+".final",std::ios::binary);
    for(auto& j:jobs) {
        for(int i=0;i<j.n;++i) {
            byte flag=j.host[i], decision=flag&1;
            bool fallback=(flag&2)!=0;
            raw.put(decision); tri.put(fallback?2:decision);
            final.put(fallback?integer_decision(inputs[j.first+i]):decision);
        }
        j.release();
    }
    raw.close(); tri.close(); final.close();
    return raw && tri && final ? 0 : 2;
}
