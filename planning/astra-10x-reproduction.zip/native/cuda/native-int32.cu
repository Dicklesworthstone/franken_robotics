#include <cuda_runtime.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <exception>
#include <future>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

constexpr int count_rows = 65536;
constexpr int half_ticks = 1 << 27;
struct Input { int32_t u, e; };
using byte = unsigned char;
using Clock = std::chrono::steady_clock;

void check(cudaError_t error, const char* where) {
    if (error != cudaSuccess)
        throw std::runtime_error(std::string(where) + ": " + cudaGetErrorString(error));
}

__global__ void screen(const Input* inputs, byte* results, int n) {
    int i = blockDim.x * blockIdx.x + threadIdx.x;
    if (i >= n) return;
    results[i] = static_cast<byte>(4 * inputs[i].e < inputs[i].u + half_ticks);

}

bool integer_decision(const Input& in) {
    return 4LL * in.e < static_cast<int64_t>(in.u) + half_ticks;
}

struct Receipt {
    int rows = 0, true_count = 0, ties = 0, raw_fp = 0, raw_fn = 0, fallback = 0;
    int corrected = 0, guarded_fp = 0, guarded_fn = 0;
    bool operator==(const Receipt& b) const {
        return rows==b.rows && true_count==b.true_count && ties==b.ties && raw_fp==b.raw_fp &&
               raw_fn==b.raw_fn && fallback==b.fallback && corrected==b.corrected &&
               guarded_fp==b.guarded_fp && guarded_fn==b.guarded_fn;
    }
};

struct Worker {
    int device, first, n;
    Input* in = nullptr;
    byte* out = nullptr;
    std::vector<byte> host;

    Receipt call(const std::vector<Input>& inputs, const std::vector<byte>& reference) {
        if (host.empty()) host.resize(n);
        if (device >= 0) {
            check(cudaSetDevice(device), "set device");
            if (in == nullptr) {
                check(cudaMalloc(&in, n*sizeof(Input)), "allocate inputs");
                check(cudaMalloc(&out, n*sizeof(byte)), "allocate flags");
            }
            check(cudaMemcpy(in, inputs.data()+first, n*sizeof(Input), cudaMemcpyHostToDevice),
                  "copy input");
            screen<<<(n+255)/256,256>>>(in,out,n);
            check(cudaGetLastError(), "launch CUDA kernel");
            check(cudaDeviceSynchronize(), "fence CUDA kernel");
            check(cudaMemcpy(host.data(), out, n*sizeof(byte), cudaMemcpyDeviceToHost),
                  "copy native output");
        } else {
            for (int i=0;i<n;++i) host[i]=integer_decision(inputs[first+i]);
        }
        Receipt receipt;
        receipt.rows = n;
        for (int i=0;i<n;++i) {
            const Input& row=inputs[first+i];
            bool truth = reference[first+i], raw = (host[i]&1) != 0;
            bool fallback = (host[i]&2) != 0;
            bool guarded = fallback ? integer_decision(row) : raw;
            receipt.true_count += truth;
            receipt.ties += (4LL*row.e == static_cast<int64_t>(row.u) + half_ticks);
            receipt.raw_fp += raw && !truth;
            receipt.raw_fn += !raw && truth;
            receipt.fallback += fallback;
            receipt.corrected += raw != truth && guarded == truth;
            receipt.guarded_fp += guarded && !truth;
            receipt.guarded_fn += !guarded && truth;
        }
        return receipt;
    }
    void release() {
        if (device >= 0) {
            check(cudaSetDevice(device), "select device for cleanup");
            check(cudaFree(in), "free device inputs");
            check(cudaFree(out), "free device flags");
        }
    }
};

void print_receipt(const Worker& w, const Receipt& r) {
    std::cout<<"device="<<w.device<<" first="<<w.first<<" rows="<<r.rows
             <<" exact_true="<<r.true_count<<" exact_ties="<<r.ties
             <<" raw_fp="<<r.raw_fp<<" raw_fn="<<r.raw_fn<<" fallback="<<r.fallback
             <<" resolved_without_fallback="<<(r.rows-r.fallback)<<" corrected="<<r.corrected
             <<" guarded_fp="<<r.guarded_fp<<" guarded_fn="<<r.guarded_fn<<"\n";
}

int run(const std::string& mode, const std::string& arm) {
    int scale = arm == "near" ? 1 : 2048;
    std::vector<Input> inputs(count_rows);
    std::vector<byte> reference(count_rows);
    for (int i=0;i<count_rows;++i) {
        int u = half_ticks + ((int64_t(i)*65537) % (half_ticks+1LL));
        int e = (u+half_ticks)/4 + (i%9-4)*scale;
        inputs[i]={u,e};
        reference[i]=e <= (static_cast<int64_t>(u)+half_ticks-1)/4;
    }
    std::vector<Worker> workers;
    if (mode=="dual") {
        workers.push_back({0,0,count_rows/2});
        workers.push_back({1,count_rows/2,count_rows/2});
    } else {
        int device = mode=="cpu" ? -1 : std::stoi(mode);
        workers.push_back({device,0,count_rows});
    }
    std::vector<double> micros;
    std::vector<Receipt> expected(workers.size());
    for (int rep=0;rep<22;++rep) {
        std::vector<Receipt> receipts(workers.size());
        auto start = Clock::now();
        if (workers.size()==2) {
            auto other=std::async(std::launch::async,[&] { return workers[1].call(inputs,reference); });
            receipts[0]=workers[0].call(inputs,reference);
            receipts[1]=other.get();
        } else {
            receipts[0]=workers[0].call(inputs,reference);
        }
        auto end = Clock::now();
        micros.push_back(std::chrono::duration<double,std::micro>(end-start).count());
        if (rep==0) expected=receipts;
        else if (receipts!=expected) throw std::runtime_error("unstable per-run receipts");
    }
    std::cout<<"mode="<<mode<<" arm="<<arm<<" warm_runs=21 cold_us="<<micros[0];
    std::sort(micros.begin()+1,micros.end());
    std::cout<<" warm_min_us="<<micros[1]<<" warm_median_us="<<micros[11]
             <<" warm_max_us="<<micros[21]<<"\n";
    for(size_t i=0;i<workers.size();++i) {
        print_receipt(workers[i],expected[i]);
        workers[i].release();
    }
    for(const auto& r:expected) if(r.guarded_fp || r.guarded_fn) return 3;
    return 0;
}

int main(int argc,char** argv) {
    if(argc!=3) return 2;
    try { return run(argv[1],argv[2]); }
    catch (const std::exception& e) { std::cerr<<e.what()<<"\n"; return 1; }
}
