# M01 · Native Metal screening of the P05 docking family

Apple M5 Ultra, macOS 27.0.1 (26A434), Xcode 27.1 (27A9275), macOS SDK 27.0, Apple clang 21.0.0. The program compiled MSL with safe math and issued a 65,536-thread Metal compute dispatch. GPU timestamps and successful command-buffer completion were read from the native API. Both the host and GPU had access to shared Metal buffers. No simulator, graphics display or remote runtime participated.

| Workload, 65,536 ordered cases each | Unsafe false admits / false exclusions | Direct guarded decisions | Exact CPU fallbacks | Incorrect direct / final decisions | Warm full Metal / exact CPU (μs) | GPU active (μs) | Fresh-process Metal / exact CPU (ms) |
|---|---:|---:|---:|---:|---:|---:|---:|
| Dense, ±4 error ticks | 452 / 23,438 | 0 | 65,536 | 0 / 0 | 288.500 / 33.750 | 6.875 | 78.558 / 9.583 |
| Spaced, offsets up to ±8,192 ticks | 110 / 4,779 | 58,254 | 7,282 | 0 / 0 | 308.750 / 35.333 | 12.708 | 82.160 / 8.079 |

Each set contained 1,820 exact equalities. In the spaced set 29,128 direct decisions were positive and 29,126 negative. Each final ordered output had 34,590 feasible cases and 30,946 infeasible cases. The CPU, resolved Metal path and independent Python exact output all had SHA-256 c789e496d4a2e51be10ec0764991fb30a309d3f25522f3e7129410ca93f6e115, using one byte per case (1 for feasible). The two grids have the same exact output because changing the offset multiplier preserves its sign, and the zero offsets coincide.

The directly guarded result on the dense grid is wholly inconclusive. Correctness on that grid came entirely from the exact fallback. Naive screening admitted dense case 41 even though its exact residual is −3 ticks. On the spaced workload it admitted case 364 even though that case lies exactly on the excluded boundary. These are failures of strict binary32 classification.

## Why the guard is conservative on this fixture

In normalized coordinates, binary32 conversion errors contribute at most 2⁻²⁵ from U in [0.5,1] and four times 2⁻²⁶ from E in roughly [0.2499,0.3752]. Scaling by powers of two is exact; rounding U+0.5 contributes at most 2⁻²⁴. Subtraction of the two nearby positive binary32 values is exact by Sterbenz's lemma in this domain. Thus absolute error is bounded by 5·2⁻²⁵, strictly below the 2⁻²¹ guard. These bounds apply to the declared input chart and operation ordering. Other target scales, formats, operations and rounding modes need their own bound.

## Reproduction

From this directory on a Metal-capable Mac with recent Xcode and Python 3:

```sh
xcrun clang++ -std=c++17 -O3 -fobjc-arc screen.mm -framework Metal -framework Foundation -o screen
python3 -B run.py > REPLAY.json
```

The driver uses only the Python standard library. It writes JSON to stdout. Timing and machine identity in a replay will differ. For the archived run see RECEIPT.json for all raw timings, first counterexamples, false-positive/negative counts, ordered-output hashes, hardware identity and exact SDK/compiler details. PREREG.md was committed to its SHA-256 before the first measured command. SHA256SUMS covers the portable sources, protocol, README and archived receipt.

Warm timings are medians over nine alternating paired trials per workload, after two priming iterations per arm. The native GPU arm starts with ordinary host input and finishes with ordinary host output, counting input packing, actual completion and exact CPU fallback. The CPU maps the same ordinary arrays through an optimized integer comparison. GPU active intervals are diagnostic. Three fresh-process pairs per workload include device/pipeline setup on the GPU arm and ordinary host startup on the CPU arm; existing OS/driver caches are uncontrolled. Timing did not include Xcode compilation, human authoring or the separate correctness audit. No confidence or productwide performance claim is made. A robotics implementation whose input and output already live on the GPU would require a different measurement.
