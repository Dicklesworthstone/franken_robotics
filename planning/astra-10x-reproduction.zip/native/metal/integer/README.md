# M02 · Exact integer Metal on the P05 dyadic grid

This follow-up gives the Metal device the same integer inequality as the CPU comparator in M01. Both operands fit unsigned 32 bits: the largest registered U tick is at most 2²⁸, and 4E stays at or below 2²⁸ + 2²⁷ + 4·8192. One MSL kernel emits a final byte per input. The only host step after successful command-buffer completion is a byte copy. All fallback counts are zero by construction, and correctness is checked independently on every indexed input.

| Workload | Correct GPU labels | False admits / exclusions | Exact equalities excluded | Warm Metal / CPU (μs) | GPU active (μs) | Process-cold Metal / CPU (ms) |
|---|---:|---:|---:|---:|---:|---:|
| Near boundary | 65,536/65,536 | 0 / 0 | 1,820 | 209.458 / 23.333 | 6.875 | 73.408 / 8.506 |
| Spaced | 65,536/65,536 | 0 / 0 | 1,820 | 236.625 / 30.750 | 6.750 | 184.884 / 9.321 |

Each grid has 34,590 feasible and 30,946 infeasible cases. Both native output sequences matched Python arbitrary-precision labels in recorded order, with SHA-256 c789e496d4a2e51be10ec0764991fb30a309d3f25522f3e7129410ca93f6e115. Exact integer Metal eliminated the fallbacks observed with the guarded floating-point representation. The matched host-in/host-out CPU comparison still took less time at this batch size. Timings do not cover a GPU-resident robotics simulation. Original M01 runs and receipts predate this separately registered follow-up.

Reproduce from this folder on a Metal-enabled Mac with recent Xcode and Python 3. M02 ran on an Apple M5 Ultra, macOS 27.0.1 (26A434), Xcode 27.1 (27A9275), macOS SDK 27.0, Apple clang 21.0.0.

```sh
xcrun clang++ -std=c++17 -O3 -fobjc-arc screen.mm -framework Metal -framework Foundation -o screen
python3 -B run.py > REPLAY.json
```

Each warm median uses nine timings per arm per workload, paired in alternating order after two priming iterations. Three paired fresh-process invocations per arm measured process-cold time with system caches uncontrolled. The archive includes all timings; compare arms within the same follow-up run. The protocol and original source hashes are available in PREREG.md and SHA256SUMS.
