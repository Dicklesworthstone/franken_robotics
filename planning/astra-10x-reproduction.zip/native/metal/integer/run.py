#!/usr/bin/env python3
"""Build first (README). Archive a verifiable small receipt on stdout."""
import datetime
import hashlib
import json
import platform
import statistics
import subprocess
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent
COUNT = 65536
H = 1 << 27

def command(*argv):
    return subprocess.check_output(argv, cwd=BASE)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def run_case(case, arm):
    return json.loads(command("./screen",case,arm))

def raw_times(case):
    times = []
    for j in range(3):
        pair = {}
        for arm in (("cpu","gpu") if j % 2 == 0 else ("gpu","cpu")):
            start = time.perf_counter_ns()
            data = command("./screen",case,arm)
            process_us = (time.perf_counter_ns()-start)/1000
            pair[arm] = dict(process_us=process_us,**json.loads(data))
        times.append(pair)
    return times

def accuracy(case):
    hz = 1 if case == "near" else 2048
    packed = command("./screen",case,"audit")
    assert len(packed) == 2*COUNT
    metal, cpu = packed[:COUNT], packed[COUNT:]
    oracle = bytearray()
    report = dict(exact_equal=0, metal_false_admit=0, metal_false_exclude=0,
                  cpu_false=0, fallback=0)
    for i in range(COUNT):
        u = H + i*65537 % (H+1)
        e = (u+H)//4 + (i%9-4)*hz
        residual = u+H-4*e
        label = int(residual>0)
        oracle.append(label)
        report["exact_equal"] += residual == 0
        report["metal_false_admit"] += metal[i] == 1 and label == 0
        report["metal_false_exclude"] += metal[i] == 0 and label == 1
        report["cpu_false"] += cpu[i] != label
    assert set(metal) <= {0,1}
    return dict(**report,exact_include=sum(oracle),exact_exclude=COUNT-sum(oracle),
                metal_sha256=digest(metal),python_exact_sha256=digest(oracle),
                cpu_sha256=digest(cpu))

result = dict(pilot="M02",started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              fixture_count=COUNT,prereg_sha256=digest((BASE/"PREREG.md").read_bytes()),system=platform.platform(),
              os_build=command("sw_vers","-buildVersion").decode().strip(),
              compiler=command("xcrun","clang++","--version").decode().splitlines()[0],
              xcode=command("xcodebuild","-version").decode().strip(),
              sdk=command("xcrun","--show-sdk-version").decode().strip(),
              unity_tick="2^-28",representation="uint32 exact, no host fallback",workloads={})
for name in ("near","separated"):
    cold = raw_times(name)
    warm = run_case(name,"warm")
    aud = accuracy(name)
    med = statistics.median
    summary = {k:med(r[k] for r in warm["samples"]) for k in ("cpu_us","metal_us","gpu_us")}
    for arm in ("cpu","gpu"):
        summary["process_cold_"+arm+"_us"] = med(p[arm]["process_us"] for p in cold)
    for p in cold:
        for arm in ("cpu","gpu"):
            assert p[arm]["ones"] == aud["exact_include"]
    result["workloads"][name] = dict(accuracy=aud,median=summary,cold=cold,warm=warm)
result["outcome"] = "pass" if all(not any(v["accuracy"][k] for k in ("metal_false_admit","metal_false_exclude","cpu_false")) for v in result["workloads"].values()) else "fail"
result["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
print(json.dumps(result,indent=2))
