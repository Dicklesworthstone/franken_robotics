#include <metal_stdlib>
using namespace metal;

// Each operand is below 2^32 on both registered P05 domains.
kernel void exact_p05(device const uint2* ticks [[buffer(0)]],
                      device uchar* decision [[buffer(1)]],
                      uint i [[thread_position_in_grid]]) {
    uint2 z = ticks[i];
    decision[i] = 4u * z.y < z.x + (1u << 27);
}
