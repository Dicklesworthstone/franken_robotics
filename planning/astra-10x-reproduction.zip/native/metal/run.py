#!/usr/bin/env python3
"""Build first (README). Archive a verifiable small receipt on stdout."""
import datetime
import hashlib
import json
import platform
import statistics
import subprocess
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent
COUNT = 65536
H = 1 << 27

def command(*argv):
    return subprocess.check_output(argv, cwd=BASE)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def run_case(case, arm):
    return json.loads(command("./screen",case,arm))

def raw_times(case):
    times = []
    for j in range(3):
        pair = {}
        for arm in (("cpu","gpu") if j % 2 == 0 else ("gpu","cpu")):
            start = time.perf_counter_ns()
            data = command("./screen",case,arm)
            process_us = (time.perf_counter_ns()-start)/1000
            pair[arm] = dict(process_us=process_us,**json.loads(data))
        times.append(pair)
    return times

def accuracy(case):
    hz = 1 if case == "near" else 2048
    packed = command("./screen",case,"audit")
    assert len(packed) == 4*COUNT
    raw,guard,final,cpu = (packed[i:i+COUNT] for i in range(0,len(packed),COUNT))
    assert set(raw) <= {0,1} and set(guard) <= {0,1,2} and set(final) <= {0,1}
    oracle = bytearray()
    summary = dict(exact_equal=0,raw_false_exclude=0,raw_false_include=0,
                   unknown=0,direct_include=0,direct_exclude=0,guarded_false_exclude=0,
                   guarded_false_include=0,resolved_false=0,cpu_false=0)
    witnesses = {}
    for i in range(COUNT):
        u = H + i*65537 % (H+1)
        e = (u+H)//4 + (i%9-4)*hz
        residual = (u+H)-4*e
        label = int(residual>0)
        oracle.append(label)
        summary["exact_equal"] += residual == 0
        summary["raw_false_exclude"] += raw[i] == 0 and label == 1
        summary["raw_false_include"] += raw[i] == 1 and label == 0
        summary[["direct_exclude","direct_include","unknown"][guard[i]]] += 1
        summary["guarded_false_exclude"] += guard[i] == 0 and label == 1
        summary["guarded_false_include"] += guard[i] == 1 and label == 0
        summary["resolved_false"] += final[i] != label
        summary["cpu_false"] += cpu[i] != label
        for name,predicate in [("raw_false_include",raw[i] and not label),("raw_false_exclude",not raw[i] and label),("strict_equality",residual==0)]:
            if predicate and name not in witnesses:
                witnesses[name] = dict(index=i,u_ticks=u,e_ticks=e,residual_ticks=residual,raw=raw[i],guarded=guard[i],exact=label)
    return dict(**summary,exact_include=sum(oracle),exact_exclude=COUNT-sum(oracle),
                raw_sha256=digest(raw),guarded_sha256=digest(guard),final_sha256=digest(final),
                python_exact_sha256=digest(oracle),cpu_sha256=digest(cpu),example_rows=witnesses)

result = dict(pilot="M01",started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              fixture_count=COUNT,prereg_sha256=digest((BASE/"PREREG.md").read_bytes()),system=platform.platform(),
              os_build=command("sw_vers","-buildVersion").decode().strip(),
              compiler=command("xcrun","clang++","--version").decode().splitlines()[0],
              xcode=command("xcodebuild","-version").decode().strip(),
              sdk=command("xcrun","--show-sdk-version").decode().strip(),
              unity_tick="2^-28",normalized_guard="2^-21",fallback_code=2,workloads={})
for name in ("near","separated"):
    cold = raw_times(name)
    warm = run_case(name,"warm")
    aud = accuracy(name)
    med = statistics.median
    summary = {k:med(r[k] for r in warm["samples"]) for k in ("cpu_us","metal_us","gpu_us")}
    for arm in ("cpu","gpu"):
        summary["process_cold_"+arm+"_us"] = med(p[arm]["process_us"] for p in cold)
    for p in cold:
        for arm in ("cpu","gpu"):
            assert p[arm]["ones"] == aud["exact_include"]
    result["workloads"][name] = dict(accuracy=aud,median=summary,cold=cold,warm=warm)
result["outcome"] = "pass" if all(not any(v["accuracy"][k] for k in ("guarded_false_include","guarded_false_exclude","resolved_false","cpu_false")) for v in result["workloads"].values()) else "fail"
result["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
print(json.dumps(result,indent=2))
