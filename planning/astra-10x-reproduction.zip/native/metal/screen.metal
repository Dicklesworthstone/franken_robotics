#include <metal_stdlib>
using namespace metal;

inline float residual(uint2 ticks) {
    const float unit = 0x1p-28f;
    float u = float(ticks.x) * unit;
    float epsilon = float(ticks.y) * unit;
    return (u + 0.5f) - 4.0f * epsilon;
}

kernel void guarded(device const uint2* ticks [[buffer(0)]],
                    device uchar* decision [[buffer(1)]],
                    uint i [[thread_position_in_grid]]) {
    float r = residual(ticks[i]);
    constexpr float guard = 0x1p-21f;
    decision[i] = r > guard ? 1 : (r < -guard ? 0 : 2);
}

kernel void unchecked(device const uint2* ticks [[buffer(0)]],
                      device uchar* decision [[buffer(1)]],
                      uint i [[thread_position_in_grid]]) {
    decision[i] = residual(ticks[i]) > 0.0f ? 1 : 0;
}
