#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <string>
#include <vector>

constexpr uint32_t count = 65536, half = 1u << 27;
using Clock = std::chrono::steady_clock;
struct Ticks { uint32_t u, e; };
static_assert(sizeof(Ticks) == 8);
using Flags = std::vector<uint8_t>;
static bool exact(Ticks z) { return uint64_t(4)*z.e < uint64_t(z.u)+half; }

static std::vector<Ticks> fixture(int k) {
    std::vector<Ticks> x(count);
    for (uint32_t i = 0; i < count; ++i) {
        uint32_t u = half + uint64_t(i) * 65537u % (half + 1);
        int d = (int(i % 9) - 4) * k;
        x[i] = {u, uint32_t(int64_t((u+half)/4) + d)};
    }
    return x;
}

__attribute__((noinline)) static void cpu(const std::vector<Ticks>& x, Flags& dst) {
    for (uint32_t i = 0; i < count; ++i) dst[i] = exact(x[i]);
}
static void require(bool pass, const char* msg, NSError* err=nil) {
    if (!pass) throw std::runtime_error(std::string(msg) + (err ? std::string(": ")+err.localizedDescription.UTF8String : ""));
}
struct Metal {
    id<MTLDevice> device;
    id<MTLCommandQueue> queue;
    id<MTLLibrary> library;
    id<MTLComputePipelineState> guard;
    id<MTLBuffer> input, output;
    NSUInteger threads;

    id<MTLComputePipelineState> make(NSString* name) {
        NSError* error = nil;
        id<MTLFunction> fun = [library newFunctionWithName:name];
        require(fun != nil, "missing kernel");
        auto pipeline = [device newComputePipelineStateWithFunction:fun error:&error];
        require(pipeline != nil, "pipeline build", error);
        return pipeline;
    }
    Metal() {
        device = MTLCreateSystemDefaultDevice();
        require(device != nil, "no Metal device");
        queue = [device newCommandQueue];
        require(queue != nil, "queue");
        NSError* error = nil;
        NSString* source = [NSString stringWithContentsOfFile:@"screen.metal" encoding:NSUTF8StringEncoding error:&error];
        require(source != nil, "reading MSL", error);
        MTLCompileOptions* options = [MTLCompileOptions new];
        options.mathMode = MTLMathModeSafe;
        library = [device newLibraryWithSource:source options:options error:&error];
        require(library != nil, "MSL compilation", error);
        guard = make(@"guarded");
        threads = std::min<NSUInteger>(256, guard.maxTotalThreadsPerThreadgroup);
        input = [device newBufferWithLength:sizeof(Ticks)*count options:MTLResourceStorageModeShared];
        output = [device newBufferWithLength:count options:MTLResourceStorageModeShared];
        require(input != nil && output != nil, "shared buffers");
    }

    double dispatch(id<MTLComputePipelineState> pipe, const std::vector<Ticks>& x) {
        std::memcpy(input.contents,x.data(),count*sizeof(Ticks));
        id<MTLCommandBuffer> command = [queue commandBuffer];
        auto enc = [command computeCommandEncoder];
        require(enc != nil, "command encoder");
        [enc setComputePipelineState:pipe];
        [enc setBuffer:input offset:0 atIndex:0];
        [enc setBuffer:output offset:0 atIndex:1];
        [enc dispatchThreads:MTLSizeMake(count,1,1) threadsPerThreadgroup:MTLSizeMake(threads,1,1)];
        [enc endEncoding];
        [command commit];
        [command waitUntilCompleted];
        require(command.status == MTLCommandBufferStatusCompleted, "Metal command failed",command.error);
        return (command.GPUEndTime - command.GPUStartTime)*1e6;
    }

    double resolved(const std::vector<Ticks>& x, Flags& final) {
        double gpuUs = dispatch(guard,x);
        const uint8_t* p = static_cast<uint8_t*>(output.contents);
        for (uint32_t i=0;i<count;++i) final[i] = p[i] == 2 ? exact(x[i]) : p[i];
        return gpuUs;
    }
};

struct Timing {double totalUs, gpuUs;};
static Timing timed(Metal* metal, const std::vector<Ticks>& x, Flags& y) {
    auto start = Clock::now();
    double gpu = 0;
    if (metal) gpu = metal->resolved(x,y); else cpu(x,y);
    asm volatile("" : : "r"(y.data()) : "memory");
    return {std::chrono::duration<double,std::micro>(Clock::now()-start).count(),gpu};
}
static void audit(Metal& m, const std::vector<Ticks>& x, Flags& y) {
    m.dispatch(m.make(@"unchecked"),x);
    fwrite(m.output.contents,1,count,stdout);
    m.resolved(x,y);
    fwrite(m.output.contents,1,count,stdout);
    fwrite(y.data(),1,count,stdout);
    cpu(x,y);
    fwrite(y.data(),1,count,stdout);
}
int main(int argc, char** argv) {
  @autoreleasepool {
    try {
      require(argc>=3,"expected near|separated and cpu|gpu|audit|warm");
      std::string workload=argv[1], mode=argv[2];
      require(workload=="near"||workload=="separated","bad fixture");
      auto x=fixture(workload=="near" ? 1 : 2048); Flags y(count);
      if (mode=="cpu") {
          auto t=timed(nullptr,x,y);
          printf("{\"host_us\":%.3f,\"ones\":%ld}\n",t.totalUs,std::count(y.begin(),y.end(),uint8_t(1)));
          return 0;
      }
      Metal m;
      if (mode=="audit") {audit(m,x,y);return 0;}
      require(mode=="gpu"||mode=="warm","bad arm");
      if (mode=="gpu") {
          auto t=timed(&m,x,y);
          printf("{\"host_us\":%.3f,\"gpu_us\":%.3f,\"ones\":%ld}\n",t.totalUs,t.gpuUs,std::count(y.begin(),y.end(),uint8_t(1)));
          return 0;
      }
      for(int j=0;j<2;++j){timed(nullptr,x,y);timed(&m,x,y);}
      printf("{\"device\":\"%s\",\"registry_id\":%llu,\"threadgroup\":%lu,\"samples\":[",
        m.device.name.UTF8String,m.device.registryID,(unsigned long)m.threads);
      for(int j=0;j<9;++j){
          @autoreleasepool {
            Timing a,b;
            if(j%2==0){a=timed(nullptr,x,y);b=timed(&m,x,y);} else {b=timed(&m,x,y);a=timed(nullptr,x,y);}
            printf("%s{\"cpu_us\":%.3f,\"metal_us\":%.3f,\"gpu_us\":%.3f}",j?",":"",a.totalUs,b.totalUs,b.gpuUs);
          }
      }
      printf("]}\n");
      return 0;
    } catch(const std::exception& e){fprintf(stderr,"%s\n",e.what());return 2;}
  }
}
