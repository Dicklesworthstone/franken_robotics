"""Run from any directory. Default checks use the Python standard library."""
from fractions import Fraction
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
MOR = ROOT / "mor" / "repro"
PUSHER = ROOT / "pusher"
SILL = ROOT / "sill"


def check_integrity():
    listed = set()
    for line in (ROOT / "SHA256SUMS").read_text().splitlines():
        expected, name = line.split("  ", 1)
        observed = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
        if expected != observed:
            raise ValueError(f"SHA-256 mismatch in {name}")
        listed.add(name)
    print(f"Verified {len(listed)} listed file digests.")


def run(program, *args):
    return subprocess.check_output(
        [sys.executable, "-B", program.name, *args], cwd=program.parent
    )


def match(program, receipt):
    observed = run(program)
    if observed != receipt.read_bytes():
        raise ValueError(f"Output differs from {receipt.name}")
    print(f"{program.name} matched {receipt.name}.")


def pusher():
    reference = json.loads((PUSHER / "PILOT_RUN.json").read_text())["reference"]
    for arm in ("specialized", "composed"):
        observed = json.loads(run(PUSHER / "pilot.py", "--arm", arm))
        if observed != reference[arm] or len(observed) != 10:
            raise ValueError(f"{arm} certificates or proofs changed")
    print("Both pusher arms matched all 10 stored fixture records.")


def docking_counts():
    # Terminal (position, velocity) fixes the last commands to 1/g-2x and
    # x-1/g for first command x. Intersect their scalar bounds over both gains.
    admitted = excluded = touching = 0
    for index in range(17):
        bound = Fraction(1, 2) + Fraction(index, 32)
        lower, upper = -bound, bound
        for gain in (1, 2):
            displacement = Fraction(1, gain)
            lower = max(lower, (displacement-bound)/2, displacement-bound)
            upper = min(upper, (displacement+bound)/2, displacement+bound)
        if lower > upper:
            raise ValueError("No feasible conditional schedule at zero measurement error")
        separation = max(abs(lower), abs(upper))
        for j in range(33):
            twice_error = 2*Fraction(j, 64)
            if separation > twice_error:
                admitted += 1
            else:
                excluded += 1
            touching += separation == twice_error
    if (admitted, excluded, touching) != (344, 217, 9):
        raise ValueError("The independent rational docking counts changed")
    print("Docking inequalities reproduced 344 admissions, 217 exclusions and 9 equalities.")



def smt():
    for formula in sorted((PUSHER / "queries").glob("*.smt2")):
        expected = "sat" if formula.name.startswith("mutant-") else "unsat"
        observed = subprocess.check_output(["z3", "-T:5", str(formula)], timeout=8, text=True).strip()
        if observed != expected:
            raise ValueError(f"{formula.name} yielded {observed}, expected {expected}")
    print("Z3 accepted 20 exact-set comparisons and exposed the mutant.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--all", action="store_true", help="also run the pinned scientific Python and Z3 checks")
    flags = parser.parse_args()
    check_integrity()
    for driver,receipt in [
        ("P02-identification.py", "P02-identification-results.json"),
        ("P02-identification-family.py", "P02-identification-family.json"),
        ("P03-sensor.py", "P03-results.txt"),
        ("P04-docking.py", "P04-docking.txt"),
    ]:
        match(MOR/driver, MOR/receipt)
    match(SILL/"quasistatic_sill.py", SILL/"quasistatic_sill.out")
    pusher()
    docking_counts()
    if flags.all:
        match(MOR/"P05-docking-family.py", MOR/"P05-docking-family.txt")
        match(SILL/"promotion_rule.py", SILL/"promotion_rule.out")
        match(MOR/"P01-inverse.py", MOR/"P01-results.json")
        print(run(MOR/"AUD01-recheck.py").decode(), end="")
        smt()


if __name__ == "__main__":
    main()
