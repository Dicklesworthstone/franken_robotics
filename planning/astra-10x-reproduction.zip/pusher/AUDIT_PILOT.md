# AUDIT_PILOT · Q-001 · fresh-eyes review of the guarded one-stroke pusher pilot (MO-07a)

Reviewer: AmberCliff (cart attack investigator, not an author of the pilot) · 2026-11-21.
Read: `PILOT_LOCK.md`, `PILOT_RUN.json`, `pilot_check.py`, `evidence/packs/independent-pusher-check.md`,
plus `PILOT.md`, `pilot.py`, `check_locked_pusher_z3.py` and `pusher-z3.json` for the claim and encodings.
Originals were not edited. My scripts and outputs are in `analyses/audit_pilot/`.

**Bottom line.** The distinct-query kill is **confirmed, and more strongly than claimed**: an off-the-shelf
engine derives the family answer from the raw plant. The quantifiers and certificates are sound for this plant.
The **10× speed kill is not informative**: the locked denominator caps the measurable ratio at about 1.46×
warm and 1.003× cold, so that disconfirmer had to fire whatever the method. One transfer risk remains open (item 5).

## Reproduction

| Command | Result |
|---|---|
| `python3 -B pusher/pilot.py --arm specialized` / `--arm composed` | 10/10 and 10/10 certificates accepted |
| `python3 -I -B pusher/check_locked_pusher_z3.py` | 20/20 `unsat`, widened-exclusion mutant `sat`, Σ 0.475 s |
| `python3 -B pusher/audit_pilot/timing_ceiling.py` | see item 1 (`timing_ceiling.out`) |
| `python3 -I pusher/audit_pilot/z3_qe_produce.py` | see item 2 (`z3_qe_produce.out`) |

## Findings, ordered by severity

**1 · High · The speed disconfirmer had no power under the locked denominator.**
One "accepted decision" batch consists of fixture parsing, the solve, a JSON round trip, the shared checker and
equality checks. Measured on the pilot's own code, unchanged:

```text
specialized  solve=    34.4 us  parse+solve+json=   108.1 us  run_batch (pilot unit)=   610.1 us
composed     solve=   189.0 us  parse+solve+json=   285.6 us  run_batch (pilot unit)=   842.8 us
solve-only ratio composed/specialized          = 5.49x      (6.85x on a first run)
pilot-unit ratio composed/specialized           = 1.38x      (receipt: 1.345x)
shared overhead (specialized batch - its solve) = 575.7 us (94% of specialized batch)
warm ceiling if specialized solve cost -> 0     = 1.46x      (1.42x on a first run)
cold expected ratio from work alone              = 1.0030x (receipt: 1.088x, noise-dominated)
cold ceiling if specialized solve cost -> 0      = 1.0034x
cold per-pair ratios [1.494, 1.142, 0.743, 0.938, 1.007, 1.055, 1.222, 0.886, 0.886]
```

* **No method could have reached 10×.** Even an infinitely fast specialized arm would measure at most ≈ 1.46×
  warm and 1.003× cold.
* **The cold figure is noise.** The receipt's 1.088× is interpreter-start noise; pairs span 0.74–1.49× around
  an expected 0.3% effect.
* **Compute is a negligible share of the decision.** The whole batch (≈ 0.6 ms) is about 3×10⁻⁶ of the 3 m 41 s
  to first result, and authoring was not timed per arm.

The verdict sentence in `PILOT.md`, "Both predeclared disconfirmers fired. This retires the … 10× hypotheses",
counts a guaranteed outcome as evidence.
**Correction:** "The distinct-query disconfirmer fired. The speed disconfirmer could not discriminate: with shared
checking at about 94% of the batch, the warm ratio is capped near 1.46× and the cold ratio near 1.003×. The
solve-only ratio is 5.5–6.9×. Inclusive speed is unresolved, not killed, for this workload." Future locks should
compute this ceiling before execution and refuse a speed test whose ceiling is below 10×.

**2 · Medium · Timing and novelty agree in sign but rest on different baselines.**
* **The timed composed arm already contains the specialization.** `composed()` receives the plant pre-linearized
  at the gap vertices, as rows `(d+L)·r − u ≤ 0` and `u − (d+H)·r ≤ 0`. That means the `max(0,·)` guard has
  already been removed and the corner reduction already applied, which is the same inversion the specialized arm
  performs. The 1.35× therefore measures Fourier–Motzkin bookkeeping between two implementations of one
  reduction. It does not compare a specialization against an existing composition.
* **The real independent baseline is Z3 on the raw plant.** My quantifier-elimination run used the raw plant
  `ite(gu ≥ d, gu − d, 0)` with continuous ∀d and no hand reduction. It **produced the locked set directly** for
  8 of 12 queries in 15–110 ms each:

  | Fixture | Adjustable | Shared |
  |---|---|---|
  | wide | [1/2, 2] | false |
  | shared-tight | [1, 5/4] | (unsimplified) |
  | branch-crossing | [1/2, 1] | (unsimplified) |
  | both-ends | (unsimplified) | false |
  | zero-allowed | (unsimplified) | false |
  | hidden-gap | false | false |

  The other 4 came back quantifier-free but unsimplified. Their equivalence to the lock follows from the
  pack's xor = `unsat` check on the same predicate.
* **The novelty kill therefore rests on the Z3 evidence, not the composed arm.** The compute "speedup" swings
  from 1.35× (hand-reduced Fourier–Motzkin) to about 800× (raw-plant QE: Σ ≈ 0.5 s including process starts,
  against a 0.61 ms specialized batch), depending on which baseline is called matched. A compute ratio is not a
  property of the method here.

**Correction:** state that the timed composed arm embeds the specialized reduction. Name the raw-plant QE run as
the matched existing system, and record authoring time per arm, including deriving A = d_max + L and
B = d_min + H.

**3 · Low · Certificate coverage is sound for this plant; independence comes from the pack, not the checker.**
I checked the logic analytically.
* **Corner lifting holds.** Gains are positive, commands nonnegative and H ≥ 0. The scheduled extension
  max(g·u_min, A) is nondecreasing in g, and y is nonincreasing in d. So the checks at (lo, d_max) and (hi, d_min)
  cover the whole region.
* **The boundary tests prove maximality.** For g < lo, g·u_max − d_max < L. For g > hi, g·u_min − d_min > H.
* **The empty-region reasons are exhaustive.** An empty set means A > B, or A/u_max > g_max, or B/u_min < g_min.
  A remaining case is impossible because A ≤ B and u_min ≤ u_max.

Residual gaps:
* **Untested preconditions.** The monotonicity lemma lives in comments. Nothing refuses g_min ≤ 0, negative
  U or D, or L > H.
* **Common mode.** One author wrote the checker, the specialization and the composed arm, and all three share the
  corner lemma.
* **Narrow negative controls.** They run only on the specialized arm's certificates.
* **Solver trust.** Z3 emits no proof object, and the passing strategy was chosen after two failed strategies.
  The inputs stayed fixed, as the pack discloses.

**Correction:** assert the preconditions and refuse otherwise. Run the six mutations on the composed certificates
too. Keep the Z3 pack cited as the independence-carrying check.

**4 · Low · Quantifier ownership is correct.**
* **Adjustable query:** {g ∈ G : ∃u ∈ U ∀d ∈ D, y ∈ Y}. The command is chosen per catalog design before the gap
  is seen, a build-time retuned controller in the §9.4 sense.
* **Shared query:** {u ∈ U : ∀g ∀d}.
* **Encodings match.** Both the lock and the Z3 encoding nest the quantifiers this way, and coverage of all of G
  is derived correctly.

The only loose end is in the hidden-gap fixture. The prose claim that a gap-aware command u = (d+3/4)/g succeeds
is true: y = 3/4 and u ≤ 3/2 ≤ 2. But this third ownership level is not certified.
**Correction:** label it "uncertified prose", or add it as a third query.

**5 · Unresolved risk (disclosed) · The workload has no state-dependent hybrid branch, so the null result may
not transfer.**
* **The guard collapses.** For H ≥ 0, max(0, x) ∈ [L, H] is equivalent to x ≤ H ∧ (L = 0 ∨ x ≥ L). The guard is
  decided by a fixture constant, not by the state, so every query is a two-variable linear projection.
* **Agreement was near-certain.** Both arms had to agree, and the locked prediction "both will match" was close
  to guaranteed. The novelty kill is valid here but says nothing about Astra's actual hybrid regimes:
  state-dependent event order, slip versus strike, controller sampling.
* **The cart attack hits exactly that regime.** In `ATTACK.md`, an unpinned rotor inertia and the loop's sampling
  rate move a planar proxy's A/B outcome. This is the non-monotone regime that `PILOT.md`'s proposed next
  discriminator targets.

I did not resolve whether any Astra workload with a state-dependent guard lets a specialization beat raw-plant
QE or CAD at equal authoring cost. Until that is tested, "distinct-query claim retired" should be scoped to
*monotone, single-guard, fixture-decided branches*.
