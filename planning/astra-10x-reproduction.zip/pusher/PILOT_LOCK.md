# Q-001 prediction lock

Locked 2026-11-21 before executing either solver. Session RS-20261121-franken-robotics-astra-10x. Protocol MO-quickie-pilot. Budget 30 minutes to first result, standard-library Python, one local CPU, no installations.

## Hypothesis and disconfirmers

The probable failure is that an existing composition already answers the family query once both arms receive the plant equations and the same controller ownership. Test whether specializing a guarded stroke into a certificate over a continuous design family buys a kind of answer unavailable to an exact robust counterpart and polyhedral projection, or a 10× local reduction in accepted decision time.

- Kill the distinct-query claim on this workload if both methods produce the same complete design and shared-command intervals and the checker accepts both sets of certificates.
- Any independently rejected certificate, missed boundary, or accepted mutation invalidates the affected result. One design with no feasible command refutes universal adjustable coverage. A conflict between two admissible design/gap pairs can refute shared coverage even when each design works.
- The local 10× claim requires equal checked results, zero unknowns and retries, and a baseline/candidate median ratio of at least 10 for each of the warm and cold measurements below. Either ratio below 10 kills this pilot's speed claim. The product's full engineering-cost claim needs a different experiment.
- Prediction. Both methods will match. The wide family will pass with commands chosen per design and fail with a shared command. Warm and cold accepted-decision ratios will miss 10. A mismatch triggers diagnosis against the checker and locked answers, with all first-run results retained.

## Plant and quantifiers

A simulated one-axis quasi-static pusher moves a package into a displacement window in a single stroke. A design has positive dimensionless stroke gain g in closed interval G. It issues command u in a nonnegative closed stroke interval U. A reset gives an unknown nonnegative free gap d in closed interval D. The simulator first takes up the gap, then pushes by the remaining extension. Displacement is y = max(0, g u − d) in normalized length units. Equality at contact onset yields zero. Acceptance is y in the nonnegative closed interval Y. There is no subsequent feedback. Catalog gain is available at build time, the gap is hidden from both controllers. There are no inertial, force, friction, or numerical-integration claims.

Return the exact adjustable design set {g in G : ∃u in U ∀d in D, y in Y} and the exact shared command set {u in U : ∀g in G ∀d in D, y in Y}. Coverage of the complete G is a derived decision. Positive answers include a schedule or command and exact bounds. Negative answers include a blocked design or conflicting corner constraints. Closed endpoints and zero-width intervals count.

## Arms and acceptance

- **Specialization.** Normalize extension to t = gu, invert the two saturation inequalities once, and intersect the resulting bounds with actuator and family constraints. Produce a schedule of the form max(u_min, A/g). Show both excluded portions of the design interval, when present.
- **Composed method.** Apply guarded dynamics constraints separately at the disturbance vertices. Normalize the linear rows using r = 1/g for the adjustable query and substitute gain vertices for the shared query. Apply Fourier–Motzkin projection to eliminate u, and intersect the scalar half-lines exactly. Recover the adjustable schedule from the lower rows. Both arms get exact rationals, the same model, fixture cases, checker, and output format. This is a native implementation of existing methods for this bounded problem.
- **Checker.** Reimplement the free-travel/contact simulator in a separate module without solver imports. Test a submitted schedule at design/gap corners and justify coverage by monotonicity. Require contact replay and tight separating inequalities at any claimed family boundary. Independently recompute all shared-command possibilities from the fixed-corner simulator branches. Check empty-family witnesses against the input model. Negative controls must reject a widened design interval, a truncated design interval, an overstated shared interval, a hidden-gap-violating schedule, and spurious empty answers for both queries.

## Frozen cases and expected intervals

| Case | G | U | D | Y | Adjustable design set | Shared command set |
|---|---|---|---|---|---|---|
| wide | [1/2, 2] | [0, 2] | [0, 1/4] | [3/4, 5/4] | [1/2, 2] | ∅ |
| shared-tight | [1, 5/4] | [0, 2] | [0, 1/4] | [3/4, 5/4] | [1, 5/4] | [1, 1] |
| weak-design | [1/4, 2] | [0, 2] | [0, 1/4] | [3/4, 5/4] | [1/2, 2] | ∅ |
| hidden-gap | [1, 2] | [0, 2] | [0, 3/4] | [3/4, 5/4] | ∅ | ∅ |
| zero-allowed | [1/4, 1] | [1/2, 2] | [1/4, 1/2] | [0, 1/8] | [1/4, 3/4] | ∅ |
| both-ends | [1/2, 2] | [1, 3/2] | [0, 1/4] | [3/4, 5/4] | [2/3, 5/4] | ∅ |
| singleton | [1/2, 2] | [1, 1] | [0, 0] | [3/4, 3/4] | [3/4, 3/4] | ∅ |
| branch-crossing | [1/2, 1] | [0, 1] | [1/4, 1/2] | [0, 1/8] | [1/2, 1] | [0, 3/8] |
| no-stroke | [1/2, 2] | [0, 0] | [0, 0] | [1/2, 1] | ∅ | ∅ |
| forced-overshoot | [1, 2] | [1, 1] | [0, 0] | [0, 1/2] | ∅ | ∅ |

## Denominator and accounting

The equal unit of work is all ten cases and both query outputs through certificate construction, JSON encode/decode and acceptance by the same checker. Warm timing uses 9 alternating-order pairs of 100 complete in-process batches, normalizing to one batch. Cold timing uses 9 alternating-order pairs of fresh Python processes, each running one batch with output capture. Report median wall time, all runs, correctness denominators, and failures or unknowns. Warm includes fixture construction and excludes interpreter startup. Cold includes interpreter startup and output transport and uses the existing filesystem cache. Both exclude experimental authoring, external engines and requester review. Record total investigator wall time and observed manual interventions separately. The fixtures are designed examples with no statistical or held-out claim.

## Source anchors

Astra §4.2 gives bounded design variables and infeasibility witnesses. §5.6 specifies hybrid guards. §9.4 calls for explicit shared and retuned controller comparisons. §13.1 separates analytic and differential evidence. §14.1 places a hybrid-regime atlas among its first bets. The supplied original links to §§18–20 but ends after §17. This pilot uses the question of record for the continuous-family and inclusive-cost criteria. Astra plan, §§4.2, 5.6, 9.4, 13.1 and 14.1. The decision contract is in [MOR_CASE.md](../mor/MOR_CASE.md).
