#!/usr/bin/env python3
"""AUDIT_PILOT: split the pilot's warm batch into arm-specific solve work and shared overhead.

Reads (imports) analyses/pilot.py and analyses/pilot_check.py unchanged. A batch = 10 fixtures:
parse fixture strings -> arm solve -> JSON round trip -> shared checker. The ceiling on the
composed/specialized ratio, if the specialized solve cost fell to zero, is
composed_batch / (specialized_batch - specialized_solve).
Usage: python3 -B analyses/audit_pilot/timing_ceiling.py
"""
import json
import sys
from pathlib import Path
from statistics import median
from time import perf_counter_ns

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pilot  # noqa: E402  (unchanged original)

CASES = [pilot.Case(*(pilot.parse_interval(v) for v in vals[:4])) for vals in pilot.FIXTURES.values()]
N, REPS = 200, 9


def per_batch(fn):
    samples = []
    for _ in range(REPS):
        t0 = perf_counter_ns()
        for _ in range(N):
            fn()
        samples.append((perf_counter_ns() - t0) / N)
    return median(samples)


def solve_only(arm):
    f = pilot.ARMS[arm]
    return lambda: [f(c) for c in CASES]


def parse_solve_json(arm):
    f = pilot.ARMS[arm]
    def run():
        for vals in pilot.FIXTURES.values():
            case = pilot.Case(*(pilot.parse_interval(v) for v in vals[:4]))
            json.loads(json.dumps(f(case), default=str))
    return run


def full_batch(arm):
    return lambda: pilot.run_batch(arm)


rows = {}
for arm in ("specialized", "composed"):
    rows[arm] = {"solve": per_batch(solve_only(arm)),
                 "parse+solve+json": per_batch(parse_solve_json(arm)),
                 "run_batch (pilot unit)": per_batch(full_batch(arm))}
for arm, r in rows.items():
    print(f"{arm:12} " + "  ".join(f"{k}={v/1e3:8.1f} us" for k, v in r.items()))
s, c = rows["specialized"], rows["composed"]
shared = s["run_batch (pilot unit)"] - s["solve"]
print(f"solve-only ratio composed/specialized          = {c['solve']/s['solve']:.2f}x")
print(f"pilot-unit ratio composed/specialized           = {c['run_batch (pilot unit)']/s['run_batch (pilot unit)']:.2f}x")
print(f"shared overhead (specialized batch - its solve) = {shared/1e3:.1f} us "
      f"({100*shared/s['run_batch (pilot unit)']:.0f}% of specialized batch)")
print(f"warm ceiling if specialized solve cost -> 0     = {c['run_batch (pilot unit)']/shared:.2f}x")
# Cold: receipt median 78.81 ms for one specialized fresh process (interpreter start + 1 batch).
# Composed process = same start-up with its batch swapped in; ceiling sets the specialized solve to 0.
cold_s = 78.81
cold_c = cold_s - s["run_batch (pilot unit)"] / 1e6 + c["run_batch (pilot unit)"] / 1e6
cold_s0 = cold_s - s["solve"] / 1e6
print(f"cold expected ratio from work alone              = {cold_c/cold_s:.4f}x (receipt: 1.088x, noise-dominated)")
print(f"cold ceiling if specialized solve cost -> 0      = {cold_c/cold_s0:.4f}x")
