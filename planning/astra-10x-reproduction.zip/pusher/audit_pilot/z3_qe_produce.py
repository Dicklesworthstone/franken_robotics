#!/usr/bin/env python3
"""AUDIT_PILOT: can an off-the-shelf engine PRODUCE the family answer from the raw plant?

Encodes y = ite(g*u >= d, g*u - d, 0) (no hand linearization, no vertex reduction, d ranges over
the whole closed interval) and asks Z3 quantifier elimination for the quantifier-free set of
designs g (adjustable: exists u forall d) or commands u (shared: forall g forall d).
Fixture rows are copied verbatim from PILOT_LOCK.md. Usage: python3 -I analyses/audit_pilot/z3_qe_produce.py
"""
import subprocess
import time
from fractions import Fraction

FIX = {  # name: (G, U, D, Y, locked adjustable, locked shared)
    "wide": ("1/2 2", "0 2", "0 1/4", "3/4 5/4", "[1/2, 2]", "∅"),
    "both-ends": ("1/2 2", "1 3/2", "0 1/4", "3/4 5/4", "[2/3, 5/4]", "∅"),
    "zero-allowed": ("1/4 1", "1/2 2", "1/4 1/2", "0 1/8", "[1/4, 3/4]", "∅"),
    "branch-crossing": ("1/2 1", "0 1", "1/4 1/2", "0 1/8", "[1/2, 1]", "[0, 3/8]"),
    "shared-tight": ("1 5/4", "0 2", "0 1/4", "3/4 5/4", "[1, 5/4]", "[1, 1]"),
    "hidden-gap": ("1 2", "0 2", "0 3/4", "3/4 5/4", "∅", "∅"),
}


def r(x):
    q = Fraction(x)
    return str(q.numerator) if q.denominator == 1 else f"(/ {q.numerator} {q.denominator})"


def inside(v, iv):
    lo, hi = iv.split()
    return f"(and (<= {r(lo)} {v}) (<= {v} {r(hi)}))"


def formula(G, U, D, Y, shared):
    ok = f"(let ((y (ite (>= (* g u) d) (- (* g u) d) 0))) {inside('y', Y)})"
    robust = f"(forall ((d Real)) (=> {inside('d', D)} {ok}))"
    if shared:
        return "u", f"(and {inside('u', U)} (forall ((g Real)) (=> {inside('g', G)} {robust})))"
    return "g", f"(and {inside('g', G)} (exists ((u Real)) (and {inside('u', U)} {robust})))"


for name, (G, U, D, Y, adj, sh) in FIX.items():
    for shared, locked in ((False, adj), (True, sh)):
        var, body = formula(G, U, D, Y, shared)
        smt = (f"(declare-const {var} Real)\n(assert {body})\n"
               "(apply (then simplify (using-params qe :qe_nonlinear true) simplify propagate-ineqs"
               " ctx-solver-simplify propagate-ineqs))\n")
        t0 = time.monotonic()
        out = subprocess.run(["z3", "-T:10", "-in"], input=smt, capture_output=True, text=True, timeout=15)
        dt = time.monotonic() - t0
        text = " ".join(out.stdout.split())
        text = text.replace("(goals (goal", "").replace(":precision precise :depth 3)) ", "").strip()
        print(f"{name:16} {'shared' if shared else 'adjustable':10} locked {locked:12} {dt*1000:6.0f} ms  z3: {text[:150]}")
