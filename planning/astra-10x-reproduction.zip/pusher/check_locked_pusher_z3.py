"""Check the locked membership sets in nonlinear real arithmetic, directly against the plant."""
from fractions import Fraction
from pathlib import Path
import json
import re
import subprocess
import time

HERE = Path(__file__).resolve().parent

def real(value):
    q = Fraction(value)
    return str(q.numerator) if q.denominator == 1 else f"(/ {q.numerator} {q.denominator})"

def belongs(variable, interval):
    if interval.strip() == "∅":
        return "false"
    ends = re.fullmatch(r"\[([^,]+),\s*([^\]]+)\]", interval.strip())
    if ends is None:
        raise ValueError(interval)
    lo, hi = (real(v.strip()) for v in ends.groups())
    return f"(and (<= {lo} {variable}) (<= {variable} {hi}))"

def problem(gains, commands, gaps, targets, expected, shared):
    allowed_gain = belongs("g", gains)
    allowed_command = belongs("u", commands)
    good = belongs("y", targets)
    success = f"(let ((y (ite (>= (* g u) d) (- (* g u) d) 0))) {good})"
    robust = f"(forall ((d Real)) (=> {belongs('d', gaps)} {success}))"
    if shared:
        var = "u"
        actual = f"(and {allowed_command} (forall ((g Real)) (=> {allowed_gain} {robust})))"
    else:
        var = "g"
        actual = f"(and {allowed_gain} (exists ((u Real)) (and {allowed_command} {robust})))"
    return f"(set-logic NRA)\n(declare-const {var} Real)\n(assert (xor {actual} {belongs(var, expected)}))\n(check-sat-using (then simplify (using-params qe :qe_nonlinear true) smt))\n"

def main():
    rows = []
    for line in (HERE / "PILOT_LOCK.md").read_text().splitlines():
        cells = [v.strip() for v in line.strip("|").split("|")]
        if len(cells) != 7 or not cells[1].startswith("["):
            continue
        name, gains, commands, gaps, targets, adjustable, shared = cells
        for query, expected in [("adjustable", adjustable), ("shared", shared)]:
            smt = problem(gains, commands, gaps, targets, expected, query == "shared")
            started = time.monotonic()
            result = subprocess.run(["z3", "-T:5", "-in"], input=smt, capture_output=True, text=True, timeout=8)
            rows.append({"case": name, "query": query, "result": result.stdout.strip(),
                         "seconds": round(time.monotonic()-started, 4), "return_code": result.returncode})
    # A checker that rejects everything would also say unsat on the valid cases.
    # The wide family's adjustable answer wrongly restricted to [1,2] provides a positive control.
    mutant = problem("[1/2,2]", "[0,2]", "[0,1/4]", "[3/4,5/4]", "[1,2]", False)
    bad = subprocess.run(["z3", "-T:5", "-in"], input=mutant, capture_output=True, text=True, timeout=8)
    print(json.dumps({"z3":subprocess.check_output(["z3","--version"],text=True).strip(),
                      "semantics":"unsat means no discrepancy over any real design or command",
                      "queries": rows, "widened_exclusion_mutant": bad.stdout.strip()}, indent=2))

if __name__ == "__main__":
    main()
