"""Run Q-001's exact pusher discriminator with the standard library."""

import argparse
from dataclasses import dataclass
from datetime import datetime
from fractions import Fraction
from itertools import product
import json
from pathlib import Path
import platform
from statistics import median
import subprocess
import sys
from time import perf_counter_ns

from pilot_check import Rejected, check, fraction_interval


# gain, actuator, initial gap, target, expected gain region, expected shared commands
FIXTURES = {
    "wide": ("1/2 2", "0 2", "0 1/4", "3/4 5/4", "1/2 2", None),
    "shared-tight": ("1 5/4", "0 2", "0 1/4", "3/4 5/4", "1 5/4", "1 1"),
    "weak-design": ("1/4 2", "0 2", "0 1/4", "3/4 5/4", "1/2 2", None),
    "hidden-gap": ("1 2", "0 2", "0 3/4", "3/4 5/4", None, None),
    "zero-allowed": ("1/4 1", "1/2 2", "1/4 1/2", "0 1/8", "1/4 3/4", None),
    "both-ends": ("1/2 2", "1 3/2", "0 1/4", "3/4 5/4", "2/3 5/4", None),
    "singleton": ("1/2 2", "1 1", "0 0", "3/4 3/4", "3/4 3/4", None),
    "branch-crossing": ("1/2 1", "0 1", "1/4 1/2", "0 1/8", "1/2 1", "0 3/8"),
    "no-stroke": ("1/2 2", "0 0", "0 0", "1/2 1", None, None),
    "forced-overshoot": ("1 2", "1 1", "0 0", "0 1/2", None, None),
}
REPEATS = 9
WARM_BATCHES = 100


@dataclass(frozen=True)
class Case:
    gain: tuple
    command: tuple
    gap: tuple
    goal: tuple


def parse_interval(text):
    return None if text is None else tuple(map(Fraction, text.split()))


def ordered_interval(lo, hi):
    return (lo, hi) if lo <= hi else None


def certificate(case, region, shared, schedule):
    reason = None
    if region is None:
        if case.goal[0] > 0 and case.gain[1] * case.command[1] < case.gap[1] + case.goal[0]:
            reason = "short-stroke"
        elif case.gain[0] * case.command[0] > case.gap[0] + case.goal[1]:
            reason = "overshoot"
        else:
            reason = "gap-conflict"
    return {"gain_region": region, "shared_commands": shared,
            "schedule_extension": schedule if region is not None else None,
            "empty_region_reason": reason}


def specialized(case):
    gain_min, gain_max = case.gain
    command_min, command_max = case.command
    target_min, target_max = case.goal
    required = case.gap[1] + target_min if target_min else Fraction(0)
    permitted = case.gap[0] + target_max

    region = None
    if required <= permitted and (command_max or required == 0):
        lo = max(gain_min, required / command_max) if command_max else gain_min
        hi = min(gain_max, permitted / command_min) if command_min else gain_max
        region = ordered_interval(lo, hi)
    shared = ordered_interval(max(command_min, required / gain_min),
                              min(command_max, permitted / gain_max))
    return certificate(case, region, shared, required)


def scalar_bounds(limits, constraints):
    """Intersect limits with inequalities a*x <= b."""
    lo, hi = limits
    for a, b in constraints:
        if a > 0:
            hi = min(hi, b / a)
        elif a < 0:
            lo = max(lo, b / a)
        elif b < 0:
            return None
        if lo > hi:
            return None
    return lo, hi


def composed(case):
    # Each row is a*r + b*u <= rhs, with inverse gain r > 0 and b = +/-1.
    # Compile the admissible noncontact/contact modes at each gap vertex.
    limits = [(0, -1, -case.command[0]), (0, 1, case.command[1])]
    plant_rows = []
    for gap in case.gap:
        if case.goal[0] > 0:
            plant_rows.append((gap + case.goal[0], -1, Fraction(0)))
        plant_rows.append((-(gap + case.goal[1]), 1, Fraction(0)))

    rows = limits + plant_rows
    lower = [(a, rhs) for a, b, rhs in rows if b == -1]
    upper = [(a, rhs) for a, b, rhs in rows if b == 1]
    # With unit, opposite coefficients, Fourier–Motzkin just adds each
    # pair of rows to remove u and leaves one scalar inequality in r.
    projected = ((a_lo + a_hi, rhs_lo + rhs_hi)
                 for (a_lo, rhs_lo), (a_hi, rhs_hi) in product(lower, upper))
    inverse = scalar_bounds((1 / case.gain[1], 1 / case.gain[0]), projected)
    region = None if inverse is None else (1 / inverse[1], 1 / inverse[0])
    schedule = max((a for a, b, _ in plant_rows if b == -1), default=Fraction(0))

    corner_rows = ((b, rhs - a / gain)
                   for gain, (a, b, rhs) in product(case.gain, plant_rows))
    shared = scalar_bounds(case.command, corner_rows)
    return certificate(case, region, shared, schedule)


ARMS = {"specialized": specialized, "composed": composed}


def run_batch(arm):
    results = {}
    for name, values in FIXTURES.items():
        case = Case(*(parse_interval(value) for value in values[:4]))
        proposed = json.loads(json.dumps(ARMS[arm](case), default=str))
        try:
            proof = check(case, proposed)
        except Rejected as rejected:
            results[name] = {"certificate": proposed, "accepted": False,
                             "reason": str(rejected)}
        else:
            results[name] = {"certificate": proposed, "accepted": True, "proof": proof}
    return results


def locked_matches(results):
    matches = 0
    for name, row in results.items():
        expected_region, expected_shared = map(parse_interval, FIXTURES[name][4:])
        proposed = row["certificate"]
        matches += fraction_interval(proposed["gain_region"]) == expected_region
        matches += fraction_interval(proposed["shared_commands"]) == expected_shared
    return matches


def negative_controls(results):
    mutations = (
        ("widened-design", "weak-design", {"gain_region": ["1/4", "2"]}),
        ("truncated-design", "wide", {"gain_region": ["3/4", "2"]}),
        ("overstated-shared", "branch-crossing", {"shared_commands": ["0", "1/2"]}),
        ("gap-violating-schedule", "wide", {"schedule_extension": "3/4"}),
        ("spurious-empty-design", "wide", {"gain_region": None, "schedule_extension": None,
                                         "empty_region_reason": "gap-conflict"}),
        ("spurious-empty-shared", "shared-tight", {"shared_commands": None}),
    )
    outcomes = {}
    for name, fixture, changes in mutations:
        case = Case(*(parse_interval(value) for value in FIXTURES[fixture][:4]))
        proposed = results[fixture]["certificate"] | changes
        try:
            check(case, proposed)
        except Rejected as rejected:
            outcomes[name] = {"rejected": True, "reason": str(rejected)}
        else:
            outcomes[name] = {"rejected": False}
    return outcomes


def json_wire(value):
    return json.dumps(value, sort_keys=True, default=str)


def timed_trials(mode, reference):
    trials = []
    for index in range(REPEATS):
        order = list(ARMS) if index % 2 == 0 else list(reversed(ARMS))
        times = {}
        checks = {}
        for arm in order:
            if mode == "warm":
                matches = True
                start = perf_counter_ns()
                for _ in range(WARM_BATCHES):
                    result = run_batch(arm)
                    matches &= result == reference[arm]
                elapsed = (perf_counter_ns() - start) / WARM_BATCHES
            else:
                invocation = [sys.executable, "-B", str(Path(__file__).resolve()),
                              "--arm", arm]
                start = perf_counter_ns()
                child = subprocess.run(invocation, capture_output=True, text=True)
                elapsed = perf_counter_ns() - start
                matches = (child.returncode == 0 and
                           json.loads(child.stdout) == json.loads(json_wire(reference[arm])))
                if child.returncode:
                    checks[f"{arm}_error"] = child.stderr
            times[arm] = elapsed
            checks[arm] = bool(matches)
        trials.append({"order": order, "ns_per_batch": times, "matches_reference": checks})
    medians = {arm: median(trial["ns_per_batch"][arm] for trial in trials) for arm in ARMS}
    return {"trials": trials, "median_ns_per_batch": medians,
            "composed_over_specialized": medians["composed"] / medians["specialized"]}


def experiment():
    start = datetime.now().astimezone()
    reference = {arm: run_batch(arm) for arm in ARMS}
    controls = negative_controls(reference["specialized"])
    warm = timed_trials("warm", reference)
    cold = timed_trials("cold", reference)
    return {"started": start.isoformat(), "finished": datetime.now().astimezone().isoformat(),
            "python": sys.version, "platform": platform.platform(), "fixtures": FIXTURES,
            "reference": reference,
            "locked_matches": {arm: locked_matches(rows) for arm, rows in reference.items()},
            "negative_controls": controls, "warm_batches_per_trial": WARM_BATCHES,
            "retries": 0, "warm": warm, "cold": cold}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", choices=ARMS)
    args = parser.parse_args()
    print(json_wire(run_batch(args.arm) if args.arm else experiment()))
