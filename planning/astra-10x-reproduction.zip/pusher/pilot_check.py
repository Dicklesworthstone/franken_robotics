"""Check exact pusher certificates without importing either solver."""

from fractions import Fraction
from itertools import pairwise, product


class Rejected(ValueError):
    """A proposed certificate fails a check against the plant."""


def require(condition, message):
    if not condition:
        raise Rejected(message)


def advance(gain, command, gap):
    travel = gain * command
    if travel <= gap:
        return Fraction(0)
    return travel - gap


def fraction_interval(value):
    return None if value is None else tuple(map(Fraction, value))


def corner_window(gain, gap, goal):
    """Intersect the two simulated line segments with the goal window."""
    goal_min, goal_max = goal
    commands = (Fraction(0), gap / gain, (gap + goal_max + 1) / gain)
    points = [(command, advance(gain, command, gap)) for command in commands]
    pieces = []
    for (left, start), (right, end) in pairwise(points):
        first, last = max(start, goal_min), min(end, goal_max)
        if first > last:
            continue
        if start == end:
            pieces.append((left, right))
        else:
            scale = (right - left) / (end - start)
            pieces.append((left + (first - start) * scale,
                           left + (last - start) * scale))
    return pieces[0][0], pieces[-1][1]


def check_shared(case, proposed):
    # The plant is monotone in gain and gap for nonnegative commands, so
    # intersecting the corner windows covers every loaded stroke.
    lower = [(case.command[0], "actuator minimum")]
    upper = [(case.command[1], "actuator maximum")]
    for gain, gap in product(case.gain, case.gap):
        lo, hi = corner_window(gain, gap, case.goal)
        origin = f"g={gain}, d={gap}"
        lower.append((lo, origin))
        upper.append((hi, origin))
    lo, lo_origin = max(lower, key=lambda bound: bound[0])
    hi, hi_origin = min(upper, key=lambda bound: bound[0])
    require(proposed == ((lo, hi) if lo <= hi else None),
            "shared interval differs from simulated corner intersection")
    return {"lower": lo, "lower_source": lo_origin,
            "upper": hi, "upper_source": hi_origin}


def check_empty_region(case, reason):
    gain_min, gain_max = case.gain
    command_min, command_max = case.command
    gap_min, gap_max = case.gap
    goal_min, goal_max = case.goal
    if reason == "short-stroke":
        actual = advance(gain_max, command_max, gap_max)
        require(actual < goal_min, "largest available stroke reaches the lower goal")
        return {"gain": gain_max, "command": command_max, "gap": gap_max,
                "displacement": actual, "required_at_least": goal_min}
    if reason == "overshoot":
        actual = advance(gain_min, command_min, gap_min)
        require(actual > goal_max, "smallest available stroke meets the upper goal")
        return {"gain": gain_min, "command": command_min, "gap": gap_min,
                "displacement": actual, "required_at_most": goal_max}
    require(reason == "gap-conflict", "missing empty-region witness")
    # Even with the actuator limits removed, the free/contact replay at
    # normalized gain 1 demands incompatible extension bounds.
    lo, _ = corner_window(Fraction(1), gap_max, case.goal)
    _, hi = corner_window(Fraction(1), gap_min, case.goal)
    require(lo > hi, "disturbance vertices permit a common extension")
    return {"extension_at_least": lo, "lower_gap": gap_max,
            "extension_at_most": hi, "upper_gap": gap_min}


def check_region(case, region, schedule, reason):
    if region is None:
        require(schedule is None, "empty design region carries a schedule")
        return {"empty_region_witness": check_empty_region(case, reason)}

    lo, hi = region
    gain_min, gain_max = case.gain
    command_min, command_max = case.command
    gap_min, gap_max = case.gap
    goal_min, goal_max = case.goal
    require(reason is None and gain_min <= lo <= hi <= gain_max,
            "design interval outside the declared family")
    require(schedule is not None and schedule >= 0, "invalid schedule extension")

    # The command max(command_min, schedule/gain) is nonincreasing in gain
    # while its effective extension max(gain*command_min, schedule) is
    # nondecreasing. Therefore these corners control the whole interval.
    for gain, gap in product(region, case.gap):
        command = max(command_min, schedule / gain)
        require(command_min <= command <= command_max, "schedule exceeds actuator bounds")
        require(goal_min <= advance(gain, command, gap) <= goal_max,
                "schedule misses the target at a design/gap corner")

    excluded = []
    if gain_min < lo:
        require(goal_min > 0 and advance(lo, command_max, gap_max) == goal_min,
                "lower design boundary is not tight")
        excluded.append({"gain": gain_min, "command": command_max, "gap": gap_max,
                         "displacement": advance(gain_min, command_max, gap_max),
                         "required_at_least": goal_min})
    if hi < gain_max:
        require(command_min > 0 and hi * command_min == gap_min + goal_max,
                "upper design boundary is not tight")
        excluded.append({"gain": gain_max, "command": command_min, "gap": gap_min,
                         "displacement": advance(gain_max, command_min, gap_min),
                         "required_at_most": goal_max})
    return {"excluded_family_corners": excluded}


def check(case, certificate):
    region = fraction_interval(certificate["gain_region"])
    shared = fraction_interval(certificate["shared_commands"])
    schedule = certificate["schedule_extension"]
    proof = check_region(case, region, None if schedule is None else Fraction(schedule),
                         certificate["empty_region_reason"])
    proof["shared_bounds"] = check_shared(case, shared)
    return proof
