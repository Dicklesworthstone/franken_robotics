(set-logic NRA)
(declare-const u Real)
(assert (xor (and (and (<= 0 u) (<= u 1)) (forall ((g Real)) (=> (and (<= (/ 1 2) g) (<= g 1)) (forall ((d Real)) (=> (and (<= (/ 1 4) d) (<= d (/ 1 2))) (let ((y (ite (>= (* g u) d) (- (* g u) d) 0))) (and (<= 0 y) (<= y (/ 1 8))))))))) (and (<= 0 u) (<= u (/ 3 8)))))
(check-sat-using (then simplify (using-params qe :qe_nonlinear true) smt))
