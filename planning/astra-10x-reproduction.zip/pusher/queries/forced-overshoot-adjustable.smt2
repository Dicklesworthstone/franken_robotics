(set-logic NRA)
(declare-const g Real)
(assert (xor (and (and (<= 1 g) (<= g 2)) (exists ((u Real)) (and (and (<= 1 u) (<= u 1)) (forall ((d Real)) (=> (and (<= 0 d) (<= d 0)) (let ((y (ite (>= (* g u) d) (- (* g u) d) 0))) (and (<= 0 y) (<= y (/ 1 2))))))))) false))
(check-sat-using (then simplify (using-params qe :qe_nonlinear true) smt))
