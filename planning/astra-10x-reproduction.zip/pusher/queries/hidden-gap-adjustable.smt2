(set-logic NRA)
(declare-const g Real)
(assert (xor (and (and (<= 1 g) (<= g 2)) (exists ((u Real)) (and (and (<= 0 u) (<= u 2)) (forall ((d Real)) (=> (and (<= 0 d) (<= d (/ 3 4))) (let ((y (ite (>= (* g u) d) (- (* g u) d) 0))) (and (<= (/ 3 4) y) (<= y (/ 5 4))))))))) false))
(check-sat-using (then simplify (using-params qe :qe_nonlinear true) smt))
