(set-logic NRA)
(declare-const g Real)
(assert (xor (and (and (<= (/ 1 2) g) (<= g 2)) (exists ((u Real)) (and (and (<= 0 u) (<= u 0)) (forall ((d Real)) (=> (and (<= 0 d) (<= d 0)) (let ((y (ite (>= (* g u) d) (- (* g u) d) 0))) (and (<= (/ 1 2) y) (<= y 1)))))))) false))
(check-sat-using (then simplify (using-params qe :qe_nonlinear true) smt))
