(set-logic NRA)
(declare-const u Real)
(assert (xor (and (and (<= 0 u) (<= u 2)) (forall ((g Real)) (=> (and (<= 1 g) (<= g (/ 5 4))) (forall ((d Real)) (=> (and (<= 0 d) (<= d (/ 1 4))) (let ((y (ite (>= (* g u) d) (- (* g u) d) 0))) (and (<= (/ 3 4) y) (<= y (/ 5 4))))))))) (and (<= 1 u) (<= u 1))))
(check-sat-using (then simplify (using-params qe :qe_nonlinear true) smt))
