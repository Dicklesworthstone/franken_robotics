(set-logic NRA)
(declare-const u Real)
(assert (xor (and (and (<= 1 u) (<= u 1)) (forall ((g Real)) (=> (and (<= (/ 1 2) g) (<= g 2)) (forall ((d Real)) (=> (and (<= 0 d) (<= d 0)) (let ((y (ite (>= (* g u) d) (- (* g u) d) 0))) (and (<= (/ 3 4) y) (<= y (/ 3 4))))))))) false))
(check-sat-using (then simplify (using-params qe :qe_nonlinear true) smt))
