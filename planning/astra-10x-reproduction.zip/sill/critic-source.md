# ATTACK · Q-001 · adversarial investigator (MO-04b devil's advocate / MO-quickie-pilot)

Agent: AmberCliff (claude-code, opus-5.5) · 2026-11-21 · RS-20261121-franken-robotics-astra-10x
Read: `intake/order-attack.md`, `intake/question_of_record.md`, and Astra plan §§1, 4.4, 5, 9.4, 13 and 14
(`COMPREHENSIVE_PLAN_FOR_FRANKEN_ROBOTICS__ASTRA.md`).
No MOR_*, `.mor/` or other panes' files were opened. All artifacts are in `analyses/attack/`.
Scripts need numpy and scipy; run them with `python3 -I`.

## Verdict (read this first)

**Claim attacked.** Astra's *first decision to earn* (§1, §4.4, §13.2):

> "A larger wheel improves approach geometry and reduces available tangential force for a given axle torque.
> Either design can lose." (§1)
> "The test must determine which effect dominates once weight distribution, motor lag, compliance, collision and
> chassis clearance are included." (§4.4)

The broad form is that the registered 60→75 mm wheel A/B (§13.2) is a design decision about geometry versus
tread force, and that the §13.2 fidelity diagnosis protects its verdict.

**Killed.** As registered, the verdict comes from neither effect. It comes from a **discrete-time controller
instability during wheel slip** together with an **unstated parameter, rotor inertia**:

1. **One-line discriminator.** While a driven wheel slips, Coulomb friction torque does not depend on wheel rate,
   so the 100 Hz P loop (Kω = 2 A·s/rad, kt = 0.2 N·m/A, T = 0.01 s) acts on the wheel's spin inertia alone.
   The closed-loop pole is z = 1 − Kω·kt·T/I. For A, I = 3.6e-4 kg·m² gives |z| = **10.1**. For B, I = 8.8e-4
   (spin inertia grows as r⁴ at fixed density and width) gives |z| = **3.55**. Both loops are unstable and fall into
   a ±6 A bang-bang limit cycle. Launch tread force is 40 N for A, against at most 0.95 × 39 N of traction, so
   **A slips at launch for every friction draw**.
2. **Executable pilot.** In a planar dynamic model of the exact §13.2 fixture, the registered spec gives
   P(A) = 0.09 and P(B) = 0.78, so B-only ≈ 44/64 and A-only = 0, and the §13.2 rule says **promote B**.
   A fails on the flat, before the lip ("stall" at 0.56 s at μ = 0.5). Adding a rotor inertia of 1e-3 kg·m², which
   §13.2 never pins, or running the same P law at 1 kHz gives **300/300 successes for both designs**, so
   a = b = 0 and the verdict is **inconclusive**.
3. **The plan's own guard does not catch it.** §13.2's Diagnosis row checks for reversal "under timestep,
   contact-feature or tire-law refinement". Halving dt and doubling contact stiffness *preserves* the spurious
   verdict (A 0.12, B 0.82). This is a candidate **false certificate**, the top loss in Q-001's loss order.
4. **A never beats B** on any condition in any variant (a = 0 everywhere). "Either design can lose" is not
   exercised by the registered fixture.

**Self-attack: my own analytic baseline is also killed.** The quasi-static statics baseline (below) says the
cart needs μ ≥ 0.65–1.23 to cross. The stable-loop dynamic pilot crosses at **μ = 0.35** for both designs
(A at μ = 0.35: front edge cleared at 1.88 s, rear at 3.01 s, goal at 3.55 s). At 0.30 m/s, momentum carries
both hurdles. The statics μ* is a sufficient condition only. It is not an impossibility certificate, and it does
not predict this fixture. I retract K2 from v1 of this file.

## Evidence

### E1 · Dynamic pilot of the §13.2 fixture

`analyses/attack/planar_sill_pilot.py` (285 lines, numpy, 300 conditions vectorized, 18–72 s wall time per run)
models the fixture as follows:

* **Bodies.** A composite chassis, payload and wheel-mass rigid body with pitch, plus absolute spin of the lumped
  front (driven) and rear (free) wheel pairs.
* **Contact.** Penalty normal contact, overdamped (ζ ≈ 1.1, approximately the inelastic impact §13.2 asks for),
  with a Cundall–Strack tangential spring and Coulomb cap, which gives true sticking.
* **Terrain.** Sharp or 2 mm filleted sill, 0.012 × 0.10 m.
* **Drive and controller (§13.2).** Motor and driver with kt = ke = 0.2, R = 1 Ω, L = 10 mH, 24 V, ±6 A and 4 Ω current
  feedback. The 100 Hz rate P controller targets 0.30/r. Axle damping is 0.002.
* **Adjudication (§13.2).** Goal, 0.5 s upright dwell, rollover, stall and an 8 s horizon.
* **Grid.** μ from 0.35 to 0.95 in steps of 0.025, payload Δx ∈ {−0.04, 0, +0.04} m, edge ∈ {sharp, fillet}.
  The grid is used as uniform quadrature over the §13.2 draw.

Command: `python3 -I planar_sill_pilot.py [--rotor R] [--ctrl-hz F] [--dt D --k K --cn C] [--no-stall-terminal]`
(outputs `pilot_*.out` and `pilot_*.json`).

| Variant | slip-loop \|z\| A / B | P(success) A | P(success) B | B-only → E[b] of 64 | §13.2 verdict |
|---|---|---|---|---|---|
| **as registered** (rotor 0, 100 Hz) | 10.1 / 3.55 | 0.093 | 0.780 | 0.687 → 43.9 | **promote B** |
| refined dt 2.5e-5, k ×2 | 10.1 / 3.55 | 0.120 | 0.820 | 0.700 → 44.8 | promote B (survives §13.2 fidelity check) |
| stall rule non-terminal | 10.1 / 3.55 | 0.093 | 0.780 | 0.687 → 43.9 | promote B |
| rotor 2e-4 kg·m² | 6.14 / 2.71 | 0.267 | 0.947 | 0.680 → 43.5 | promote B |
| rotor 5e-4 | 3.65 / 1.90 | 0.593 | 1.000 | 0.407 → 26.0 | promote B |
| rotor 1e-3 | 1.94 / 1.13 | 1.000 | 1.000 | 0 → 0 | inconclusive |
| rotor 1.5e-3 | 1.15 / 0.68 | 1.000 | 1.000 | 0 → 0 | inconclusive |
| rotor 2.5e-3 (and refined) | 0.40 / 0.18 | 1.000 | 1.000 | 0 → 0 | inconclusive |
| 1 kHz control, rotor 0 | 0.11 / 0.54 | 1.000 | 1.000 | 0 → 0 | inconclusive |

The verdict flips between rotor inertias of **5e-4 and 1e-3 kg·m²**, which is 1.4–2.8× the 60 mm wheel's own
spin inertia. That is a physically ordinary range for a direct-drive (gear ratio one) motor. Every A failure in
the registered run happens before the front edge is climbed (`stall@front` or `timeout@front`).

Actual output, registered run (`pilot_registered.out`):

```text
tag=registered dt=5e-05 k=200000.0 cn=2000.0 rotor=0.0 ctrl_hz=100.0 stall_terminal=True conditions=300 wall=35.0s
  slip-phase loop multiplier A: |1 - Kp*kt*T/I| = |1 - 11.11| = 10.11 (UNSTABLE); launch tread force 40 N
  slip-phase loop multiplier B: |1 - Kp*kt*T/I| = |1 - 4.55| = 3.55 (UNSTABLE); launch tread force 32 N
  A sharp  pdx=+0.00: success  1/25 min-mu-success 0.950  fails {'stall@front': 16, 'timeout@front': 8}
  A sharp  pdx=+0.04: success  6/25 min-mu-success 0.825  fails {'stall@front': 14, 'timeout@front': 5}
  B sharp  pdx=+0.00: success 21/25 min-mu-success 0.450  fails {'timeout@front': 4}
  B fillet pdx=+0.04: success 21/25 min-mu-success 0.450  fails {'timeout@front': 4}
  grid-quadrature P(success): A 0.093  B 0.780  B-only 0.687  A-only 0.000  -> expected b/64 43.9, a/64 0.0
```

Rotor 2.5e-3 (`pilot_rotor.out`), with every stratum at 25/25 for both designs:

```text
  slip-phase loop multiplier A: |1 - Kp*kt*T/I| = |1 - 1.40| = 0.40 (stable); launch tread force 40 N
  A sharp  pdx=-0.04: success 25/25 min-mu-success 0.350  fails {}
  grid-quadrature P(success): A 1.000  B 1.000  B-only 0.000  A-only 0.000  -> expected b/64 0.0, a/64 0.0
```

Trace of the limit cycle (`--trace A,sharp,0,0.8`). Commanded current is +6 A, but the current sampled at the
ticks sits near −5.7 A. The cart crawls at 0.032 m/s against a 0.30 m/s target:

```text
t= 0.010 ... wfwd=+10.11 icmd=+6.00 i=+5.96      # wheel overspins (target 5 rad/s) within 10 ms
t= 0.010 ... wfwd=+10.19 icmd=-6.00 i=+5.96      # next tick: full reverse
t= 2.000 fc=(-0.4218,0.0598) vx=+0.032 ... icmd=+6.00 i=-5.66
```

### E2 · Quasi-static statics baseline: sufficient only, refuted as a predictor by E1

`python3 -I quasistatic_sill.py` (full output in `quasistatic_sill.out`). The baseline has two hurdles:

* **H1, front climb.** With the rear wheels free, the front edge reaction must be vertical, so μ ≥ tan θ_f.
* **H2, rear pull-over.** The free rear wheel is dragged over by front traction (3-equation equilibrium).

```text
design edge    payload |  H1 mu H1 tau |  H2 mu H2 tau |    mu*
A r60  sharp    +0.000 |  0.750  1.270 |  1.043  2.055 |  1.043
B r75  sharp    +0.000 |  0.646  1.468 |  1.024  2.619 |    inf   (needs 2.62 > 2.40 N.m)
B r75  fillet   +0.040 |  0.635  1.549 |  0.848  2.379 |  0.848
Front-hurdle family certificate r_min = h/(1-1/sqrt(1+mu^2)): mu=0.75 -> 60.0 mm, mu=0.65 -> 74.3 mm
```

* **K1 (holds quasi-statically only).** §4.4's 40→32 N tread-force loss does not bind at the front lip. H1 needs
  1.18–1.57 of the 2.40 N·m available, so the lip is a pure traction limit, where B is better. The loss binds at
  the rear pull-over, which §4.4 never names. **E1 shows this is moot at 0.30 m/s**, because momentum carries
  both hurdles once the loop is stable.
* **K2 (retracted).** v1 of this file claimed that statics predicts most pairs fail for both designs. E1 refutes
  this: with a stable loop, both designs succeed at every μ ≥ 0.35.
* **K4 (narrowed).** The closed form r_min(h, μ) is a universally quantified *sufficient* certificate. It is not an
  impossibility certificate. E1 is the point counterexample: a design with r < r_min(0.35) crosses at μ = 0.35.

### E3 · The registered n=64 decision rule

`python3 -I promotion_rule.py` (output in `promotion_rule.out`):

```text
n=64: number of (a,b) outcomes classified practical_tie = 0
a=b=0 (all pairs concordant): inconclusive  interval [-0.0662, +0.0662]
min B-only count to promote with a=0: b=15 (0.234)  interval [+0.0604, +0.3743]
smallest n at which even a=b=0 yields practical_tie: n=86
```

The registered pilot can never return a practical tie. In E1 the stable-loop truth (a = b = 0) therefore reads as
*inconclusive*, while the unstable-loop artifact reads as *promote B*. **The only decisive verdict the pilot can
reach in this fixture is the spurious one.**

## Implications for Q-001

* **False-certificate route, concrete.** Run §13.2 exactly as written, with rotor inertia unpinned or defaulted to
  0. The pipeline would promote B. It would then pass the plan's own timestep and contact-refinement diagnosis and
  pass the n=64 rule by a wide margin (b ≈ 44 ≫ 15). The cause would be a sampled-control artifact, and the A/B
  would answer neither of the questions §1 and §4.4 pose. A matched baseline such as MuJoCo with the same spec
  would reproduce the same artifact. The defect is in the **fixture spec**, not the solver, so solver-level
  validation and speed do not protect the decision.
* **Cheapest guard (constant cost, catches the artifact).** At fixture admission, compute
  Π = K·k_t·T / I_spin for every driven joint, in both the slip regime (spin inertia only) and the grip regime.
  Refuse or flag the fixture when Π ≥ 2. Also make actuator rotor inertia a required pinned field, and add one
  rotor-inertia or control-rate sensitivity pair to the §13.2 Diagnosis row.
* **Denominator for any 10× claim on P5.** "Time to a design decision" must include fixture admission checks and
  the actuator and controller sensitivity that E1 shows is decisive. Solver throughput affects none of it.
  Each 300-condition planar sweep here took 18–72 s on one CPU, and all ten sweeps together took under 6 minutes.
  Compute is not the bottleneck; spec correctness is.
* **Where a real new query might exist.** At 0.30 m/s the crossing is momentum-dominated, and statics cannot
  answer it (E2 retraction). A family query such as "minimum approach speed v_min(r, h, μ) that crosses, with a
  stable drive loop" is beyond the closed-form baseline. Its certificate would depend on the impact law, though,
  so it needs a validated impact model (§12.3) before it counts as verifiable.

## Predeclared discriminators for the studio team

1. Run §13.2 as written with rotor inertia 0. Prediction: B ≫ A, with B-only ≈ 0.6–0.7 and A-only ≈ 0, and
   most A failures happen before the lip.
2. Run it again with rotor inertia ≥ 1e-3 kg·m² or a 1 kHz loop. Prediction: both designs ≈ 100%, a = b = 0,
   *inconclusive*. If both predictions hold, the registered verdict measures the controller, not the wheel.
3. Kill condition for this attack: if a 3D studio run with a stable loop (Π < 2 in every regime) still shows
   B-only ≥ 15/64, the geometry effect is real at 0.30 m/s, and E1's lumped planar model missed it (heading
   stagger, roll, per-wheel slip).

## Limits

* The model is planar: left/right wheels are lumped, there is no heading (±2°) or roll, and slip is per pair,
  not per wheel.
* I used my own penalty contact (overdamped, ζ ≈ 1.1), not the plan's rigid inelastic law. Impact-law
  sensitivity was not run. The registered-case classification was stable under dt/2 and k×2.
* The friction draw is a deterministic grid (25 μ × 3 payload offsets × 2 edges) used as uniform quadrature,
  not the seed-17 64-draw table. The counter-based RNG is not available here.
* Wheels are uniform cylinders with no rotor inertia, matching §13.2's silence on rotor inertia. The current loop
  is continuous, and the 4 Ω driver plus ±24 V clamp are as specified. Energy accounting was not computed.
* The stall rule was treated as terminal. The non-terminal reading gives identical counts.
* `pilot_quick.out` is an earlier 13-μ run of the same physics and is consistent with the registered row.
