#!/usr/bin/env python3
"""Bounded planar dynamic pilot of the Astra §13.2 sill A/B fixture (heading 0, left/right lumped).

Composite rigid body (chassis + payload + wheel masses at axles) with pitch, plus absolute spin of
the lumped front (driven) and rear (free) wheel pairs. Penalty normal contact k*delta - c*vn,
Cundall-Strack tangential spring with Coulomb cap (true sticking). Terrain: run-in floor, sill
[0,0.10]x[0,0.012] with sharp or 2 mm filleted upper edges, run-out floor.
Motor per §13.2: kt=ke=0.2, R=1 ohm, L=10 mH, +-6 A plant clamp, 24 V bus; driver
V = R*icmd + ke*w + 4*(icmd-i); 100 Hz controller icmd = clip(2*(0.30/r - w), +-6). Axle damping
0.002 N.m.s/rad per wheel. Goal: assembly min x > 0.10, then |pitch| <= 5 deg for 0.5 s, by 8 s.
Stall: icmd saturated and CG advance < 2 mm over 0.5 s (terminal). Rollover: |pitch| > 35 deg.
Usage: planar_sill_pilot.py [--dt 5e-5] [--k 2e5] [--cn 2000] [--tag name] [--quick]
"""
import argparse
import json
import math
import sys
import time

import numpy as np

G, H, LS, AX = 9.81, 0.012, 0.10, 0.16
KT = KE = 0.2
R_M, L_M, IMAX, VBUS, KP_I, KP_W, V_CMD = 1.0, 0.010, 6.0, 24.0, 4.0, 2.0, 0.30
C_AX = 0.002


def build(conds):
    K = len(conds)
    a = {k: np.array([c[k] for c in conds], dtype=float) for k in conds[0]}
    rf, rr = a["rf"], np.full(K, 0.060)
    mwf, mwr = 0.2 * (rf / 0.060) ** 2, np.full(K, 0.2)
    pdx = a["pdx"]
    parts_m = [np.full(K, 5.0), np.full(K, 2.2), 2 * mwf, 2 * mwr]
    parts_x = [np.zeros(K), pdx, np.full(K, AX), np.full(K, -AX)]
    parts_z = [np.full(K, 0.05), np.full(K, 0.13), np.zeros(K), np.zeros(K)]
    M = sum(parts_m)
    cx = sum(m * x for m, x in zip(parts_m, parts_x)) / M
    cz = sum(m * z for m, z in zip(parts_m, parts_z)) / M
    Ic = (5.0 * (0.40 ** 2 + 0.08 ** 2) / 12 + 2.2 * (0.18 ** 2 + 0.08 ** 2) / 12
          + sum(m * ((x - cx) ** 2 + (z - cz) ** 2) for m, x, z in zip(parts_m, parts_x, parts_z)))
    p = dict(K=K, rf=rf, rr=rr, M=M, Ic=Ic, mu=a["mu"], rho=a["rho"],
             Iwf=2 * 0.5 * mwf * rf ** 2, Iwr=2 * 0.5 * mwr * rr ** 2,
             # axle offsets from CG in body frame
             fx=AX - cx, fz=-cz, bx=-AX - cx, bz=-cz,
             # chassis box rear-bottom/top corners relative to CG (body frame)
             crx=-0.20 - cx, crz0=0.01 - cz, crz1=0.09 - cz)
    return p


def closest_on_sill(cx, cy, rho):
    """Closest point on the sill boundary (left face, left fillet, top, right fillet, right face)."""
    cands = []
    # left face x=0, y in [0, H-rho]
    cands.append((np.zeros_like(cx), np.clip(cy, 0.0, H - rho)))
    # right face x=LS
    cands.append((np.full_like(cx, LS), np.clip(cy, 0.0, H - rho)))
    # top y=H, x in [rho, LS-rho]
    cands.append((np.clip(cx, rho, LS - rho), np.full_like(cx, H)))
    # fillets (quarter arcs); rho=0 degenerates to the corner point
    for ox, lo, hi in ((rho, math.pi / 2, math.pi), (LS - rho, 0.0, math.pi / 2)):
        oy = H - rho
        ang = np.clip(np.arctan2(cy - oy, cx - ox), lo, hi)
        cands.append((ox + rho * np.cos(ang), oy + rho * np.sin(ang)))
    best_d2 = None
    for px, py in cands:
        d2 = (cx - px) ** 2 + (cy - py) ** 2
        if best_d2 is None:
            best_d2, bx, by = d2, px, py
        else:
            m = d2 < best_d2
            best_d2 = np.where(m, d2, best_d2)
            bx, by = np.where(m, px, bx), np.where(m, py, by)
    return bx, by


def wheel_contacts(c_x, c_y, vax, vay, w, r, mu, rho, s, k, cn, kt, ct, dt):
    """Return total force on wheel (Fx,Fy), spin moment about centre, updated springs s[3]."""
    Fx = np.zeros_like(c_x)
    Fy = np.zeros_like(c_x)
    Mw = np.zeros_like(c_x)
    feats = [
        (np.minimum(c_x, 0.0), np.zeros_like(c_x)),          # run-in floor
        closest_on_sill(c_x, c_y, rho),                       # sill
        (np.maximum(c_x, LS), np.zeros_like(c_x)),           # run-out floor
    ]
    s_new = []
    for j, (px, py) in enumerate(feats):
        dx, dy = c_x - px, c_y - py
        d = np.sqrt(dx * dx + dy * dy)
        delta = r - d
        act = delta > 0
        dsafe = np.where(d > 1e-12, d, 1e-12)
        nx, ny = dx / dsafe, dy / dsafe
        tx, ty = -ny, nx
        rx, ry = px - c_x, py - c_y
        vcx = vax - w * ry
        vcy = vay + w * rx
        vn = vcx * nx + vcy * ny
        vt = vcx * tx + vcy * ty
        Fn = np.where(act, np.maximum(0.0, k * delta - cn * vn), 0.0)
        sj = np.where(act, s[j] + vt * dt, 0.0)
        cap = mu * Fn / kt
        sj = np.clip(sj, -cap, cap)
        Ft = np.clip(-kt * sj - ct * vt, -mu * Fn, mu * Fn)
        Ft = np.where(act, Ft, 0.0)
        fx, fy = Fn * nx + Ft * tx, Fn * ny + Ft * ty
        Fx += fx
        Fy += fy
        Mw += rx * fy - ry * fx
        s_new.append(sj)
    return Fx, Fy, Mw, s_new


def simulate(conds, dt=5e-5, k=2e5, cn=2000.0, settle=0.3, horizon=8.0, trace=None, stall_terminal=True,
             rotor=0.0, ctrl_hz=100.0):
    p = build(conds)
    K = p["K"]
    p["Iwf"] = p["Iwf"] + 2 * rotor  # direct-drive rotor (gear ratio one) spins with each front wheel
    kt_s, ct = k, 200.0
    rf, rr = p["rf"], p["rr"]
    # initial pose: both wheels on run-in floor (pitch from radius difference), front axle at x=-0.5
    phi = np.arctan2(rf - rr, 2 * AX)
    fax, fay = np.full(K, -0.5), rf
    X = fax - (p["fx"] * np.cos(phi) - p["fz"] * np.sin(phi))
    Y = fay - (p["fx"] * np.sin(phi) + p["fz"] * np.cos(phi))
    VX = np.zeros(K); VY = np.zeros(K); OM = np.zeros(K)
    wf = np.zeros(K); wr = np.zeros(K); cur = np.zeros(K)
    sf = [np.zeros(K)] * 3; sr = [np.zeros(K)] * 3
    icmd = np.zeros(K)
    wdes = V_CMD / rf
    n_settle, n_total = int(round(settle / dt)), int(round((settle + horizon) / dt))
    ctrl_every = int(round(1.0 / ctrl_hz / dt))
    win = int(round(0.5 * ctrl_hz)) + 1
    done = np.zeros(K, bool)
    outcome = np.array(["timeout"] * K, dtype=object)
    t_goal = np.full(K, np.nan); t_front_over = np.full(K, np.nan); t_rear_over = np.full(K, np.nan)
    dwell_start = np.full(K, np.nan)
    hist = []  # CG x at controller ticks for stall rule
    sat_hist = []
    max_pitch = np.zeros(K)
    first_stall = np.full(K, np.nan)
    for n in range(n_total):
        t = (n - n_settle) * dt
        c, s_ = np.cos(phi), np.sin(phi)
        fcx = X + p["fx"] * c - p["fz"] * s_; fcy = Y + p["fx"] * s_ + p["fz"] * c
        rcx = X + p["bx"] * c - p["bz"] * s_; rcy = Y + p["bx"] * s_ + p["bz"] * c
        # axle velocities
        fvx = VX - OM * (fcy - Y); fvy = VY + OM * (fcx - X)
        rvx = VX - OM * (rcy - Y); rvy = VY + OM * (rcx - X)
        Ffx, Ffy, Mf, sf = wheel_contacts(fcx, fcy, fvx, fvy, wf, rf, p["mu"], p["rho"], sf, k, cn, kt_s, ct, dt)
        Frx, Fry, Mr, sr = wheel_contacts(rcx, rcy, rvx, rvy, wr, rr, p["mu"], p["rho"], sr, k, cn, kt_s, ct, dt)
        wfwd = -(wf - OM)  # forward relative rate of the driven axle (encoder)
        if n >= n_settle and (n - n_settle) % ctrl_every == 0:
            icmd = np.clip(KP_W * (wdes - wfwd), -IMAX, IMAX)
            hist.append(X.copy()); sat_hist.append(np.abs(icmd) >= IMAX - 1e-9)
            if len(hist) > win:
                hist.pop(0); sat_hist.pop(0)
            if len(hist) == win:
                stalled = np.all(np.array(sat_hist), axis=0) & ((X - hist[0]) < 0.002)
                newst = stalled & ~done & np.isnan(first_stall)
                first_stall = np.where(newst, t, first_stall)
                if stall_terminal:
                    outcome[newst] = "stall"; done |= newst
        if trace is not None and n >= n_settle and (n - n_settle) % trace == 0:
            print(f"t={t:6.3f} fc=({fcx[0]:+.4f},{fcy[0]:.4f}) rc=({rcx[0]:+.4f},{rcy[0]:.4f}) "
                  f"vx={VX[0]:+.3f} pitch={math.degrees(phi[0]):+6.2f} wfwd={wfwd[0]:+6.2f} "
                  f"wr={-wr[0]:+6.2f} icmd={icmd[0]:+5.2f} i={cur[0]:+5.2f} "
                  f"Ff=({Ffx[0]:+6.1f},{Ffy[0]:+6.1f}) Fr=({Frx[0]:+6.1f},{Fry[0]:+6.1f})")
        ic = icmd if n >= n_settle else np.zeros(K)
        V = np.clip(R_M * ic + KE * wfwd + KP_I * (ic - cur), -VBUS, VBUS)
        cur = np.clip(cur + dt * (V - R_M * cur - KE * wfwd) / L_M, -IMAX, IMAX)
        tau_m = 2 * KT * cur  # forward (clockwise) torque on front wheel pair
        tdf = 2 * C_AX * (wf - OM); tdr = 2 * C_AX * (wr - OM)
        # composite body
        FX = Ffx + Frx; FY = Ffy + Fry - p["M"] * G
        Mc = ((fcx - X) * Ffy - (fcy - Y) * Ffx + (rcx - X) * Fry - (rcy - Y) * Frx
              + tau_m + tdf + tdr)
        VX += dt * FX / p["M"]; VY += dt * FY / p["M"]; OM += dt * Mc / p["Ic"]
        wf += dt * (Mf - tau_m - tdf) / p["Iwf"]
        wr += dt * (Mr - tdr) / p["Iwr"]
        X += dt * VX; Y += dt * VY; phi = phi + dt * OM
        if n < n_settle or n % 20:
            continue
        # adjudication (every 1 ms)
        pitch_deg = np.degrees(np.abs(phi))
        max_pitch = np.maximum(max_pitch, np.where(done, max_pitch, pitch_deg))
        roll = (pitch_deg > 35) & ~done
        outcome[roll] = "rollover"; done |= roll
        t_front_over = np.where(np.isnan(t_front_over) & (fcx > 0.0) & (fcy > H + 0.5 * rf), t, t_front_over)
        t_rear_over = np.where(np.isnan(t_rear_over) & (rcx > 0.0) & (rcy > H + 0.5 * rr), t, t_rear_over)
        crx = X + p["crx"] * c - np.maximum(p["crz0"] * s_, p["crz1"] * s_)
        minx = np.minimum(rcx - rr, np.minimum(fcx - rf, crx))
        reached = (minx > LS) & ~done & np.isnan(t_goal)
        t_goal = np.where(reached, t, t_goal)
        dwell_start = np.where(reached, t, dwell_start)
        upright = pitch_deg <= 5.0
        broke = ~np.isnan(dwell_start) & ~upright & ~done
        dwell_start = np.where(broke, np.nan, dwell_start)
        okd = ~np.isnan(dwell_start) & ((t - dwell_start) >= 0.5) & ~done
        outcome[okd] = "success"; done |= okd
        if done.all():
            break
    return dict(first_stall=first_stall.tolist(), outcome=outcome.tolist(), t_goal=t_goal.tolist(), t_front_over=t_front_over.tolist(),
                t_rear_over=t_rear_over.tolist(), max_pitch=max_pitch.tolist(), t_end=t)


def grid(quick=False):
    mus = np.round(np.arange(0.35, 0.9501, 0.05 if quick else 0.025), 4)
    conds = []
    for design, rf in (("A", 0.060), ("B", 0.075)):
        for edge, rho in (("sharp", 0.0), ("fillet", 0.002)):
            for pdx in (-0.04, 0.0, 0.04):
                for mu in mus:
                    conds.append(dict(design=design, rf=rf, edge=edge, rho=rho, pdx=pdx, mu=float(mu)))
    return conds


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dt", type=float, default=5e-5)
    ap.add_argument("--k", type=float, default=2e5)
    ap.add_argument("--cn", type=float, default=2000.0)
    ap.add_argument("--tag", default="nominal")
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--out", default=None)
    ap.add_argument("--trace", default=None, help="design,edge,pdx,mu e.g. B,sharp,0,0.5")
    ap.add_argument("--trace-every", type=float, default=0.05)
    ap.add_argument("--no-stall-terminal", action="store_true")
    ap.add_argument("--rotor", type=float, default=0.0, help="rotor inertia per front motor, kg.m^2")
    ap.add_argument("--ctrl-hz", type=float, default=100.0)
    a = ap.parse_args()
    if a.trace:
        d, e, pdx, mu = a.trace.split(",")
        c = dict(rf=0.060 if d == "A" else 0.075, rho=0.0 if e == "sharp" else 0.002, pdx=float(pdx), mu=float(mu))
        r = simulate([c], dt=a.dt, k=a.k, cn=a.cn, trace=int(round(a.trace_every / a.dt)),
                     stall_terminal=not a.no_stall_terminal, rotor=a.rotor, ctrl_hz=a.ctrl_hz)
        print({key: v[0] if isinstance(v, list) else v for key, v in r.items()})
        return
    conds = grid(a.quick)
    numeric = [dict(rf=c["rf"], rho=c["rho"], pdx=c["pdx"], mu=c["mu"]) for c in conds]
    t0 = time.time()
    res = simulate(numeric, dt=a.dt, k=a.k, cn=a.cn, stall_terminal=not a.no_stall_terminal,
                   rotor=a.rotor, ctrl_hz=a.ctrl_hz)
    wall = time.time() - t0
    rows = [dict(c, **{key: res[key][i] for key in ("outcome", "t_goal", "t_front_over", "t_rear_over", "max_pitch", "first_stall")})
            for i, c in enumerate(conds)]
    out = dict(rotor=a.rotor, ctrl_hz=a.ctrl_hz, stall_terminal=not a.no_stall_terminal, tag=a.tag, dt=a.dt, k=a.k, cn=a.cn, n=len(rows), wall_s=round(wall, 1), rows=rows)
    if a.out:
        with open(a.out, "w") as f:
            json.dump(out, f)
    # compact report: per (design, edge, payload) the success threshold in mu and failure modes
    print(f"tag={a.tag} dt={a.dt} k={a.k} cn={a.cn} rotor={a.rotor} ctrl_hz={a.ctrl_hz} "
          f"stall_terminal={not a.no_stall_terminal} conditions={len(rows)} wall={wall:.1f}s")
    for d, rf, mw in (("A", 0.060, 0.2), ("B", 0.075, 0.2 * (0.075 / 0.060) ** 2)):
        I = 0.5 * mw * rf ** 2 + a.rotor
        g = KP_W * KT / a.ctrl_hz / I
        print(f"  slip-phase loop multiplier {d}: |1 - Kp*kt*T/I| = |1 - {g:.2f}| = {abs(1 - g):.2f} "
              f"({'UNSTABLE' if abs(1 - g) > 1 else 'stable'}); launch tread force {2*KT*IMAX/rf:.0f} N")
    for design in ("A", "B"):
        for edge in ("sharp", "fillet"):
            for pdx in (-0.04, 0.0, 0.04):
                sel = [r for r in rows if r["design"] == design and r["edge"] == edge and r["pdx"] == pdx]
                succ = [r["mu"] for r in sel if r["outcome"] == "success"]
                modes = {}
                for r in sel:
                    if r["outcome"] != "success":
                        stage = "rear" if not math.isnan(r["t_front_over"]) else "front"
                        key = f"{r['outcome']}@{stage}"
                        modes[key] = modes.get(key, 0) + 1
                thr = f"{min(succ):.3f}" if succ else " none"
                print(f"  {design} {edge:6} pdx={pdx:+.2f}: success {len(succ):2d}/{len(sel)} "
                      f"min-mu-success {thr}  fails {modes}")
    keyf = lambda r: (r["edge"], r["pdx"], r["mu"])
    A = {keyf(r): r["outcome"] == "success" for r in rows if r["design"] == "A"}
    B = {keyf(r): r["outcome"] == "success" for r in rows if r["design"] == "B"}
    n = len(A); pa = sum(A.values()) / n; pb = sum(B.values()) / n
    bonly = sum(B[k_] and not A[k_] for k_ in A) / n; aonly = sum(A[k_] and not B[k_] for k_ in A) / n
    print(f"  grid-quadrature P(success): A {pa:.3f}  B {pb:.3f}  B-only {bonly:.3f}  A-only {aonly:.3f}  "
          f"-> expected b/64 {64*bonly:.1f}, a/64 {64*aonly:.1f}")
    sys.stdout.flush()


if __name__ == "__main__":
    main()
