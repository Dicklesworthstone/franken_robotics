#!/usr/bin/env python3
"""Exact behaviour of the Astra §13.2 paired decision rule at the registered pilot size n=64.

Rule (§13.2): b = B-only successes, a = A-only successes among n complete pairs. Two-sided 97.5%
Clopper-Pearson intervals for p_B-only and p_A-only; difference interval
[lo_b - hi_a, hi_b - lo_a]. Promote B if lower > +0.05; inferior if upper < -0.05;
practical tie if interval inside [-0.05, +0.05]; else inconclusive.
"""
from scipy.stats import beta

N = 64
ALPHA = 0.025  # two-sided 97.5% -> 1.25% per tail


def cp(k, n, alpha=ALPHA):
    lo = 0.0 if k == 0 else beta.ppf(alpha / 2, k, n - k + 1)
    hi = 1.0 if k == n else beta.ppf(1 - alpha / 2, k + 1, n - k)
    return lo, hi


def verdict(a, b, n=N):
    lo_b, hi_b = cp(b, n)
    lo_a, hi_a = cp(a, n)
    lo, hi = lo_b - hi_a, hi_b - lo_a
    if lo > 0.05:
        return "promote_B", lo, hi
    if hi < -0.05:
        return "B_inferior", lo, hi
    if lo >= -0.05 and hi <= 0.05:
        return "practical_tie", lo, hi
    return "inconclusive", lo, hi


ties = [(a, b) for a in range(N + 1) for b in range(N + 1 - a) if verdict(a, b)[0] == "practical_tie"]
print(f"n={N}: number of (a,b) outcomes classified practical_tie = {len(ties)}")
v = verdict(0, 0)
print(f"a=b=0 (all pairs concordant): {v[0]}  interval [{v[1]:+.4f}, {v[2]:+.4f}]")
bmin = next(b for b in range(N + 1) if verdict(0, b)[0] == "promote_B")
v = verdict(0, bmin)
print(f"min B-only count to promote with a=0: b={bmin} ({bmin/N:.3f})  interval [{v[1]:+.4f}, {v[2]:+.4f}]")
for a in (1, 2, 3):
    bm = next(b for b in range(N + 1 - a) if verdict(a, b)[0] == "promote_B")
    print(f"min B-only count to promote with a={a}: b={bm}")
# n needed for a practical tie to be reachable at all (a=b=0)
n_tie = next(n for n in range(64, 5000) if verdict(0, 0, n)[0] == "practical_tie")
print(f"smallest n at which even a=b=0 yields practical_tie: n={n_tie}")
