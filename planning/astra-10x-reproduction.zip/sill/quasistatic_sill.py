#!/usr/bin/env python3
"""ATTACK baseline: closed-form quasi-static statics for the Astra §13.2 sill A/B fixture.

Fixture (Astra §4.4, §13.2): 4-wheel cart, front-wheel drive, rear wheels free (axle damping
only), axles at chassis x=+-0.16 m, 5 kg uniform chassis box 0.40x0.20x0.08 m centred 50 mm above
the axle line, 2.2 kg payload box (0.18x0.14x0.08) on the chassis top, four 0.2 kg wheels of
radius 0.060 m (A). Design B grows the FRONT pair to 0.075 m radius at fixed density (+0.1125 kg
each). Rear pair stays 0.060 m. Sill: 0.012 m high, x in [0, 0.10] m, sharp or 2 mm fillet.
Motor: kt=0.2 N.m/A, +-6 A -> 1.2 N.m per front drive, 2.4 N.m per axle. g=9.81.
Goal: complete assembly past x=0.10 (so BOTH axles must cross the sill).

Quasi-static model (velocity -> 0, rigid contact, Coulomb mu, free rear wheel transmits no
tangential force):
  H1 front climb:  front wheel on sill edge, rear on run-in floor.  Only horizontal external
                   forces act at the front edge contact, so the edge reaction must be vertical:
                   mu >= tan(theta_f).  Independent of mass, CG, payload, torque.
  H2 rear pull-over: rear (free) wheel on sill edge, front (driven) wheel on run-out floor.
                   Edge force is purely normal (free wheel), front traction must supply its
                   horizontal component: mu >= F_f/N_f from 3-equation planar equilibrium.
Success (quasi-static sufficient condition) = mu >= max over the climb of both requirements and
required axle torque <= 2.4 N.m.  It is NOT a necessary condition: momentum can carry a cart
through the steep initial part of a climb (see dynamic pilot).
"""
import math

G = 9.81
H = 0.012          # sill height
LSILL = 0.10       # sill length
AX = 0.16          # half wheelbase
TAU_MAX = 2 * 0.2 * 6.0  # N.m per driven axle (two motors)


def cart(r_front, payload_dx):
    """Return masses and body-frame (along axle line, perpendicular up from axle line) points."""
    r_rear = 0.060
    m_wheel_rear = 0.2
    m_wheel_front = 0.2 * (r_front / 0.060) ** 2
    parts = [
        (5.0, (0.0, 0.05)),                       # chassis box centre 50 mm above axle line
        (2.2, (payload_dx, 0.05 + 0.04 + 0.04)),  # payload centred on top face, bottom flush
        (2 * m_wheel_front, (+AX, 0.0)),
        (2 * m_wheel_rear, (-AX, 0.0)),
    ]
    m = sum(p[0] for p in parts)
    cx = sum(p[0] * p[1][0] for p in parts) / m
    cz = sum(p[0] * p[1][1] for p in parts) / m
    return m, (cx, cz), r_rear


def world_cg(rear_c, front_c, cg_body):
    """Axle-line frame: origin midway between axle centres, x toward front axle."""
    dx, dy = front_c[0] - rear_c[0], front_c[1] - rear_c[1]
    L = math.hypot(dx, dy)
    ex = (dx / L, dy / L)
    ez = (-ex[1], ex[0])
    o = ((rear_c[0] + front_c[0]) / 2, (rear_c[1] + front_c[1]) / 2)
    return (o[0] + cg_body[0] * ex[0] + cg_body[1] * ez[0],
            o[1] + cg_body[0] * ex[1] + cg_body[1] * ez[1])


def edge_geom(r, rho):
    """Pivot (fillet centre) and pivot radius R=r+rho; theta measured from vertical."""
    pivot = (rho, H - rho)  # sharp edge: (0, H)
    return pivot, r + rho


def thetas(r, rho, n=400):
    pivot, R = edge_geom(r, rho)
    c0 = (r - pivot[1]) / R  # wheel centre still at height r (also touching floor)
    th0 = math.acos(c0)
    return [th0 * (1 - k / n) for k in range(n)]  # th0 -> ~0 as the wheel rises


def h1_front(r_f, rho, payload_dx):
    m, cgb, r_r = cart(r_f, payload_dx)
    pivot, R = edge_geom(r_f, rho)
    worst_mu, worst_tau = 0.0, 0.0
    for th in thetas(r_f, rho):
        fc = (pivot[0] - R * math.sin(th), pivot[1] + R * math.cos(th))
        rc = (fc[0] - math.sqrt((2 * AX) ** 2 - (fc[1] - r_r) ** 2), r_r)
        cg = world_cg(rc, fc, cgb)
        # vertical edge reaction V acting through wheel contact (line through pivot), rear N_r at rc x
        x_contact = pivot[0] - rho * math.sin(th)
        V = m * G * (cg[0] - rc[0]) / (x_contact - rc[0])
        mu_req = math.tan(th)                     # horizontal balance, independent of loads
        tau = V * math.sin(th) * r_f              # friction F = V sin(th) at lever r_f
        worst_mu, worst_tau = max(worst_mu, mu_req), max(worst_tau, tau)
    return worst_mu, worst_tau


def h2_rear(r_f, rho, payload_dx):
    m, cgb, r_r = cart(r_f, payload_dx)
    pivot, R = edge_geom(r_r, rho)
    worst_mu, worst_tau = 0.0, 0.0
    for th in thetas(r_r, rho):
        rc = (pivot[0] - R * math.sin(th), pivot[1] + R * math.cos(th))
        fc = (rc[0] + math.sqrt((2 * AX) ** 2 - (rc[1] - r_f) ** 2), r_f)
        assert fc[0] - r_f > LSILL, "front wheel must already be on run-out"
        cg = world_cg(rc, fc, cgb)
        n = (-math.sin(th), math.cos(th))         # free-wheel edge force along normal through rc
        # moments about front floor contact (fc[0], 0): Nr*[(rc-fc) x n] + (cg-fc) x (0,-mg) = 0
        arm_n = (rc[0] - fc[0]) * n[1] - (rc[1] - 0.0) * n[0]
        arm_g = -(cg[0] - fc[0]) * m * G
        Nr = -arm_g / arm_n
        Ff = Nr * math.sin(th)                    # traction the front must provide
        Nf = m * G - Nr * math.cos(th)
        mu_req = Ff / Nf
        tau = Ff * r_f
        worst_mu, worst_tau = max(worst_mu, mu_req), max(worst_tau, tau)
    return worst_mu, worst_tau


def main():
    print("Astra §13.2 sill fixture - quasi-static requirements (mu needed; axle torque N.m)")
    print(f"available front-axle torque {TAU_MAX:.2f} N.m; §4.4 tread-force limits "
          f"{TAU_MAX/0.060:.1f} N (r=60) vs {TAU_MAX/0.075:.1f} N (r=75)")
    hdr = f"{'design':6} {'edge':6} {'payload':>8} | {'H1 mu':>6} {'H1 tau':>6} | {'H2 mu':>6} {'H2 tau':>6} | {'mu*':>6}"
    print(hdr)
    print("-" * len(hdr))
    table = {}
    for name, r_f in (("A r60", 0.060), ("B r75", 0.075)):
        for edge, rho in (("sharp", 0.0), ("fillet", 0.002)):
            for pdx in (-0.04, 0.0, 0.04):
                m1, t1 = h1_front(r_f, rho, pdx)
                m2, t2 = h2_rear(r_f, rho, pdx)
                mu_star = max(m1, m2) if max(t1, t2) <= TAU_MAX else float("inf")
                table[(name, edge, pdx)] = (m1, m2, mu_star)
                print(f"{name:6} {edge:6} {pdx:+8.3f} | {m1:6.3f} {t1:6.3f} | {m2:6.3f} {t2:6.3f} | {mu_star:6.3f}")

    # Fraction of the registered friction draw U[0.35,0.95] that is quasi-statically sufficient.
    print("\nP(quasi-static success | mu~U[0.35,0.95]) per stratum, and B-only band width:")
    for edge in ("sharp", "fillet"):
        for pdx in (-0.04, 0.0, 0.04):
            pa = max(0.0, (0.95 - table[("A r60", edge, pdx)][2]) / 0.60)
            pb = max(0.0, (0.95 - table[("B r75", edge, pdx)][2]) / 0.60)
            print(f"  {edge:6} payload {pdx:+.2f}: A {pa:5.3f}  B {pb:5.3f}  B-only {max(0.0, pb-pa):5.3f}")

    # Family-level closed form for the front hurdle alone: r_min(h, mu) = h / (1 - 1/sqrt(1+mu^2))
    print("\nFront-hurdle family certificate r_min = h/(1-1/sqrt(1+mu^2)) for h=12 mm:")
    for mu in (0.35, 0.5, 0.65, 0.75, 0.8, 0.95):
        print(f"  mu={mu:.2f}: r_min = {1000 * H / (1 - 1 / math.sqrt(1 + mu * mu)):6.1f} mm")


if __name__ == "__main__":
    main()
