# Dueling Idea Wizards · Franken Robotics

**Test automatic derivation of sound component contracts first.** This was the highest-rated proposal, averaging 665/1000. No proposal received 700 from both independent reviewers. None established a tenfold advantage in total cost or time to a correct robot-design decision. The guarded pusher and deadline fixtures both returned the same complete family answers under existing exact methods. A matched dependency graph captured every saving in the clock-edit test. [Brenner findings](BRENNER_REPORT.md)

## Three-family score matrix

Each author deposited three independently developed ideas. Every other family scored all three on the same 0–1000 scale, and each author received both reviews. A dash marks the author’s own column. Mean ranks use the two external scores. The scores reflect research judgments. The qualification tests below determine which claims survived.

| Rank | Proposal | Claude | Codex | Gemini | Mean | Post-reveal disposition |
|---:|---|---:|---:|---:|---:|---|
| 1 | AGY2 · Compositional feasibility contracts | 640 | 690 | — | **665** | Test compiler-generated outer envelopes on 20 edits. Audit every pruned variant and match a hermetic contract DAG using the same envelopes. |
| 2 | COD1 · Certify joint A/B outcomes directly | 720 | — | 560 | **640** | One contact transition. Preserve the fixed paired rule and provide identical product-model reachability, batches and exact curtailment to the rival. |
| 3 | CC3 · Reuse a verified decision after edits | — | 745 | 510 | **627.5** | Claude withdrew sensitivity-margin reuse absent a certificate. A matched graph already duplicated every saving in the clock fixture. |
| 4 | CC2 · Family impossibility from mechanical bounds | — | 565 | 680 | **622.5** | Restrict to sound exclusions with approach energy, bounded control and a necessary condition. Exact algebra already handles the quasi-static problem. |
| 5 | AGY1 · Parametric hybrid reachability | 600 | 620 | — | **610** | Gemini corrected the original quantifiers, narrowed the controller class, and proposed a separate interval checker and predeclared unknown-volume cap. |
| 6 | COD2 · Exclude by a mandatory work cut | 560 | — | 590 | **575** | Keep the exact passive, energy-capped result. The active cart requires a verified, binding bound on its available energy and its entire support geometry. |
| 7 | COD3 · Minimum factory calibration tags | 380 | — | 690 | **535** | Retain the inverse query. Two tags solve the stipulated three-polytopes fixture. A separate executed Z3 model found one tag unsatisfiable and two tags satisfiable. The plant-derived inner and outer sets remain open. |
| 8 | AGY3 · Saltation, symmetry and event forks | 420 | 505 | — | **462.5** | Gemini retired tenfold claims for the binary cart and split-grip landing. Retain a single local-gradient test at regular, isolated events. |
| 9 | CC1 · Adaptive fidelity and paired stopping | — | 475 | 420 | **447.5** | Claude withdrew the decision procedure. Coarse concordance needs a sound relation to strict outcomes. Statistical stopping alone cannot supply one. |

[Machine-readable matrix](score-matrix.json) · [Claude reveal](WIZARD_REACTIONS_CC.md) · [Codex reveal](WIZARD_REACTIONS_COD.md) · [Gemini reveal](WIZARD_REACTIONS_AGY.md)

## What changed the ranking

**Contracts.** A local passivity or current bound can omit time correlation across the system. In a two-finger simulation, each finger needs one full unit-current tick, the shared bus can supply one unit per tick, and local capability summaries are identical. One tick has zero admissible joint schedules. Two ticks have exactly two. Enumeration and generic Z3 agree. A rule that adds both peak demands and prunes the two-tick design loses a feasible schedule. This is a negative control for a contract compiler. The next question is whether it can *derive* accurate cross-component envelopes at lower cold and amortized cost than an expert using Censi-style co-design and an incremental solver. [Executable check](../information/contract_bus_check.py) · [Receipt](../information/contract_bus.out) · [Primary baselines](primary-baselines.md)

**Decision reuse.** A camera packet could arrive before or after the controller committed. A correctly keyed hermetic DAG and the proposed receipt skipped exactly the same work on all four edit states. Omitting delivery from the dependency set inherited a false promotion. The 235-point spread between the external scores concerned distinctiveness, and the execution favored the stronger rival. The incremental idea needs a harder relation and a price for deriving it. [Locked experiment](../information/REUSE_CHECK.md)

**Calibration tags.** This had the largest disagreement, 310 points. Gemini valued the verifiable minimum. Claude objected that deriving admissible actions from a contact-rich plant was most of the work. Codex withdrew any advantage over exact SMT once both arms have the same command sets. The live Astra plan expanded during study, so reviewers also saw different section inventories. The author enumerated the three-polytopes fixture; a subsequent standalone SMT check reproduced its one-tag impossibility and two-tag witness. [Z3 model](../information/compare_cod3_tags.smt2) · [Receipt](../information/cod3-z3.out) A separate scalar gripper test found exact tag/deadline frontiers; its ordinary elimination baseline recovered all of them. [Deadline and tag test](../information/DEADLINE_CHECK.md) · [Disagreement register](disagreement_register.md)

**Impossibility.** For “every controller encounters some failing disturbance,” one successful trajectory is an insufficient refuter. The counterexample needs a controller successful against every admitted disturbance. Gemini changed its proposal to uniform failure over bounded design, policy and disturbance boxes, where one admissible successful run is a valid refuter. The update changes the question and narrows the eligible certificates. [Gemini reveal](WIZARD_REACTIONS_AGY.md)

## Author and source provenance

Three authors delivered nine proposals, all six directed assessments and all three final reveals. The portable packet identifies the model binding and original artifacts. [Provenance](PROVENANCE.md)
