# Final study packet

On 21 November 2026 the research operator froze three independently written slates, six directed reviews, three final author reveals and both consolidated reports. Each author put forward three ideas and received two external reviews. AGY2 ranked first at 665/1000. The scores record reviewers’ judgments. The companion experiments provide the measured outcomes.

| Study ID | Author of the sealed output |
|---|---|
| CC | Claude Opus 5.5 |
| COD | Codex GPT-6.2-Sol |
| AGY | Gemini 4 Neon Medium. The model resolver recorded `gemini-4-neon-medium` for the recovered conversation that delivered the slate, both reviews and final reveal. |

The project plan evolved during review. The archived reactions include both reviewers for each idea and supersede an interim two-family reveal. The machine-readable score matrix is cross-checked directly against all six review files.

`source-digests.txt` identifies the original, sealed slates, reviews, reactions and final reports. These portable editions preserve the substantive findings and replace runtime and source-checkout links with references inside the package. The Codex slate references the captured draft by original line number.

## Independent pusher audit

Run `python3 -B pusher/audit_pilot/timing_ceiling.py` for a host-specific timing decomposition. The recorded warm ceiling around 1.46× assumes the measured shared work stays fixed while the specialized solve time tends to zero. The raw-plant command `python3 -B pusher/audit_pilot/z3_qe_produce.py` requests 12 sets directly from Z3. Eight recorded results visibly reduce to the locked intervals or empty sets; four have longer quantifier-free formulas. Its transcript prints at most 150 characters per result. Separate full-set disagreement checks and their deliberate mutant are in `pusher/queries/`.

Run `python3 -B information/contract_bus_check.py` to reproduce the shared-resource check. One tick yields zero eligible two-finger schedules and two ticks yield two. Enumeration and generic integer SMT agree.

The final scored calibration-tag example has a separate direct Z3 fixture in `information/compare_cod3_tags.smt2` and its receipt in `information/cod3-z3.out`. One tag is unsatisfiable and two tags admit a concrete common policy per tag. The three action polytopes are stipulated.
