*Note: Winnowed from 30 candidate simulation-only architectures across reachability, formal methods, compositional design, differentiable/hybrid physics, GPU codegen, and sequential testing. All items below are unmeasured architectural hypotheses; no measured gains are claimed.*

### AGY1 — Parametric Hybrid Reachability & Impossibility Certificates
- **New Family Query:** For compact morphology set $\Theta$, disturbance set $D$, and owned current-limited controller class $\mathcal{U}$, decide $\forall \theta\in\Theta_k,\forall u\in\mathcal{U},\exists d\in D:\text{Fail}$ (impossibility) or $\exists\theta,u,\forall d\in D:\text{Safe}$ using branch-and-bound Taylor-model hybrid enclosures, emitting an independently reproducible interval-arithmetic certificate.
- **Matched Rival:** Drake/MuJoCo + CMA-ES/RL + standalone SMT (sampling cannot prove universal impossibility).
- **Cost Boundary:** Cold encoding, enclosure refinement, unknown-box retries, human time, compute, and independent checker cost per family query.
- **Falsifier:** Any independently simulated point counterexample $(\theta^*,u^*,d^*)$ contradicting a certificate, or rival matching the query at comparable inclusive cost.
- **Minimal Experiment:** Certify infeasible wheel-radius/COM sub-boxes on the §13.2 12 mm sill fixture.
- **Primary Source:** Chen, Ábrahám & Sankaranarayanan (2013), *Flow\*: An Analyzer for Non-Linear Hybrid Systems*, CAV.

### AGY2 — Compositional Assume-Guarantee Co-Design Calculus
- **10× Mechanism:** Compiles assemblies as typed open systems with cached subsystem feasibility/passivity contracts (motor-bus envelope, wheel-sill wrench cone, chassis clearance). Local design edits recompute only dirty subgraphs and boundary contracts, pruning infeasible variants before full-physics rollouts and controller retuning.
- **Matched Rival:** Xacro/URDF + MuJoCo/MJX + warm-started RL/CMA-ES with common random numbers (CRN) and equal tuning budgets.
- **Cost Boundary:** Cold contract authoring, abstraction validation, false-pruning retries, human time, compute, and full-physics validation of survivors, amortized over a predeclared $K\ge 20$-variant sweep (not expected to hit $10\times$ at $K=1$).
- **Falsifier:** Any pruned variant outperforming the winner on independent full physics (unsoundness), or inclusive cost ratio $<10\times$ at predeclared $K$.
- **Minimal Experiment:** 20-variant wheel-radius/mass/gear sweep on the §13.2 64-condition paired fixture.
- **Primary Source:** Censi (2016), *A Mathematical Theory of Co-Design*, arXiv:1512.08055.

### AGY3 — Saltation-Guarded Hybrid Sensitivity & Symmetry-Quotient Forking
- **10× Mechanism:** Replaces blind black-box sampling and biased smoothed-contact gradients with exact hybrid tangent transport via saltation matrices, an explicit refusal gate near grazing/frictional degeneracy (falling back to local perturbations), counterfactual event-forking under CRN, and morphology-automorphism quotienting until physical symmetry breaks.
- **Matched Rival:** MJX/Isaac Lab + CMA-ES/PPO or smoothed differentiable physics with CRN and matched retuning budget.
- **Cost Boundary:** Guard compilation, saltation finite-perturbation checks, refusal-fallback rollouts, human debugging, compute, and independent high-fidelity contact-law replay per verified decision.
- **Falsifier:** Refusal rate forcing black-box cost, predicted design ranking reversing on a held-out landing or higher-fidelity contact law, or inclusive ratio $<10\times$.
- **Minimal Experiment:** §13.2 60 mm vs. 75 mm cart A/B decision plus quadruped split-grip landing ranking on held-out materials.
- **Primary Source:** Kong et al. (2023), *Saltation Matrices: The Essential Tool for Linearizing Hybrid Dynamical Systems*, arXiv:2306.06862.
