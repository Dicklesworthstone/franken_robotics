# WIZARD_IDEAS_CC — independent Claude slate (OrangeStone, order-cc)

Q-001. Source: Astra plan (§ anchors below). About 30 candidates considered privately, winnowed to 3. No URL below was re-fetched in this session; verify them before citing. Every tenfold figure is **conditional potential**, not a measured result: none has a matched measurement yet. Measurement denominator (predeclared, inclusive): cold authoring + validation + retries + unknown/inconclusive reruns + human minutes + compute + amortized build, measured to an independently replayed decision (§13.1, §13.4 P5).

## CC1 · rank 1 · Decision-sufficient adaptive fidelity (sequential paired stopping)
**Mechanism.** Do not finish each design comparison at full fidelity. Spend each trial only until the §13.2 verdict (CP interval on discordant pairs) is settled, and escalate fidelity (Δt, contact law, §6.3) only on pairs whose sign is unstable (A/B discordant or near the margin). Use an anytime-valid paired e-process so the frozen rule survives early stopping. Concordant pairs stay low-fidelity; the strict profile is spent only where the decision depends on it (§14.2 #12, §17 "training vs engineering fidelity").
**Rival.** Composed baseline: MuJoCo/Isaac + Optuna + a fixed 64-pair high-fidelity run with the same CP rule.
**Cost.** Cuts compute and validation; adds one-time e-process qualification. Human time is unchanged.
**Falsifier.** Verdict differs from the full high-fidelity replay on any sealed holdout, or the inclusive ratio is below 10 on the §13.2 cart and §13.2 quadruped. A low-fidelity concordant pair that flips at high fidelity counts as a soundness failure.
**Pilot.** Wheel 60 vs 75 mm, 64 conditions, cost to verdict, sequential vs fixed.
**Independent check.** Rerun every pair at strict fidelity in MuJoCo.
**Prior art.** Waudby-Smith & Ramdas, "Estimating means of bounded random variables by betting", https://arxiv.org/abs/2010.09686 (§3–4); multi-fidelity BO, Kandasamy et al. https://arxiv.org/abs/1603.06288.

## CC2 · rank 2 · Family-level impossibility certificates (new query, not a speedup)
**Query.** ∀ r∈[r₀,r₁], ∀ μ∈[μ₀,μ₁], ∀ payload offset∈P, with controller ownership fixed (§13.2 current-limited P controller) or ∃ a feedforward bounded by I_max: the cart either cannot clear lip h, or a design satisfies x=√(2rh−h²) such that k_t·I_max·(…) ≥ W·x under a μ-cone (§4.4 oracle). Output is an existence witness or an interval-arithmetic infeasibility certificate over the whole box, checked by a small independent checker (interval/SMT) separate from FrankenSim (§5.8, §5.7 barrier row).
**Rival.** Dense sampling (10⁴ sims) + the conservative §4.4 quasi-static bound.
**Cost.** Checker authoring is one-time; each certificate costs a branch-and-bound split count.
**Falsifier.** Any single simulated or analytic point counterexample inside a certified box kills the certificate (Q-001).
**Pilot.** Quasi-static lip model only, r∈[50,90] mm.
**Independent check.** dReal re-proof plus sampled MuJoCo counterexample search.
**Prior art.** Gao, Kong & Clarke, dReal δ-complete decision procedures, https://arxiv.org/abs/1310.8278 (§3).

## CC3 · rank 3 · Third framing: amortize decisions, not simulations (decision-receipt reuse)
**Mechanism.** Store each validated verdict as a receipt: frozen inputs, a dependency mask (§3, §14.2 #8), and a sensitivity/validity domain (§14.1 #5 atlas). A new query whose patch touches only fields outside the mask, or stays inside the certified margin, inherits the verdict with a proof of non-dependence. Otherwise it reruns only the invalidated pairs. The saving is in the number of decisions re-earned across a design campaign, not in steps/s.
**Rival.** Composed baseline: DVC/Bazel cache + a full rerun of each comparison.
**Falsifier.** A reused verdict disagrees with a fresh independent run (false-reuse rate >0 on seeded mutants per §15.3 W27), or reuse under 90% of a realistic edit stream yields an inclusive ratio below 10.
**Pilot.** A 30-edit W27 campaign (cosmetic, camera, wheel, friction).
**Independent check.** A blind full rerun of a random 20% of reused verdicts.
**Prior art.** Bazel hermetic action cache, https://bazel.build/remote/caching; Adapton incremental computation, https://arxiv.org/abs/1503.07792.
