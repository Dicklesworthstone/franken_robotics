# Q-001 · Independent Codex architecture duel

Use one sealed, independently accepted decision batch as the denominator. Freeze inputs, deliverables, tolerances, controller access, hardware and reviewer resources across arms. Charge cold authoring, elapsed time, human time and compute, including unknowns, retries and checking. Report amortized cost over a predeclared edit count. Tenfold potential is conditional on matched measurement. Retire an architectural advantage if the composed baseline delivers the same query at comparable total cost.

## COD1 · Rank 1 · Verify paired outcome counts directly

Compile a fixed-controller A/B comparison into a joint terminal monitor. Carry shared terrain and payload variables through both plants. Close a parameter box once every compatible branch pair yields identical joint success, hard-limit and validity labels. Split ambiguous boxes or evaluate their draws individually. Feed the labels into Astra’s frozen paired interval rule. This adds decision-level closure to Astra’s trajectory batching. Astra §13.2 (Astra draft, line 1243) · §§18.3, 18.6 (Astra draft, line 1877)

**Duel.** Matched-law MuJoCo plus Flow* on a shared-input product model. Give both arms the joint monitor, equal caching and one independent adjudicator. Charge enclosure setup, branching, fallback and checking. Tenfold requires inclusive time within 10% of baseline, including energy and traces if the full §13.2 contract is claimed.

**Pilot and falsifier.** Run a sagittal sharp-lip pair over one friction interval spanning slip onset. Independently check the branch cover and replay all sealed points under a separately authored matched law. One mislabeled draw kills the certificate. [Chen et al., Flow*, §1](https://home.cs.colorado.edu/~srirams/papers/cav2013-flowstar.pdf#page=1)

## COD2 · Rank 2 · Exclude a family by mandatory work

Compile a mandatory geometric crossing from the goal. Prove its minimum potential rise exceeds initial stored energy plus all allowed external work. The bound covers even clairvoyant controllers without unrolling contact schedules. For a passive fixed-sill model, an 8 kg load starting at rest must rise 12 mm to reach the top. For every radius in [60,75] mm, the required 0.94176 J exceeds all gross input budgets in [0,0.90] J. Astra §4.4 (Astra draft, line 318) · §13.2 (Astra draft, line 1243) · §18.2 (Astra draft, line 1818)

**Duel.** Drake contact-implicit planning plus interval or occupation-measure dual bounds, with the same analytic cut available. Charge geometry authoring, cut discovery, independent checking and unresolved boxes per accepted exclusion.

**Pilot and falsifier.** Check the single-wheel geometry and passivity assumptions independently. Exact arithmetic gives a 0.04176 J gap. Adding 0.05 J of initial kinetic energy removes the exclusion at the top budget. For Astra’s cart, recompute the cut across all supports and include approach energy. Any admissible successful trace inside the certified box kills it. [Lasserre et al., §2, Eqs. 2.12–2.14](https://homepages.laas.fr/henrion/papers/ocp.pdf#page=6)

## COD3 · Rank 3 · Minimize factory calibration labels

Third framing. Find the fewest factory tags that let one controller serve three simulated gripper SKUs across payloads in [1,1.1] kg. Choose one tag per SKU and one causal policy shared across SKUs and payloads. With a fixed observation-identical prefix, each tag needs a common terminal command. Color the hypergraph of minimal empty intersections of robust action polytopes. Check feasible commands for the upper bound and conflicting intersections plus uncolorability for the lower bound. Astra §18.1 (Astra draft, line 1771) · §§18.4–18.5 (Astra draft, line 1902)

**Duel.** Matched plant reachability plus exact SMT over tag assignments and command inequalities. Charge envelope derivation, solving, independent checking and unknowns per certified minimum.

**Pilot and falsifier.** For normalized planar placement commands in [0,1]², assign x≥2/3, y≥2/3 and x+y≤1 to separate SKUs. Exact vertex and partition enumeration found every pair intersects, the triple fails, and two tags suffice. Any common command across all three under the same model falsifies the lower bound. [Shoukry et al., SMC, §4](https://people.eecs.berkeley.edu/~sseshia/pubdir/hscc17-smc.pdf)
