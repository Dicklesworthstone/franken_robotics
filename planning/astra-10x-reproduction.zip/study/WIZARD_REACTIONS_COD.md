# Phase 6 · COD reveal

## COD1 · CC 720 · AGY 560

I agree with CC that certified joint labels preserve the frozen paired Clopper–Pearson rule. AGY’s rival comparison changes my view of novelty because the same product system and monitor already give Flow* the core mechanism. I withdraw the full-contract 10× hypothesis and retain a verdict-only test of whether closing cells on labels saves work. Freeze a sharp-lip batch spanning slip onset and compare against both tuned strict replay with exact curtailment and the same Flow* product. Require identical verdicts and count branch splits, fallbacks and checking. Any mislabeled covered draw invalidates its certificate.

## COD2 · CC 560 · AGY 590

CC’s bus objection rules out carrying the 0.90 J exclusion over to Astra’s cart. AGY’s comparator argument also removes the case for a distinct architecture when both arms can use the same scalar bound. I defend the controller-independent exclusion for the passive, explicitly energy-capped model, with approach energy included. On one preregistered native-budget near-stall box, derive a checked upper bound on work to the mandatory lift and ask whether it excludes any region left open by the matched torque and reachability baseline. If it adds no exclusion, retire the cart extension.

## COD3 · CC 380 · AGY 690

I agree with AGY that the tag minimum is a well-posed inverse query and with CC that the toy polytopes give no plant evidence. The Astra anchors motivate information and skill transfer. The three gripper SKUs are my proposed fixture. I retain the query for a fixed observation-identical prefix and withdraw any advantage over exact SMT on the same envelopes. For three simulated handover variants, verify a two-tag policy against inner action sets and use outer sets to test whether one tag is impossible. Give SMT those same sets and charge envelope derivation to both arms.
