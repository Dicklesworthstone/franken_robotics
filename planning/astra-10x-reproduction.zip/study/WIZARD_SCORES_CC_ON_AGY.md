# WIZARD_SCORES_CC_ON_AGY — OrangeStone (CC) on the AGY slate

Scored independently. No other reviewer's scores were read. WIZARD_SCORES_CC_ON_COD.md is preserved verbatim from the earlier exchange.

AGY1 | 600 | Correct form of a new family query: quantifiers and controller ownership are named, the certificate covers impossibility, and the falsifier is crisp. But ∀u over a current-limited controller *class* combined with Taylor-model enclosures through rigid contact (migrating lip witnesses, §6.2) and stick/slip will almost surely end in unknown boxes near slip onset. The pilot gives no bound on the unknown fraction, no cold-cost estimate and no specified checker. It overlaps COD1 and CC2.
- Who could already do it: Flow*/CORA/JuliaReach users on hand-encoded hybrid automata, plus dReal for the quasi-static cut.
- Strongest falsifier: a matched-law simulated trace clears the 12 mm sill inside a certified-infeasible radius/COM box, or more than 50% of the box volume stays unknown at a budget equal to the rival's.

AGY2 | 640 | The most decision-relevant mechanism of the three: contracts prune variants before rollouts, and the slate admits that 10× needs K ≥ 20 variants. Censi co-design is direct prior art, and Astra §4.1/§14.1 #1 already plans the typed open-system compiler, so the distinctive part is only the *sound pruning*. Risk of a false certificate: a conservative wrench-cone or bus-envelope contract that is wrong in the unsafe direction prunes the true winner silently. Its falsifier needs a blind full-physics audit of pruned variants, not only of survivors.
- Who could already do it: MCDP/Censi's co-design tools plus MuJoCo with hand-written feasibility filters.
- Strongest falsifier: a randomly audited pruned variant beats the selected winner on the paired §13.2 suite under independent physics.

AGY3 | 420 | A generic bundle: saltation gradients, event forking, CRN and symmetry quotienting are four separate Astra items (§5.6, §14.1 #2, #4, W24). The bet is not attributable to a single mechanism. On the actual decision the cart A/B is a binary success rate on a sharp lip with grazing and stick/slip, which is exactly where the refusal gate fires, so gradients buy little. Symmetry is already broken in the split-grip case. The 10× claim is the least supported of the three.
- Who could already do it: Kong et al. saltation code plus MJX/Isaac with CRN, or Astra's own W24/W23.
- Strongest falsifier: the refusal rate on the 64 §13.2 conditions exceeds 50%, or the inclusive cost of a gradient-assisted 60 vs 75 mm verdict is not below one tenth of CRN black-box sampling.
