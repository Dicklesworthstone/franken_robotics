# WIZARD_SCORES_CC_ON_COD — OrangeStone (CC) scoring of the COD slate

Scored privately. No peer scores read. The CC slate was not touched.
Caveat: COD cites Astra §18.x (lines 1771–1902). The plan copy I read ends at §17, line 1737, so those anchors are unverified. If the plan has since grown, they need to be re-checked against it.

COD1 | 720 | Strongest decision-level idea. It closes parameter boxes on *joint paired labels*, so it saves work exactly where the §13.2 CP rule needs it. It is checkable and composes with Astra's frozen rule. Risk: Flow*-style enclosures through rigid contact, migrating lip witnesses (§6.2) and current saturation are likely to branch almost everywhere near slip onset, which collapses toward per-draw simulation. Tenfold is unlikely on the full 8-D §13.2 contract.
- Strongest rival: matched-law MuJoCo, 64 fixed draws, plus a sequential/anytime-valid stopping rule (cheaper than any enclosure).
- Falsifier: on the sharp-lip pilot, more than 50% of the friction-interval volume ends up in split-to-points boxes, or one sealed draw is mislabeled.

COD2 | 560 | A sound and elegant energy cut that covers clairvoyant controllers. I verified the arithmetic: 8·9.81·0.012 = 0.94176 J. But Astra's cart runs on a regulated 24 V bus with ±6 A for 8 s (§13.2), so the available work is orders of magnitude above 0.9 J. The exclusion is therefore vacuous for the actual decision and binds only in a contrived passive or low-budget box. As a new family query it is valid but thin, and it is fragile to approach kinetic energy (as COD itself shows).
- Strongest rival: the §4.4 quasi-static torque/push oracle plus Drake bounds. It already excludes on torque, not energy, and is tighter.
- Falsifier: under the real §13.2 bus and current limits, the cut excludes no box that a sampling baseline wouldn't already reject in under 1 CPU-minute.

COD3 | 380 | A genuine third framing (minimum calibration tags as hypergraph coloring) with exact lower-bound certificates. But it is off the Q-001 decision path: the gripper SKUs and §18 anchors are not in the Astra plan I read. The pilot is a toy 2-D polytope with no plant dynamics, and robust action polytopes for contact-rich grasping are the hard, unpriced part.
- Strongest rival: SMT/MILP over the tag assignment, given sampled reachable command sets (same answer, standard tools).
- Falsifier: with real plant reachability for 3 SKUs × payloads, envelope derivation costs more than 10× the SMT baseline, or one sampled common command exists.
