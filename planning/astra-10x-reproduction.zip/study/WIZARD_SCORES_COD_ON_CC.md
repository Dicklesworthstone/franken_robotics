CC1 | 475 | Anytime validity controls stopping error. Matching Astra’s fixed-64 Clopper–Pearson verdict also requires a proof that unresolved strict-fidelity outcomes cannot change it. Low-fidelity concordance gives no such guarantee, and replaying every pair at strict fidelity consumes the work the proposal aims to save.
Strongest rival — Tuned strict-fidelity batching with exact curtailment over all possible completions of the frozen rule. Give both arms the same certified cheap pair bounds and charge the independent check.
Falsifier — A sealed sharp-lip pair changes from both-success at coarse fidelity to B-only at strict fidelity after being declared resolved. Kill the 10× claim if inclusive time exceeds one tenth of the matched baseline.

CC2 | 565 | The quasi-static lip oracle is a tractable exclusion pilot. The slate leaves the feedforward quantifier and its access to world parameters ambiguous. A feasible force balance gives only a necessary condition for the proposed dynamic crossing.
Strongest rival — Exact semialgebraic elimination of the same lip equations and bounds, with the same controller information, plus matched-law trajectory search for counterexamples.
Falsifier — An admissible trace clears the lip inside a certified excluded box, for example by retaining approach kinetic energy the quasi-static model dropped.

CC3 | 745 | Reusing an accepted verdict after a relevant edit can save checker and adjudication work beyond exact cache hits. The proof must cover every changed dependency of the final verdict, including contact guards and policy-visible clocks. A 20% replay sample measures errors in the sample.
Strongest rival — A hermetic per-pair DAG with content-addressed strict results, incremental verdict reduction and the same independently checkable margin bounds. Compare over the identical sealed edit sequence.
Falsifier — Reuse after a camera edit moves packet delivery across a controller tick, and independent replay changes the verdict. Count audit and invalidation work in the campaign’s 10× test.
