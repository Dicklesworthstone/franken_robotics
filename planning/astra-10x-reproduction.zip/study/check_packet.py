"""Check the study scores against the original reviews and replay the adjunct Z3 diagnostics."""
from itertools import permutations
from contextlib import redirect_stdout
from fractions import Fraction
from io import StringIO
from pathlib import Path
import json
import re
import runpy
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def sexpressions(text):
    """Read the atoms and balanced lists in these controlled SMT-LIB results."""
    stack = [[]]
    for token in re.findall(r"[()]|[^\s()]+", text):
        if token == "(":
            stack.append([])
        elif token == ")":
            if len(stack) == 1:
                raise ValueError("Unbalanced Z3 result")
            group = stack.pop()
            stack[-1].append(group)
        else:
            stack[-1].append(token)
    if len(stack) != 1:
        raise ValueError("Unterminated Z3 result")
    return stack[0]


def smt_text(expr):
    return expr if isinstance(expr, str) else "(" + " ".join(smt_text(item) for item in expr) + ")"


def z3_input(program):
    return subprocess.check_output(["z3", "-T:10", "-in"], input=program, text=True, timeout=15).strip()


def check_qe_answers(driver):
    """Replay full generated formulas and look for a real membership disagreement."""
    rows = {}
    for line in (ROOT/"pusher/PILOT_LOCK.md").read_text().splitlines():
        cells = [cell.strip() for cell in line.strip("|").split("|")]
        if len(cells) == 7 and cells[1].startswith("["):
            rows[cells[0]] = cells[1:]
    def bounds(value):
        return None if value == "∅" else tuple(map(Fraction, value.strip("[]").replace(",", " ").split()))
    required = {"wide", "both-ends", "zero-allowed", "branch-crossing", "shared-tight", "hidden-gap"}
    if set(driver["FIX"]) != required:
        raise ValueError("Incomplete raw-plant elimination fixture set")
    for name, (g, u, d, y, adjustable, common) in driver["FIX"].items():
        if [bounds(v) for v in (g, u, d, y, adjustable, common)] != [bounds(v) for v in rows[name]]:
            raise ValueError(f"The raw-plant experiment for {name} differs from the locked case")
        for shared, locked in ((False, adjustable), (True, common)):
            variable, plant = driver["formula"](g, u, d, y, shared)
            declare = f"(declare-const {variable} Real)\n"
            tactic = "(then simplify (using-params qe :qe_nonlinear true) simplify propagate-ineqs ctx-solver-simplify propagate-ineqs)"
            output = z3_input(declare + f"(assert {plant})\n(apply {tactic})")
            outer, = sexpressions(output)
            if len(outer) != 2 or outer[0] != "goals" or outer[1][0] != "goal":
                raise ValueError(f"{name} returned an unexpected goal structure")
            goal = outer[1]
            index = goal.index(":precision")
            if goal[index + 1] != "precise":
                raise ValueError(f"{name} returned an inexact goal")
            terms = [smt_text(term) for term in goal[1:index]]
            result = "(and " + " ".join(terms) + ")" if terms else "true"
            if re.search(r"\((?:forall|exists)\b", result):
                raise ValueError(f"{name} retained a quantified result")
            expected = "false" if locked == "∅" else driver["inside"](variable, locked.strip("[]").replace(",", ""))
            answer = z3_input(declare + f"(assert (xor {result} {expected}))\n(check-sat)")
            if answer != "unsat":
                raise ValueError(f"{name} shared={shared}: full eliminated answer differs or is unresolved ({answer})")


def check_policy_model(tags):
    lines = tags.splitlines()
    if lines[:4] != ["one shared tag", "unsat", "two available tags", "sat"]:
        raise ValueError("The one-tag and two-tag results changed")
    pairs, = sexpressions("\n".join(lines[4:]))
    model = dict(pairs)
    choices = [model[f"sku{s}_uses_tag2"] for s in "ABC"]
    if len(pairs) != 7 or any(choice not in ("true","false") for choice in choices):
        raise ValueError("Incomplete two-tag policy")
    def rational(value):
        if isinstance(value, list):
            op, a, b = value
            if op != "/":
                raise ValueError("Unexpected coordinate in two-tag policy")
            return Fraction(a) / Fraction(b)
        return Fraction(value)
    positions = {tag: [rational(model[k + tag]) for k in ("x", "y")] for tag in ("1", "2")}
    points = [positions["2" if choice == "true" else "1"] for choice in choices]
    if (any(v < 0 or v > 1 for point in positions.values() for v in point)
            or points[0][0] < Fraction(2,3) or points[1][1] < Fraction(2,3) or sum(points[2]) > 1):
        raise ValueError("The two-tag witness violates a gripper's action polygon")


def verify(full=False):
    matrix = json.loads((HERE / "score-matrix.json").read_text())
    by_id = {row["id"]: row for row in matrix}
    families = ("AGY", "CC", "COD")
    votes = {}
    for reviewer, author in permutations(families, 2):
        text = (HERE / f"WIZARD_SCORES_{reviewer}_ON_{author}.md").read_text()
        found = re.findall(rf"(?m)^\s*({author}[123])\s*\|\s*(\d+)\s*\|", text)
        if len(found) != 3:
            raise ValueError(f"Incomplete review from {reviewer} on {author}")
        for idea, rating in found:
            votes.setdefault(idea,{})[reviewer] = int(rating)
    if len(votes) != 9 or len(by_id) != 9 or len(matrix) != 9:
        raise ValueError("Incomplete score matrix")
    for idea, scores in votes.items():
        row = by_id[idea]
        if len(scores) != 2 or scores != row["scores"] or row["mean"] != sum(scores.values())/2:
            raise ValueError(f"The directed reviews disagree with the score matrix for {idea}")
    for author in families:
        reveal = (HERE / f"WIZARD_REACTIONS_{author}.md").read_text()
        if any(re.search(rf"\b{author}{n}\b", reveal) is None for n in (1,2,3)):
            raise ValueError(f"Final reveal missing a reviewed idea for {author}")
    print("Six reviews yielded 18 matching votes across nine ideas. All three reveals cover their ideas.")
    if not full:
        return
    result = subprocess.check_output([sys.executable, "-B", "contract_bus_check.py"], cwd=ROOT / "information")
    if result != (ROOT / "information/contract_bus.out").read_bytes():
        raise ValueError("The two-finger shared-resource receipt changed")
    tags = subprocess.check_output(["z3",str(ROOT / "information/compare_cod3_tags.smt2")],text=True)
    check_policy_model(tags)
    print("Direct action-polytope SMT test found one tag unsatisfiable and two tags satisfiable.")
    audit = ROOT / "pusher/audit_pilot"
    preview = StringIO()
    with redirect_stdout(preview):
        driver = runpy.run_path(str(audit / "z3_qe_produce.py"))
    raw = preview.getvalue()
    expected = (audit / "z3_qe_produce.out").read_text()
    def untimed(text):
        return re.sub(r"\s+\d+ ms  z3:", " z3:", text).splitlines()
    if len(raw.splitlines()) != 12 or untimed(raw) != untimed(expected):
        raise ValueError("Selected raw-plant elimination results changed; inspect the full solver outputs")
    check_qe_answers(driver)
    print("Two bus cases and 12 formula previews reproduced. All 12 full quantifier-free answers equal their locked intervals.")


if __name__ == "__main__":
    verify("--all" in sys.argv[1:])
