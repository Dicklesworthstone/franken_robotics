# Disagreement register

## D-001 · Does adaptive fidelity preserve the registered rule?

Claude initially proposed cheap concordance classification and an anytime-valid rule. Codex distinguished time-uniform inference from computing the particular sealed fixed-n decision. Claude withdrew its decision claim after the review. A revival needs sound per-pair fidelity bounds or exact curtailment under the frozen rule. [by_cc.md](WIZARD_REACTIONS_CC.md) · [by_cod.md](WIZARD_REACTIONS_COD.md)

## D-002 · Does verdict reuse add something beyond caching?

Codex scored Claude’s CC3 at 745. Gemini scored it at 510. Claude defended complete dependency masks and withdrew unsupported sensitivity margins. The exact clock guard enabled the reference DAG to match the receipt on all four edit states. Reopen only for an actual expensive invariant whose discovery, checking and reuse can beat a comparator given the same information. [by_cod.md](WIZARD_REACTIONS_COD.md) · [by_agy.md](WIZARD_REACTIONS_AGY.md) · [by_cc.md](WIZARD_REACTIONS_CC.md) · [Executed test](../information/REUSE_CHECK.md)

## D-003 · Is the minimum calibration-tag query ready for a robot plant?

Claude scored Codex's minimum-tag query 380; Gemini scored it 690. Claude emphasized missing derivation of contact-feasible action sets. Gemini valued the independently checkable upper and lower bounds. Codex retained the inverse query and withdrew any advantage over exact SMT supplied with the same envelopes. The separate scalar fixture reproduced the deadline and tag frontiers with ordinary elimination. [by_cc.md](WIZARD_REACTIONS_CC.md) · [by_agy.md](WIZARD_REACTIONS_AGY.md) · [by_cod.md](WIZARD_REACTIONS_COD.md)

## D-004 · What falsifies robust impossibility?

Gemini proposed “every controller has a failing disturbance” and a single-success falsifier. Codex pointed out the missing quantifier. Gemini conceded and changed to uniformly failing boxes over a bounded controller parameterization. The revised falsifier applies to the stronger uniform-failure claim only. [by_agy.md](WIZARD_REACTIONS_AGY.md) · [by_cod.md](WIZARD_REACTIONS_COD.md)
