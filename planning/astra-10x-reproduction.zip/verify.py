"""Run from any directory. Default checks use the Python standard library."""
from fractions import Fraction
import argparse
import ast
import hashlib
import json
import math
import os
import re
from pathlib import Path
import subprocess
import sys
from statistics import median

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
MOR = ROOT / "mor" / "repro"
PUSHER = ROOT / "pusher"
SILL = ROOT / "sill"


def check_integrity():
    listed = set()
    for line in (ROOT / "SHA256SUMS").read_text().splitlines():
        record = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
        if not record:
            raise ValueError("Malformed checksum record")
        expected, name = record.groups()
        path = ROOT / name
        if (Path(name).is_absolute() or Path(name).as_posix() != name or ".." in Path(name).parts
                or name in listed or not path.is_file() or path.is_symlink()):
            raise ValueError(f"Invalid, missing or duplicate checksum path {name!r}")
        observed = hashlib.sha256(path.read_bytes()).hexdigest()
        if expected != observed:
            raise ValueError(f"SHA-256 mismatch in {name}")
        listed.add(name)
    names = "\n".join(sorted(listed)).encode()
    if hashlib.sha256(names).hexdigest() != "684ebc716bf0b8f092d2e40a8dc9c6d48b796ca8bf1a3aed794db23834b0e467":
        raise ValueError("Checksum manifest does not cover the released payload inventory")
    print(f"Verified the complete release inventory and {len(listed)} file digests.")


def run(program, *args):
    return subprocess.check_output(
        [sys.executable, "-B", program.name, *args], cwd=program.parent
    )


def match(program, receipt):
    observed = run(program)
    if observed != receipt.read_bytes():
        raise ValueError(f"Output differs from {receipt.name}")
    print(f"{program.name} matched {receipt.name}.")


def check_gripper_audit(transcript):
    """Compare the separate auditor's numeric decisions with the primary study."""
    counts_prefix = "synthetic pad grid "
    mass_prefix = "nominal min mass, counts, best lighter upper "
    lines = transcript.splitlines()
    count_lines = [line.removeprefix(counts_prefix) for line in lines if line.startswith(counts_prefix)]
    mass_lines = [line.removeprefix(mass_prefix) for line in lines if line.startswith(mass_prefix)]
    if len(count_lines) != 1 or len(mass_lines) != 2:
        raise ValueError("Missing or duplicate independent gripper audit rows")
    plain = re.sub(r"Counter\((\{[^{}]*\})\)", r"\1", count_lines[0])
    observed = ast.literal_eval(plain)
    primary = json.loads((MOR / "P02-identification-results.json").read_text())["results"]
    expected = {}
    for law in "VPCD":
        expected[law] = {}
        for prefix, key in (("early", "sealed_three"), ("direct", "direct")):
            for label, count in primary[key]["per_law"][law]["counts"].items():
                if count:
                    expected[law][f"{prefix}_{label}"] = count
    if observed != expected:
        raise ValueError("Independent gripper classifications differ from the primary grid")
    family = json.loads((MOR / "P02-identification-family.json").read_text())
    seen = set()
    for line in mass_lines:
        law, grams, num_a, num_b, light_upper = line.split()
        if law not in {"V", "P"} or law in seen:
            raise ValueError("Wrong or repeated nominal material law")
        seen.add(law)
        best = family[law]["best"]
        expected_upper = family[law]["highest_upper_bound_among_lighter"]["upper_N"]
        if ([int(grams), int(num_a), int(num_b)] != [best["mass_g"], best["a"], best["b"]]
                or not math.isclose(float(light_upper), expected_upper, rel_tol=0, abs_tol=1e-10)):
            raise ValueError("Independent nominal gripper design differs from primary family")
    print("Verified independent early/direct counts for four material laws and both reported nominal optima.")


def check_normalization_records(metal, cuda):
    """Recompute the specified f32 operations and check every archived native row."""
    cpu = run(ROOT / "followups/normalization_native.py", "cpu").decode().strip()
    payload = cpu.removeprefix("CPU (mean, raw variance, centered variance): ")
    if payload == cpu:
        raise ValueError("Missing CPU normalization record")
    if metal.splitlines() != [cpu, "Apple M5 Ultra " + payload]:
        raise ValueError("Metal normalization record differs from f32 reference")
    expected = [cpu] + [f"CUDA device {i} NVIDIA GeForce RTX 4090 " + payload for i in (0,1)]
    if cuda.splitlines() != expected:
        raise ValueError("CUDA normalization records differ from f32 reference or device inventory")
    print("Checked three centered/raw variance triples on each recorded native device against CPU f32.")


def locked_pusher_rows():
    rows = {}
    for line in (PUSHER / "PILOT_LOCK.md").read_text().splitlines():
        cells = [value.strip() for value in line.strip("|").split("|")]
        if len(cells) == 7 and cells[1].startswith("["):
            name, *values = cells
            if name in rows:
                raise ValueError(f"Duplicate locked pusher case {name}")
            rows[name] = values
    if len(rows) != 10:
        raise ValueError("Expected ten different locked pusher cases")
    return rows


def check_pusher_receipt(receipt, solver_fixtures):
    arms = ["specialized", "composed"]
    locked = {name: [None if value == "∅" else value.strip("[]").replace(",", "") for value in values]
              for name, values in locked_pusher_rows().items()}
    if (receipt["fixtures"] != locked or {k: list(v) for k, v in solver_fixtures.items()} != locked
            or receipt["locked_matches"] != dict.fromkeys(arms, 20)
            or receipt["retries"] != 0 or receipt["warm_batches_per_trial"] != 100):
        raise ValueError("Pusher fixture inputs, locked coverage, retries or warm batch size changed")
    for mode in ("warm", "cold"):
        record = receipt[mode]
        trials = record["trials"]
        if len(trials) != 9:
            raise ValueError(f"Incomplete {mode} pusher timing pairs")
        for index, trial in enumerate(trials):
            times = trial["ns_per_batch"]
            if (trial["order"] != (arms if index % 2 == 0 else arms[::-1])
                    or set(times) != set(arms) or set(trial["matches_reference"]) != set(arms)
                    or any(trial["matches_reference"][arm] is not True for arm in arms)
                    or any(type(t) not in (int, float) or not math.isfinite(t) or t <= 0 for t in times.values())):
                raise ValueError(f"Invalid or unmatched {mode} pusher timing pair {index + 1}")
        medians = {arm: median(trial["ns_per_batch"][arm] for trial in trials) for arm in arms}
        ratio = medians["composed"] / medians["specialized"]
        if record["median_ns_per_batch"] != medians or record["composed_over_specialized"] != ratio:
            raise ValueError(f"The recorded {mode} pusher medians or ratio differ from the trial values")
    print("Pusher receipt matched the ten locked fixtures and all 18 timing pairs. Recomputed both median ratios.")


def pusher():
    sys.path.insert(0, str(PUSHER))
    import pilot
    receipt = json.loads((PUSHER / "PILOT_RUN.json").read_text())
    check_pusher_receipt(receipt, pilot.FIXTURES)
    reference = receipt["reference"]
    for arm in ("specialized", "composed"):
        observed = json.loads(run(PUSHER / "pilot.py", "--arm", arm))
        if (observed != reference[arm] or set(observed) != set(pilot.FIXTURES)
                or len(observed) != 10 or not all(row["accepted"] is True for row in observed.values())
                or pilot.locked_matches(observed) != 20):
            raise ValueError(f"{arm} certificates or proofs changed")
    expected_controls = {"widened-design", "truncated-design", "overstated-shared",
                         "gap-violating-schedule", "spurious-empty-design", "spurious-empty-shared"}
    controls = pilot.negative_controls(reference["specialized"])
    if (set(controls) != expected_controls or controls != receipt["negative_controls"]
            or not all(row["rejected"] is True for row in controls.values())):
        raise ValueError("A registered pusher negative control changed or was accepted")
    print("Both pusher arms matched 40 locked intervals. All six incorrect certificates were rejected.")


def docking_counts():
    # Terminal (position, velocity) fixes the last commands to 1/g-2x and
    # x-1/g for first command x. Intersect their scalar bounds over both gains.
    admitted = excluded = touching = 0
    for index in range(17):
        bound = Fraction(1, 2) + Fraction(index, 32)
        lower, upper = -bound, bound
        for gain in (1, 2):
            displacement = Fraction(1, gain)
            lower = max(lower, (displacement-bound)/2, displacement-bound)
            upper = min(upper, (displacement+bound)/2, displacement+bound)
        if lower > upper:
            raise ValueError("No feasible conditional schedule at zero measurement error")
        separation = max(abs(lower), abs(upper))
        for j in range(33):
            twice_error = 2*Fraction(j, 64)
            if separation > twice_error:
                admitted += 1
            else:
                excluded += 1
            touching += separation == twice_error
    if (admitted, excluded, touching) != (344, 217, 9):
        raise ValueError("The independent rational docking counts changed")
    print("Docking inequalities reproduced 344 admissions, 217 exclusions and 9 equalities.")



def smt():
    from pusher.check_locked_pusher_z3 import problem
    cases = {}
    for name, (gains, commands, gaps, goals, adjustable, shared) in locked_pusher_rows().items():
        for kind, answer in (("adjustable", adjustable), ("shared", shared)):
            filename = f"{name}-{kind}.smt2"
            cases[filename] = (problem(gains, commands, gaps, goals, answer, kind == "shared"), "unsat")
    cases["mutant-wide-adjustable.smt2"] = (
        problem("[1/2,2]", "[0,2]", "[0,1/4]", "[3/4,5/4]", "[1,2]", False), "sat")
    directory = PUSHER / "queries"
    if {p.name for p in directory.glob("*.smt2")} != set(cases):
        raise ValueError("Literal query inventory differs from the 20 locked cases plus one mutant")
    for name, (program, expected) in cases.items():
        formula = directory / name
        if formula.read_text() != program:
            raise ValueError(f"{name} differs from the raw plant and locked interval")
        observed = subprocess.check_output(["z3", "-T:5", str(formula)], timeout=8, text=True).strip()
        if observed != expected:
            raise ValueError(f"{formula.name} yielded {observed}, expected {expected}")
    print("Z3 accepted 20 regenerated exact-set comparisons and exposed the mutant.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--all", action="store_true", help="also run the pinned scientific Python and Z3 checks")
    flags = parser.parse_args()
    if sys.flags.optimize:
        raise SystemExit("Scientific checks require Python assertions. Rerun without -O or PYTHONOPTIMIZE.")
    # A parent launched with -E can ignore this while its child interpreters inherit it.
    os.environ.pop("PYTHONOPTIMIZE", None)
    check_integrity()
    from check_additions import check_native_receipts, information, planar
    from study.check_packet import verify as verify_study
    verify_study(flags.all)
    check_native_receipts()
    check_normalization_records((ROOT / "followups/moments-metal.txt").read_text(),
                                (ROOT / "followups/moments-cuda.txt").read_text())
    check_gripper_audit((ROOT / "followups/gripper-audit.txt").read_text())
    print(run(ROOT / "followups/recheck_pilots.py").decode(), end="")
    information()
    for driver,receipt in [
        ("P02-identification.py", "P02-identification-results.json"),
        ("P02-identification-family.py", "P02-identification-family.json"),
        ("P03-sensor.py", "P03-results.txt"),
        ("P04-docking.py", "P04-docking.txt"),
    ]:
        match(MOR/driver, MOR/receipt)
    match(SILL/"quasistatic_sill.py", SILL/"quasistatic_sill.out")
    pusher()
    docking_counts()
    if flags.all:
        for name in ("docking_support", "wheel_sample"):
            match(ROOT / "followups" / (name + ".py"), ROOT / "followups" / (name + ".txt"))
        for name in ("r2_contracts.py", "r4_contracts.py", "contact_work.py", "studio_contracts.py", "N2_benchmark.py",
                     "agent_boundaries.py", "catalog_scene_checks.py", "gait_and_resource.py"):
            run(ROOT / "followups" / name)
            print(f"{name} passed its executable contract checks.")
        match(MOR/"P05-docking-family.py", MOR/"P05-docking-family.txt")
        match(SILL/"promotion_rule.py", SILL/"promotion_rule.out")
        match(MOR/"P01-inverse.py", MOR/"P01-results.json")
        print(run(ROOT / "followups/recheck_pilots.py", "--linprog").decode(), end="")
        audit = run(MOR/"AUD01-recheck.py").decode()
        check_gripper_audit(audit)
        print(audit, end="")
        smt()
        planar()


if __name__ == "__main__":
    main()
