"""Regression checks for missing or plausible-but-wrong evidence in disposable copies."""
import copy
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from unittest.mock import patch

import check_additions as native
import verify
from study.check_packet import check_policy_model


def rejected(name, action):
    try:
        action()
    except (ValueError, FileNotFoundError) as exc:
        print(f"Rejected {name}: {exc}")
        return
    raise AssertionError(f"Accepted invalid input: {name}")


def main():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        manifest = root / "SHA256SUMS"
        manifest.write_text("")
        with patch.object(verify, "ROOT", root):
            rejected("empty inventory", verify.check_integrity)

        pusher = root / "pusher"
        shutil.copytree(verify.PUSHER, pusher)
        with patch.object(verify, "PUSHER", pusher):
            query = pusher / "queries/wide-adjustable.smt2"
            query.unlink()
            rejected("missing locked SMT program", verify.smt)
            query.write_text("(assert false)\n(check-sat)\n")
            rejected("unrelated UNSAT answer", verify.smt)

        sys.path.insert(0, str(verify.PUSHER))
        import pilot
        timed = json.loads((verify.PUSHER / "PILOT_RUN.json").read_text())
        def check_timing(record):
            verify.check_pusher_receipt(record, pilot.FIXTURES)
        altered = copy.deepcopy(timed)
        altered["fixtures"]["wide"][0] = "1 1"
        rejected("incorrect gain interval in timed inputs", lambda: check_timing(altered))
        altered = copy.deepcopy(timed)
        altered["warm"]["trials"].pop()
        rejected("missing warm timing pair", lambda: check_timing(altered))
        altered = copy.deepcopy(timed)
        altered["cold"]["trials"][0]["matches_reference"]["composed"] = False
        rejected("incorrect answer in a cold timed batch", lambda: check_timing(altered))
        altered = copy.deepcopy(timed)
        altered["warm"]["composed_over_specialized"] = 13.45
        rejected("overstated pusher timing ratio", lambda: check_timing(altered))
        grid = json.loads((verify.SILL / "pilot_quick.json").read_text())
        altered = copy.deepcopy(grid)
        altered["rows"][-1]["rf"] = 0.060
        rejected("incorrect wheel radius under label B", lambda: native.quick_grid(altered))
        altered = copy.deepcopy(grid)
        altered["dt"] = 1e-3
        rejected("different planar solver step", lambda: native.quick_grid(altered))
        altered = copy.deepcopy(grid)
        altered["rows"][0] = altered["rows"][1]
        rejected("duplicated planar condition", lambda: native.quick_grid(altered))
        altered = copy.deepcopy(grid)
        next(r for r in altered["rows"] if r["outcome"] == "success")["t_goal"] = float("nan")
        rejected("success with no recorded clearance", lambda: native.quick_grid(altered))
        altered = copy.deepcopy(grid)
        altered["rows"][0]["max_pitch"] = float("inf")
        rejected("infinite reported pitch", lambda: native.quick_grid(altered))
        altered = copy.deepcopy(grid)
        altered["rows"][0]["t_front_over"] = 0
        rejected("absent crossing reported as time zero", lambda: native.strict_planar_record(altered))

        shutil.copytree(native.ROOT / "native", root / "native")
        receipt = root / "native/cuda/RECEIPT.json"
        original = json.loads(receipt.read_text())
        with patch.object(native, "ROOT", root):
            for field in ("registered_runs", "exploratory_direct_int32_gpu0_runs"):
                altered = copy.deepcopy(original)
                altered[field] = []
                receipt.write_text(json.dumps(altered))
                rejected(f"missing CUDA {field}", native.check_native_receipts)
            altered = copy.deepcopy(original)
            altered["registered_runs"][-1]["per_shard"][0]["raw_fp"] += 1
            receipt.write_text(json.dumps(altered))
            # Change the original stdout too: the independent bitmaps must still detect the error.
            log = root / "native/cuda/native-runs.txt"
            log.write_text(log.read_text().replace("raw_fp=53 raw_fn=2389", "raw_fp=54 raw_fn=2389"))
            rejected("wrong dual-device shard false-positive count", native.check_native_receipts)

        metal = json.loads((native.ROOT / "native/metal/RECEIPT.json").read_text())
        near = native.reference(1)
        altered = copy.deepcopy(metal["workloads"]["near"])
        altered["cold"][0]["gpu"]["ones"] -= 1
        rejected("wrong accepted count in a cold Metal run",
                 lambda: native.check_metal_workload(altered, near, False))
        altered = copy.deepcopy(metal["workloads"]["near"])
        slowest = max(altered["warm"]["samples"], key=lambda s: s["metal_us"])
        slowest["metal_us"] = float("inf")
        rejected("nonfinite warm Metal sample with unchanged median",
                 lambda: native.check_metal_workload(altered, near, False))

        # SAT and UNSAT headers alone contain no usable controller witness.
        valid = (verify.ROOT / "information/cod3-z3.out").read_text()
        invalid = valid.replace("(y2 (/ 2.0 3.0))", "(y2 0.0)")
        if valid == invalid:
            raise AssertionError("The negative control did not alter the historical witness")
        rejected("infeasible two-tag policy", lambda: check_policy_model(invalid))
        fast = subprocess.run([sys.executable, "-O", "-B", str(verify.ROOT/"verify.py")],
                              text=True, capture_output=True)
        if fast.returncode == 0 or "require Python assertions" not in fast.stderr:
            raise AssertionError("Optimized Python was not refused")
        print("Rejected optimized Python, which would suppress scientific assertions.")


if __name__ == "__main__":
    main()
